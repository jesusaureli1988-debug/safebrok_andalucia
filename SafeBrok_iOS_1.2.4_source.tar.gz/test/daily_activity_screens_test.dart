import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:safebrok_andalucia/features/business/add_contactos_diarios_screen.dart';
import 'package:safebrok_andalucia/features/business/contactos_diarios_screen.dart';
import 'package:safebrok_andalucia/features/business/seguimiento_clientes_screen.dart';
import 'package:safebrok_andalucia/features/business/detalle_seguimiento_screen.dart';
import 'package:safebrok_andalucia/features/business/referencia_diaria_screen.dart';
import 'package:safebrok_andalucia/features/jefe_ventas/control_equipos_jefe_ventas_screen.dart';
import 'package:safebrok_andalucia/features/tareas/mis_tareas_screen.dart';

void main() {
  const own = '00000000-0000-0000-0000-000000000001';
  const child = '00000000-0000-0000-0000-000000000002';
  const outside = '00000000-0000-0000-0000-000000000003';
  var role = 'agente';
  var fail = false;
  var control = false;
  final requests = <http.Request>[];
  Map<String, dynamic> profile() => {
    'id': 'root',
    'auth_id': own,
    'rol_usuario': role,
    'nombre': 'Responsable',
    'parent_id': null,
  };
  Map<String, dynamic> followup() => {
    'id': 1,
    'auth_id': own,
    'cliente_id': 1,
    'nombre': 'Cliente con nombre y apellidos largos de prueba',
    'producto': 'Seguro de hogar',
    'telefono': '600000000',
    'proxima_llamada': DateTime.now().toIso8601String(),
    'estado': 'Pendiente',
    'tipo_llamada': 'Seguimiento',
  };
  setUpAll(() async {
    final fontDir = Platform.environment['SAFEBROK_QA_FONTS'];
    if (fontDir != null) {
      for (final family in ['Roboto', 'Ahem', 'MaterialIcons']) {
        final loader = FontLoader(family);
        final names = family != 'MaterialIcons'
            ? ['Roboto-Regular.ttf', 'Roboto-Bold.ttf']
            : ['MaterialIcons-Regular.otf'];
        for (final name in names) {
          loader.addFont(
            File(
              '$fontDir/$name',
            ).readAsBytes().then((b) => ByteData.sublistView(b)),
          );
        }
        await loader.load();
      }
    }
    SharedPreferences.setMockInitialValues({});
    await Supabase.initialize(
      url: 'https://example.supabase.co',
      anonKey: 'test',
      authOptions: const FlutterAuthClientOptions(
        autoRefreshToken: false,
        detectSessionInUri: false,
      ),
      httpClient: MockClient((r) async {
        requests.add(r);
        dynamic body = [];
        if (r.url.path.endsWith('/usuarios')) {
          body = r.url.queryParameters.containsKey('auth_id')
              ? profile()
              : [
                  profile(),
                  {
                    'id': 'child',
                    'auth_id': child,
                    'parent_id': 'root',
                    'rol_usuario': 'agente',
                    'nombre': 'Agente propio',
                  },
                  {
                    'id': 'outside',
                    'auth_id': outside,
                    'parent_id': 'other',
                    'rol_usuario': 'agente',
                    'nombre': 'Agente ajeno',
                  },
                ];
        } else if (!control && r.url.path.endsWith('/contactos_diarios')) {
          body = [
            {
              'id': 1,
              'fecha': DateTime.now().toIso8601String(),
              'contactos_frios': 5,
              'contactos_telefonicos': 5,
              'contactos_positivos': 6,
              'contactos_negativos': 4,
            },
          ];
        } else if (!control &&
            r.url.path.endsWith('/seguimiento_clientes') &&
            !r.url.queryParameters.containsKey('proxima_llamada') &&
            r.url.queryParameters['estado'] != 'eq.Realizada') {
          body = [followup()];
        }
        return http.Response(
          jsonEncode(fail ? {'message': 'No disponible'} : body),
          fail ? 500 : 200,
          request: r,
          headers: {'content-type': 'application/json'},
        );
      }),
    );
    String part(Object v) =>
        base64Url.encode(utf8.encode(jsonEncode(v))).replaceAll('=', '');
    await Supabase.instance.client.auth.recoverSession(
      jsonEncode({
        'access_token':
            '${part({'alg': 'HS256'})}.${part({'sub': own, 'exp': 4102444800})}.test',
        'refresh_token': 'test',
        'token_type': 'bearer',
        'expires_in': 3600,
        'expires_at': 4102444800,
        'user': {
          'id': own,
          'aud': 'authenticated',
          'email': 'test@example.invalid',
          'created_at': '2026-01-01T00:00:00Z',
          'app_metadata': {},
          'user_metadata': {},
        },
      }),
    );
  });
  tearDownAll(() async => Supabase.instance.dispose());
  setUp(() {
    requests.clear();
    fail = false;
    control = false;
    role = 'agente';
  });

  Future<void> show(WidgetTester t, Widget screen, {double width = 390}) async {
    t.view.physicalSize = Size(width, 1100);
    t.view.devicePixelRatio = 1;
    addTearDown(t.view.resetPhysicalSize);
    addTearDown(t.view.resetDevicePixelRatio);
    await t.pumpWidget(
      RepaintBoundary(
        key: const ValueKey('capture'),
        child: MaterialApp(debugShowCheckedModeBanner: false, home: screen),
      ),
    );
    await t.pumpAndSettle();
  }

  Future<void> capture(WidgetTester t, String name) async {
    final dir = Platform.environment['SAFEBROK_QA_DIR'];
    if (dir == null) return;
    await expectLater(
      find.byKey(const ValueKey('capture')),
      matchesGoldenFile('$dir/$name.png'),
    );
  }

  for (final r in [
    'agente',
    'jefe_equipo',
    'jefe_ventas',
    'director_zona',
    'director_nacional',
    'administracion',
  ]) {
    testWidgets('Contactos y seguimiento propios mantienen alcance para $r', (
      t,
    ) async {
      role = r;
      await show(t, const ContactosDiariosScreen(), width: 320);
      expect(find.text('Control de actividad'), findsOneWidget);
      expect(t.takeException(), isNull);
      if (r == 'agente') await capture(t, 'contactos');
      await show(t, const SeguimientoClientesScreen(), width: 320);
      expect(find.text('LLAMADAS DE HOY'), findsOneWidget);
      expect(t.takeException(), isNull);
      final queries = requests.where(
        (r) =>
            r.url.path.endsWith('/contactos_diarios') ||
            r.url.path.endsWith('/seguimiento_clientes'),
      );
      expect(queries, isNotEmpty);
      expect(
        queries.every((r) => r.url.queryParameters['auth_id'] == 'eq.$own'),
        isTrue,
      );
      if (r == 'agente') await capture(t, 'seguimientos');
    });
  }
  testWidgets(
    'El acceso antiguo y la tarea diaria abren Nueva referencia del CRM',
    (t) async {
      await show(t, const ReferenciaDiariaScreen());
      expect(find.text('Nueva referencia'), findsOneWidget);
      expect(t.takeException(), isNull);
      await capture(t, 'nueva-referencia');
      await t.ensureVisible(find.text('Cancelar'));
      await t.tap(find.text('Cancelar'));
      await t.pumpAndSettle();
      expect(find.text('Nueva referencia'), findsNothing);
      await show(t, const MisTareasScreen());
      await t.ensureVisible(find.text('Incluir 3 referencias diarias'));
      await t.tap(find.text('Incluir 3 referencias diarias'));
      await t.pumpAndSettle();
      expect(find.text('Nueva referencia'), findsOneWidget);
      expect(t.takeException(), isNull);
    },
  );
  testWidgets('Cambiar cantidad de positivos conserva los datos escritos', (
    t,
  ) async {
    await show(t, const AddContactosDiariosScreen(), width: 320);
    final positive = find.widgetWithText(TextFormField, 'Contactos positivos');
    await t.enterText(positive, '1');
    await t.pumpAndSettle();
    final name = find.widgetWithText(TextFormField, 'Nombre completo');
    await t.ensureVisible(name);
    await t.enterText(name, 'Nombre conservado');
    await t.ensureVisible(positive);
    await t.enterText(positive, '2');
    await t.pumpAndSettle();
    expect(find.text('Nombre conservado'), findsOneWidget);
    expect(t.takeException(), isNull);
    await t.drag(
      find.byType(SingleChildScrollView).first,
      const Offset(0, 1000),
    );
    await t.pumpAndSettle();
    await capture(t, 'nuevo-contacto');
  });
  testWidgets('Detalle de seguimiento cabe en móvil', (t) async {
    await show(
      t,
      DetalleSeguimientoScreen(seguimiento: followup()),
      width: 320,
    );
    expect(t.takeException(), isNull);
    await capture(t, 'detalle-seguimiento');
  });
  testWidgets('Un error de carga muestra reintento y no Todo al día', (
    t,
  ) async {
    fail = true;
    await show(t, const SeguimientoClientesScreen());
    expect(find.text('Reintentar'), findsOneWidget);
    expect(find.text('Todo al día'), findsNothing);
    await show(t, const ContactosDiariosScreen());
    expect(find.text('Reintentar'), findsOneWidget);
    expect(t.takeException(), isNull);
  });
  for (final r in [
    'jefe_equipo',
    'jefe_ventas',
    'director_zona',
    'director_nacional',
  ]) {
    testWidgets('Control de equipos de $r consulta solo sus descendientes', (
      t,
    ) async {
      role = r;
      control = true;
      await show(t, const ControlEquiposJefeVentasScreen(), width: 390);
      final taskQueries = requests.where(
        (r) =>
            r.url.path.endsWith('/referencias_viables') ||
            r.url.path.endsWith('/contactos_diarios') ||
            r.url.path.endsWith('/seguimiento_clientes') ||
            r.url.path.endsWith('/actividad_agentes'),
      );
      expect(taskQueries, isNotEmpty);
      expect(
        taskQueries.every(
          (r) => r.url.queryParameters['auth_id'] == 'eq.$child',
        ),
        isTrue,
      );
      expect(t.takeException(), isNull);
      if (r == 'jefe_equipo') await capture(t, 'control-equipo');
    });
  }
}
