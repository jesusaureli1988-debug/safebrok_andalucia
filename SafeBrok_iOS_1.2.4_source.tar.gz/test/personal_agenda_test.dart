import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import 'package:safebrok_andalucia/features/agenda/agenda_screen.dart';
import 'package:safebrok_andalucia/features/agenda/crear_evento_screen.dart';
import 'package:safebrok_andalucia/features/team/agenda_jefe_equipo_screen.dart';

void main() {
  const own = '00000000-0000-0000-0000-000000000001';
  const outsider = '00000000-0000-0000-0000-000000000002';
  final queries = <Uri>[];
  final now = DateTime.now();
  final day = DateTime(now.year, now.month, now.day);
  final date = day.toIso8601String().substring(0, 10);
  setUpAll(() async {
    final fontDir = Platform.environment['SAFEBROK_QA_FONTS'];
    if (fontDir != null) {
      for (final family in ['Roboto', 'Ahem', 'MaterialIcons']) {
        final loader = FontLoader(family);
        final names = family == 'MaterialIcons'
            ? ['MaterialIcons-Regular.otf']
            : ['Roboto-Regular.ttf', 'Roboto-Bold.ttf'];
        for (final name in names) {
          loader.addFont(
            File(
              '$fontDir/$name',
            ).readAsBytes().then((b) => ByteData.sublistView(b)),
          );
        }
        await loader.load();
      }
    }

    SharedPreferences.setMockInitialValues({});
    await Supabase.initialize(
      url: 'https://example.supabase.co',
      anonKey: 'test',
      authOptions: const FlutterAuthClientOptions(
        autoRefreshToken: false,
        detectSessionInUri: false,
      ),
      httpClient: MockClient((r) async {
        queries.add(r.url);
        dynamic data = [];
        switch (r.url.path.split('/').last) {
          case 'usuarios':
            data = {'id': 'internal-agent'};
          case 'agenda_eventos':
            data = [
              {
                'id': 1,
                'titulo': 'Cita propia',
                'fecha_inicio': '${date}T10:00:00',
                'fecha_fin': '${date}T11:00:00',
              },
            ];
          case 'reuniones':
            data = [
              {
                'id': 1,
                'titulo': 'Reunión invitada',
                'creador_auth_id': outsider,
                'invitados': [own],
                'fecha_inicio': '${date}T12:00:00',
                'fecha_fin': '${date}T13:00:00',
              },
              {
                'id': 2,
                'titulo': 'Reunión ajena',
                'creador_auth_id': outsider,
                'invitados': [],
                'fecha_inicio': '${date}T14:00:00',
                'fecha_fin': '${date}T15:00:00',
              },
            ];
          case 'visitas':
            data = [
              {
                'id': 1,
                'nombre_cliente': 'Cliente visita',
                'direccion': 'Dirección de prueba',
                'fecha_visita': date,
                'hora_visita': '09:30:00',
              },
            ];
          case 'planificacion_semanal_equipo':
            data = [
              {
                'id': 1,
                'semana_inicio': date,
                'lunes': 'Plan personal',
                'martes': '',
                'miercoles': null,
              },
            ];
        }
        return http.Response(
          jsonEncode(data),
          200,
          request: r,
          headers: {'content-type': 'application/json'},
        );
      }),
    );
    String part(Object v) =>
        base64Url.encode(utf8.encode(jsonEncode(v))).replaceAll('=', '');
    await Supabase.instance.client.auth.recoverSession(
      jsonEncode({
        'access_token':
            '${part({'alg': 'HS256'})}.${part({'sub': own, 'exp': 4102444800})}.test',
        'refresh_token': 'test',
        'token_type': 'bearer',
        'expires_in': 3600,
        'expires_at': 4102444800,
        'user': {
          'id': own,
          'aud': 'authenticated',
          'created_at': '2026-01-01T00:00:00Z',
          'app_metadata': {},
          'user_metadata': {},
        },
      }),
    );
  });
  tearDownAll(() async => Supabase.instance.dispose());
  setUp(queries.clear);
  Future<void> show(WidgetTester t, Widget screen, {double width = 390}) async {
    if (Platform.environment['SAFEBROK_QA_FONTS'] != null) {
      final previousShadows = debugDisableShadows;
      debugDisableShadows = false;
      addTearDown(() => debugDisableShadows = previousShadows);
    }
    t.view.physicalSize = Size(width, 1000);
    t.view.devicePixelRatio = 1;
    addTearDown(t.view.resetPhysicalSize);
    addTearDown(t.view.resetDevicePixelRatio);
    await t.pumpWidget(
      RepaintBoundary(
        key: const ValueKey('agenda-capture'),
        child: MaterialApp(debugShowCheckedModeBanner: false, home: screen),
      ),
    );
    await t.pumpAndSettle();
  }

  testWidgets(
    'La agenda personal usa el calendario del jefe y conserva cada actividad sin duplicarla',
    (t) async {
      await show(t, const AgendaScreen());
      expect(find.text('Mi agenda'), findsOneWidget);
      final qaDir = Platform.environment['SAFEBROK_QA_DIR'];
      if (qaDir != null)
        await expectLater(
          find.byKey(const ValueKey('agenda-capture')),
          matchesGoldenFile('$qaDir/agenda-personal.png'),
        );
      final calendar = t.widget<SfCalendar>(find.byType(SfCalendar));
      final appointments = calendar.dataSource!.appointments!
          .cast<Appointment>();
      expect(
        appointments.map((a) => a.subject),
        unorderedEquals([
          'Cita propia',
          'Visita: Cliente visita',
          'Plan personal',
          'Reunión invitada',
        ]),
      );
      expect(
        appointments.singleWhere((a) => a.subject == 'Plan personal').isAllDay,
        isTrue,
      );
      final visits = queries.singleWhere((q) => q.path.endsWith('/visitas'));
      expect(visits.queryParameters['auth_id'], 'eq.$own');
      final plan = queries.singleWhere(
        (q) => q.path.endsWith('/planificacion_semanal_equipo'),
      );
      expect(plan.queryParameters['agente_id'], 'eq.internal-agent');
      expect(t.takeException(), isNull);
      await t.tap(find.text('Semana').last);
      await t.pumpAndSettle();
      expect(
        t.widget<SfCalendar>(find.byType(SfCalendar)).view,
        CalendarView.week,
      );
      await t.tap(find.text('Día'));
      await t.pumpAndSettle();
      expect(
        t.widget<SfCalendar>(find.byType(SfCalendar)).view,
        CalendarView.day,
      );
      await t.tap(find.text('Nuevo evento'));
      await t.pumpAndSettle();
      expect(find.byType(CrearEventoScreen), findsOneWidget);
      expect(find.byType(MeetingCreateDialogJefeEquipo), findsNothing);
    },
  );
  testWidgets('El flujo del jefe conserva sus reuniones y su calendario', (
    t,
  ) async {
    await show(t, const AgendaJefeEquipoScreen(), width: 1400);
    expect(find.text('Agenda de equipo'), findsOneWidget);
    expect(find.text('Nueva reunión'), findsOneWidget);
    expect(
      queries.where(
        (q) =>
            q.path.endsWith('/visitas') ||
            q.path.endsWith('/planificacion_semanal_equipo'),
      ),
      isEmpty,
    );
    expect(
      t
          .widget<SfCalendar>(find.byType(SfCalendar))
          .dataSource!
          .appointments!
          .length,
      2,
    );
    expect(t.takeException(), isNull);
  });
}
