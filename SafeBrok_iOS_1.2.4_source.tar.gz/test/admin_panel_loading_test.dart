import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:safebrok_andalucia/features/admin/admin_panel_screen.dart';

void main() {
  final requests = <Uri>[];
  setUpAll(() async {
    SharedPreferences.setMockInitialValues({});
    await Supabase.initialize(
      url: 'https://example.supabase.co',
      anonKey: 'test',
      authOptions: const FlutterAuthClientOptions(
        autoRefreshToken: false,
        detectSessionInUri: false,
      ),
      httpClient: MockClient((request) async {
        requests.add(request.url);
        final profile =
            request.url.path.endsWith('/usuarios') &&
            request.url.queryParameters.containsKey('auth_id');
        return http.Response(
          jsonEncode(
            profile
                ? {
                    'id': '00000000-0000-0000-0000-000000000001',
                    'auth_id': '00000000-0000-0000-0000-000000000001',
                    'rol_usuario': 'administracion',
                    'nombre': 'Prueba',
                  }
                : [],
          ),
          200,
          request: request,
          headers: {
            'content-type': 'application/json',
            'content-range': '0-0/0',
          },
        );
      }),
    );
    String part(Object value) =>
        base64Url.encode(utf8.encode(jsonEncode(value))).replaceAll('=', '');
    final token =
        '${part({'alg': 'HS256'})}.${part({'sub': '00000000-0000-0000-0000-000000000001', 'exp': 4102444800})}.test';
    await Supabase.instance.client.auth.recoverSession(
      jsonEncode({
        'access_token': token,
        'refresh_token': 'test',
        'token_type': 'bearer',
        'expires_in': 3600,
        'expires_at': 4102444800,
        'user': {
          'id': '00000000-0000-0000-0000-000000000001',
          'aud': 'authenticated',
          'email': 'test@example.invalid',
          'created_at': '2026-01-01T00:00:00Z',
          'app_metadata': {},
          'user_metadata': {},
        },
      }),
    );
  });
  tearDownAll(() async => Supabase.instance.dispose());
  testWidgets(
    'Administración abre sin precargar otras secciones y no repite consultas al redibujar',
    (tester) async {
      tester.view.physicalSize = const Size(1700, 1100);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      requests.clear();
      await tester.pumpWidget(const MaterialApp(home: AdminPanelScreen()));
      await tester.pumpAndSettle();
      expect(requests.where((u) => u.path.endsWith('/clientes')), isEmpty);
      expect(requests.where((u) => u.path.endsWith('/recibos')), isEmpty);
      final sales = requests.where((u) => u.path.endsWith('/ventas')).toList();
      expect(sales.length, 1);
      expect(sales.single.queryParametersAll['fecha_efecto']!.length, 2);
      expect(requests.where((u) => u.path.endsWith('/usuarios')).length, 1);
      final count = requests.length;
      tester.view.physicalSize = const Size(1750, 1100);
      await tester.pumpAndSettle();
      expect(requests.length, count);
      expect(tester.takeException(), isNull);
    },
  );
}
