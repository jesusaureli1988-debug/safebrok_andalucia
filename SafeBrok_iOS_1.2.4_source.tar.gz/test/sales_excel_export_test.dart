import 'package:excel/excel.dart';
import 'dart:convert';
import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:safebrok_andalucia/features/admin/sales_excel_export.dart';

void main() {
  test(
    'Los filtros de Excel abarcan todas las columnas y filas exportadas',
    () {
      for (final count in [0, 2, 1501]) {
        final bytes = SalesExcelExport.encode(
          List.generate(
            count,
            (i) => <String, dynamic>{'numero_poliza': 'POL-$i'},
          ),
        );
        final zip = ZipDecoder().decodeBytes(bytes);
        final xml = utf8.decode(
          zip.files
                  .singleWhere(
                    (file) => RegExp(
                      r'^xl/worksheets/sheet\d+\.xml$',
                    ).hasMatch(file.name),
                  )
                  .content
              as List<int>,
        );
        expect(xml, contains('<autoFilter ref="A1:L${count + 1}"/>'));
        expect(Excel.decodeBytes(bytes)['Ventas'].maxRows, count + 1);
      }
    },
  );
  final sales = <Map<String, dynamic>>[
    {
      'numero_poliza': '0001',
      'compania': 'ASISA',
      'categoria_producto': 'Salud',
      'agente_nombre': 'Agente A',
      'jefe_nombre': 'Equipo A',
      'fecha_efecto': '2026-10-01',
      'prima_anual': 1200.50,
    },
    {
      'numero_poliza': '0002',
      'compania': 'ASISA',
      'categoria_producto': 'Salud',
      'agente_nombre': 'Agente A',
      'jefe_nombre': 'Equipo A',
      'fecha_efecto': '2026-10-31T23:59:59',
      'prima_anual': 999,
    },
    {
      'numero_poliza': '0003',
      'compania': 'OTRA',
      'categoria_producto': 'Hogar',
      'agente_nombre': 'Agente B',
      'jefe_nombre': 'Equipo B',
      'fecha_efecto': '2026-10-15',
    },
    {
      'numero_poliza': '0004',
      'compania': 'ASISA',
      'fecha_efecto': '2026-11-01',
    },
    {'numero_poliza': '0005', 'compania': 'ASISA', 'fecha_efecto': null},
  ];

  test(
    'Excel abre Ventas, sin hoja vacía, y contiene exactamente el filtro',
    () {
      final filtered = SalesExcelExport.filter(
        sales,
        company: 'ASISA',
        category: 'Salud',
        agent: 'Agente A',
        manager: 'Equipo A',
        from: DateTime(2026, 10, 1),
        until: DateTime(2026, 10, 31),
      );
      final book = Excel.decodeBytes(SalesExcelExport.encode(filtered));
      expect(book.tables.keys, ['Ventas']);
      expect(book.getDefaultSheet(), 'Ventas');
      final rows = book['Ventas'].rows;
      expect(rows.length, 3);
      expect(rows[1][0]!.value, TextCellValue('0001'));
      expect(rows[2][0]!.value, TextCellValue('0002'));
      expect(rows[1][4]!.value, DoubleCellValue(1200.50));
      expect(rows[1][8]!.value, TextCellValue('Agente A'));
    },
  );

  test(
    'Filtros individuales y fechas excluyen otros registros sin mutar el origen',
    () {
      for (final result in [
        SalesExcelExport.filter(sales, category: 'Hogar'),
        SalesExcelExport.filter(sales, agent: 'Agente B'),
        SalesExcelExport.filter(sales, manager: 'Equipo B'),
      ]) {
        expect(result.map((r) => r['numero_poliza']), ['0003']);
      }
      expect(
        SalesExcelExport.filter(sales, until: DateTime(2026, 10, 1)).length,
        1,
      );
      expect(
        SalesExcelExport.filter(sales, from: DateTime(2026, 11, 1)).length,
        1,
      );
      expect(SalesExcelExport.filter(sales).length, sales.length);
      expect(sales.length, 5);
    },
  );

  test(
    'Exporta más de una página y mantiene textos como texto, nunca fórmulas',
    () {
      final rows = List.generate(
        1501,
        (i) => <String, dynamic>{'numero_poliza': '=$i', 'comision': '12,50'},
      );
      final book = Excel.decodeBytes(SalesExcelExport.encode(rows));
      expect(book['Ventas'].maxRows, 1502);
      expect(book['Ventas'].rows.last[0]!.value, TextCellValue('=1500'));
      expect(book['Ventas'].rows.last[6]!.value, DoubleCellValue(12.50));
    },
  );
}
