import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:safebrok_andalucia/core/auth/app_role.dart';
import 'package:safebrok_andalucia/features/home/home_screen.dart';
import 'package:safebrok_andalucia/features/team/mis_equipos_jefe_ventas_screen.dart';
import 'package:safebrok_andalucia/features/business/cuadro_mandos_screen.dart';
import 'package:safebrok_andalucia/features/business/plan_comercial_anual_screen.dart';
import 'package:safebrok_andalucia/features/business/bi_rentabilidad_screen.dart';
import 'package:safebrok_andalucia/features/business/cierres_produccion_screen.dart';
import 'package:safebrok_andalucia/features/clients/my_clients_screen.dart';
import 'package:safebrok_andalucia/features/director_nacional/director_nacional_usuarios_screen.dart';

void main() {
  const own = '00000000-0000-0000-0000-000000000001';
  const other = '00000000-0000-0000-0000-000000000002';
  var role = 'administracion';
  final requests = <Uri>[];
  Map<String, dynamic> profile() => {
    'id': 'root',
    'auth_id': own,
    'rol_usuario': role,
    'nombre': 'Responsable',
    'parent_id': null,
    'estado': 'activo',
  };
  setUpAll(() async {
    SharedPreferences.setMockInitialValues({});
    await Supabase.initialize(
      url: 'https://example.supabase.co',
      anonKey: 'test',
      authOptions: const FlutterAuthClientOptions(
        autoRefreshToken: false,
        detectSessionInUri: false,
      ),
      httpClient: MockClient((r) async {
        requests.add(r.url);
        dynamic rows = [];
        final single =
            r.headers['Accept']?.contains('vnd.pgrst.object') ?? false;
        if (r.url.path.endsWith('/usuarios')) {
          rows = (r.url.queryParameters['auth_id']?.startsWith('eq.') ?? false)
              ? profile()
              : [
                  profile(),
                  {
                    'id': 'outside',
                    'auth_id': other,
                    'parent_id': null,
                    'rol_usuario': 'director_zona',
                    'nombre': 'Director ajeno',
                    'estado': 'activo',
                  },
                ];
        } else if (r.url.path.endsWith('/cierres_produccion') &&
            r.url.queryParameters.containsKey('fecha_desde')) {
          rows = null;
        } else if (r.url.path.endsWith('/clientes')) {
          rows = [
            {
              'id': 1,
              'auth_id': other,
              'nombre': 'Cliente global',
              'created_at': '2026-01-01',
            },
          ];
        } else if (single) {
          rows = null;
        }
        return http.Response(
          jsonEncode(rows),
          200,
          request: r,
          headers: {'content-type': 'application/json'},
        );
      }),
    );
    String part(Object v) =>
        base64Url.encode(utf8.encode(jsonEncode(v))).replaceAll('=', '');
    await Supabase.instance.client.auth.recoverSession(
      jsonEncode({
        'access_token':
            '${part({'alg': 'HS256'})}.${part({'sub': own, 'exp': 4102444800})}.test',
        'refresh_token': 'test',
        'token_type': 'bearer',
        'expires_in': 3600,
        'expires_at': 4102444800,
        'user': {
          'id': own,
          'aud': 'authenticated',
          'email': 'test@example.invalid',
          'created_at': '2026-01-01T00:00:00Z',
          'app_metadata': {},
          'user_metadata': {},
        },
      }),
    );
  });
  tearDownAll(() async => Supabase.instance.dispose());
  setUp(() {
    requests.clear();
    role = 'administracion';
  });
  Future<void> show(WidgetTester t, Widget screen) async {
    t.view.physicalSize = const Size(1700, 1400);
    t.view.devicePixelRatio = 1;
    addTearDown(t.view.resetPhysicalSize);
    addTearDown(t.view.resetDevicePixelRatio);
    await t.pumpWidget(MaterialApp(home: screen));
    await t.pumpAndSettle();
  }

  test(
    'El acceso nacional admite administración y sus alias y excluye los otros perfiles',
    () {
      for (final r in [
        'administracion',
        'admin',
        'administrador',
        'director_nacional',
      ]) {
        expect(AppRole.hasNationalAccess(r), isTrue);
      }
      for (final r in [
        'agente',
        'jefe_equipo',
        'jefe_ventas',
        'director_zona',
        '',
        'desconocido',
      ]) {
        expect(AppRole.hasNationalAccess(r), isFalse);
      }
      expect(AppRole.from('admin'), AppRole.administracion);
    },
  );
  for (final r in ['administracion', 'director_nacional']) {
    testWidgets('$r dispone de los accesos nacionales en Inicio', (t) async {
      role = r;
      await show(t, HomeScreen(role: r));
      for (final title in [
        'Plan Comercial Anual',
        'KPIs Globales',
        'Clientes Globales',
        'Cuadro de mandos',
        'Control Equipos',
      ]) {
        expect(find.text(title), findsOneWidget);
      }
      await t.pumpWidget(const MaterialApp(home: SizedBox()));
      await t.pumpAndSettle();
    });
    testWidgets(
      '$r puede abrir cierres y rentabilidad desde Cuadro de mandos',
      (t) async {
        role = r;
        await show(t, const CuadroMandosScreen());
        expect(find.text('Cierres de producción'), findsWidgets);
        expect(find.text('BI de Rentabilidad'), findsWidgets);
        expect(find.text('Acceso restringido'), findsNothing);
      },
    );
    testWidgets('$r carga la cartera global y usuarios fuera de su rama', (
      t,
    ) async {
      role = r;
      await show(t, const MyClientsScreen());
      expect(find.text('Cartera global de toda la compañía'), findsOneWidget);
      final query = requests.singleWhere((u) => u.path.endsWith('/clientes'));
      expect(query.queryParameters['auth_id'], contains(other));
      await show(t, const DirectorNacionalUsuariosScreen());
      await t.scrollUntilVisible(
        find.textContaining('Director ajeno'),
        500,
        scrollable: find.byType(Scrollable).first,
      );
      expect(find.textContaining('Director ajeno'), findsWidgets);
    });
    testWidgets('$r entra al plan anual con las pestañas nacionales', (
      t,
    ) async {
      role = r;
      await show(t, const PlanComercialAnualScreen());
      expect(find.text('Fijar objetivos'), findsOneWidget);
      expect(
        requests.any((u) => u.path.endsWith('/objetivos_comerciales_anuales')),
        isTrue,
      );
    });
    testWidgets('$r puede cargar cierres y BI sin bloqueo interno', (t) async {
      role = r;
      await show(t, const CierresProduccionScreen());
      expect(find.text('Acceso exclusivo'), findsNothing);
      expect(
        requests.any((u) => u.path.endsWith('/cierres_produccion')),
        isTrue,
      );
      await show(t, const BiRentabilidadScreen());
      expect(find.textContaining('Acceso exclusivo'), findsNothing);
      expect(
        requests.any((u) => u.path.endsWith('/comisiones_aseguradoras')),
        isTrue,
      );
    });
  }
  testWidgets(
    'Administración ve las estructuras comerciales aunque no tenga agentes asignados',
    (t) async {
      await show(t, const MisEquiposJefeVentasScreen());
      await t.scrollUntilVisible(
        find.textContaining('Director ajeno').first,
        400,
        scrollable: find.byType(Scrollable).first,
      );
      expect(find.textContaining('Director ajeno'), findsWidgets);
      expect(find.text('Sin estructura disponible'), findsNothing);
    },
  );
  testWidgets('Un agente sigue sin poder abrir cierres ni BI', (t) async {
    role = 'agente';
    await show(t, const CierresProduccionScreen());
    expect(find.text('Acceso exclusivo'), findsOneWidget);
    expect(
      requests.any((u) => u.path.endsWith('/cierres_produccion')),
      isFalse,
    );
    await show(t, const BiRentabilidadScreen());
    expect(find.textContaining('Acceso exclusivo'), findsOneWidget);
    expect(
      requests.any((u) => u.path.endsWith('/comisiones_aseguradoras')),
      isFalse,
    );
  });
}
