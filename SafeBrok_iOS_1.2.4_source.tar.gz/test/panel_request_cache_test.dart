import 'dart:async';
import 'package:flutter_test/flutter_test.dart';
import 'package:safebrok_andalucia/features/admin/panel_request_cache.dart';

void main() {
  test('Rebuilds comparten una petición pendiente y su resultado', () async {
    final cache = PanelRequestCache();
    final response = Completer<int>();
    var calls = 0;
    Future<int> load() {
      calls++;
      return response.future;
    }

    final a = cache.get('ventas', load);
    final b = cache.get('ventas', load);
    expect(identical(a, b), isTrue);
    expect(calls, 1);
    response.complete(42);
    expect(await a, 42);
    expect(await cache.get('ventas', load), 42);
    expect(calls, 1);
  });
  test(
    'Un fallo permite reintento y las instancias no mezclan usuarios',
    () async {
      final cache = PanelRequestCache();
      await expectLater(
        cache.get<int>('ventas', () => throw StateError('red')),
        throwsStateError,
      );
      expect(await cache.get('ventas', () async => 2), 2);
      expect(await PanelRequestCache().get('ventas', () async => 99), 99);
    },
  );
  test(
    'Guardar o cambiar ámbito invalida incluso peticiones en vuelo',
    () async {
      final cache = PanelRequestCache();
      final old = Completer<int>();
      final a = cache.get('ventas', () => old.future);
      cache.clear();
      final b = cache.get('ventas', () async => 8);
      old.complete(3);
      expect(await a, 3);
      expect(await b, 8);
      expect(await cache.get('ventas', () async => 999), 8);
      expect(await cache.get('recibos:COBRADO', () async => 10), 10);
      expect(await cache.get('recibos:PENDIENTE', () async => 20), 20);
    },
  );
}
