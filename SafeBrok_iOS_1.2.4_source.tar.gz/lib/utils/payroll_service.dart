import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:safebrok_andalucia/core/production/premium_weighting.dart';
import 'package:safebrok_andalucia/core/production/production_period_service.dart';

class PayrollService {
  static final supabase = Supabase.instance.client;

  // =========================
  // 📅 PERIODO 24 → 24 REAL
  // =========================
  static DateTime startPeriod(int mes, int anio) {
    return DateTime(anio, mes - 1, 24);
  }

  static DateTime endPeriod(int mes, int anio) {
    return DateTime(anio, mes, 23, 59, 59);
  }

  // =========================
  // 🧮 GENERAR NÓMINA AGENTE
  // =========================
  static Future<void> generarNominaAgente({
    required String authId,
    required int mes,
    required int anio,
  }) async {
    final period = await ProductionPeriodService.instance.forMonth(
      year: anio,
      month: mes,
    );
    final inicio = period.start;
    final fin = period.endExclusive;

    // =========================
    // 🔥 VENTAS DEL PERIODO
    // =========================
    final ventas = await supabase
        .from('ventas')
        .select()
        .eq('agente_auth_id', authId)
        .gte('fecha_efecto', inicio.toIso8601String())
        .lt('fecha_efecto', fin.toIso8601String());

    double primaBrutaTotal = 0;
    double primaNetaTotal = 0;
    double comisiones = 0;
    double primasDecesosVida = 0;

    for (final v in ventas) {
      final bruta = PremiumWeighting.gross(Map<String, dynamic>.from(v));
      final neta = PremiumWeighting.net(Map<String, dynamic>.from(v));
      final com = (v['comision'] ?? 0);

      primaBrutaTotal += bruta;
      primaNetaTotal += neta;
      comisiones += (com is num) ? com.toDouble() : 0;

      final producto = (v['producto'] ?? '').toString();

      if (producto == 'Decesos' || producto == 'Vida') {
        primasDecesosVida += neta;
      }
    }

    // =========================
    // 📊 % DECESOS + VIDA
    // =========================
    double porcentajeDecesosVida = 0;

    if (primaNetaTotal > 0) {
      porcentajeDecesosVida = (primasDecesosVida / primaNetaTotal) * 100;
    }

    // =========================
    // 💰 RAPPEL
    // =========================
    double rappel = 0;

    if (porcentajeDecesosVida >= 30) {
      if (primaNetaTotal >= 12000) {
        rappel = 1500;
      } else if (primaNetaTotal >= 9000) {
        rappel = 1200;
      } else if (primaNetaTotal >= 6000) {
        rappel = 800;
      } else if (primaNetaTotal >= 4000) {
        rappel = 600;
      } else if (primaNetaTotal >= 2500) {
        rappel = 400;
      } else if (primaNetaTotal >= 1500) {
        rappel = 200;
      }
    }

    // =========================
    // 💵 TOTAL
    // =========================
    final totalCobrar = comisiones + rappel;

    // =========================
    // 💾 GUARDAR NÓMINA
    // =========================
    await supabase.from('nominas_mensuales').insert({
      'auth_id': authId,
      'mes': mes,
      'anio': anio,
      'rol': 'agente',

      'primas_total': primaNetaTotal,
      'prima_bruta_total': primaBrutaTotal,
      'prima_neta_total': primaNetaTotal,

      'primas_decesos_vida': primasDecesosVida,
      'porcentaje_decesos_vida': porcentajeDecesosVida,

      'comisiones': comisiones,
      'rappel': rappel,
      'total_cobrar': totalCobrar,

      'sueldo_fijo': 0,
    });
  }
}
