import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AddContactosDiariosScreen extends StatefulWidget {
  const AddContactosDiariosScreen({super.key});

  @override
  State<AddContactosDiariosScreen> createState() =>
      _AddContactosDiariosScreenState();
}

class _AddContactosDiariosScreenState extends State<AddContactosDiariosScreen> {
  final supabase = Supabase.instance.client;
  final _formKey = GlobalKey<FormState>();

  bool loading = false;
  bool showErrors = false;

  int frios = 0;
  int telefonicos = 0;
  int positivos = 0;
  int negativos = 0;

  final friosController = TextEditingController();
  final telefonicosController = TextEditingController();
  final positivosController = TextEditingController();
  final negativosController = TextEditingController();

  List<TextEditingController> nombres = [];
  List<TextEditingController> telefonos = [];

  int get totalContactos => frios + telefonicos;
  double get progreso => (positivos / 6).clamp(0.0, 1.0);
  bool get objetivoCumplido => positivos >= 6;

  @override
  void dispose() {
    friosController.dispose();
    telefonicosController.dispose();
    positivosController.dispose();
    negativosController.dispose();

    for (final c in nombres) {
      c.dispose();
    }

    for (final c in telefonos) {
      c.dispose();
    }

    super.dispose();
  }

  void generarCamposPositivos(int value) {
    final count = value < 0 ? 0 : value;
    setState(() {
      while (nombres.length < count) {
        nombres.add(TextEditingController());
        telefonos.add(TextEditingController());
      }
      while (nombres.length > count) {
        final nombre = nombres.removeLast();
        final telefono = telefonos.removeLast();
        WidgetsBinding.instance.addPostFrameCallback((_) {
          nombre.dispose();
          telefono.dispose();
        });
      }
      positivos = count;
    });
  }

  bool validarPositivos() {
    for (int i = 0; i < positivos; i++) {
      if (nombres[i].text.trim().isEmpty || telefonos[i].text.trim().isEmpty) {
        return false;
      }
    }
    return true;
  }

  Future<void> guardar() async {
    if (loading) return;
    FocusScope.of(context).unfocus();

    setState(() => showErrors = true);

    final formOk = _formKey.currentState!.validate();
    final positivosOk = validarPositivos();

    if (!formOk || !positivosOk) {
      _snack('Rellena todos los campos obligatorios', const Color(0xFFB45309));
      return;
    }

    final user = supabase.auth.currentUser;
    if (user == null) {
      _snack('No hay usuario conectado', const Color(0xFFB42318));
      return;
    }

    setState(() => loading = true);

    try {
      final fecha = DateTime.now();

      final insert = await supabase.from('contactos_diarios').insert({
        'auth_id': user.id,
        'fecha': fecha.toIso8601String(),
        'contactos_frios': frios,
        'contactos_telefonicos': telefonicos,
        'contactos_positivos': positivos,
        'contactos_negativos': negativos,
      }).select();

      final contactoId = insert[0]['id'];

      for (int i = 0; i < positivos; i++) {
        await supabase.from('contactos_positivos_detalle').insert({
          'contacto_id': contactoId,
          'nombre': nombres[i].text.trim(),
          'telefono': telefonos[i].text.trim(),
        });
      }

      if (mounted) Navigator.pop(context);
    } catch (_) {
      if (mounted) {
        setState(() => loading = false);
        _snack('Error al guardar los contactos', const Color(0xFFB42318));
      }
    }
  }

  void _snack(String text, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: const Color(0xFFF1F5FA),
        behavior: SnackBarBehavior.floating,
        content: Text(
          text,
          style: TextStyle(color: color, fontWeight: FontWeight.w800),
        ),
      ),
    );
  }

  int _parse(String value) {
    return int.tryParse(value.trim()) ?? 0;
  }

  void _syncNumbers() {
    frios = _parse(friosController.text);
    telefonicos = _parse(telefonicosController.text);
    negativos = _parse(negativosController.text);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFFFFF),
      extendBodyBehindAppBar: false,

      appBar: AppBar(
        backgroundColor: const Color(0xFFF5F7FC),
        foregroundColor: const Color(0xFF13244D),
        elevation: 0,
        title: const Text(
          'Nuevo registro',
          style: TextStyle(
            color: const Color(0xFF071A3A),
            fontWeight: FontWeight.w900,
          ),
        ),
      ),

      body: Stack(
        children: [
          const _PremiumBackground(),

          SafeArea(
            child: Form(
              key: _formKey,
              child: Stack(
                children: [
                  SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 118),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _header(),
                        const SizedBox(height: 14),
                        _summaryPanel(),
                        const SizedBox(height: 16),

                        _sectionTitle(
                          'Actividad del día',
                          'Introduce la producción real realizada hoy.',
                        ),

                        const SizedBox(height: 12),

                        _numberInput(
                          controller: friosController,
                          label: 'Contactos fríos',
                          icon: Icons.ac_unit_rounded,
                          color: const Color(0xFF0369A1),
                          onChanged: (_) {
                            setState(() {
                              _syncNumbers();
                            });
                          },
                        ),

                        _numberInput(
                          controller: telefonicosController,
                          label: 'Contactos telefónicos',
                          icon: Icons.phone_in_talk_rounded,
                          color: const Color(0xFFB45309),
                          onChanged: (_) {
                            setState(() {
                              _syncNumbers();
                            });
                          },
                        ),

                        _numberInput(
                          controller: positivosController,
                          label: 'Contactos positivos',
                          icon: Icons.thumb_up_alt_rounded,
                          color: const Color(0xFF198754),
                          onChanged: (v) {
                            _syncNumbers();
                            generarCamposPositivos(_parse(v));
                          },
                        ),

                        _numberInput(
                          controller: negativosController,
                          label: 'Contactos negativos',
                          icon: Icons.thumb_down_alt_rounded,
                          color: const Color(0xFFB42318),
                          onChanged: (_) {
                            setState(() {
                              _syncNumbers();
                            });
                          },
                        ),

                        const SizedBox(height: 18),

                        if (positivos > 0) ...[
                          _sectionTitle(
                            'Detalle de positivos',
                            'Añade nombre y teléfono de cada positivo.',
                          ),
                          const SizedBox(height: 12),
                        ],

                        for (int i = 0; i < positivos; i++) _positivoCard(i),
                      ],
                    ),
                  ),

                  _bottomButton(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _header() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [const Color(0xFFDCE5F2), const Color(0xFFF1F5FA)],
            ),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: const Color(0xFFDCE5F2)),
          ),
          child: Row(
            children: [
              Container(
                height: 58,
                width: 58,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [const Color(0xFF2454D3), Color(0xFF2D7DFF)],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF2454D3).withOpacity(0.25),
                      blurRadius: 25,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.edit_note_rounded,
                  color: Colors.white,
                  size: 32,
                ),
              ),

              const SizedBox(width: 16),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Registro diario',
                      style: TextStyle(
                        color: const Color(0xFF071A3A),
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.5,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      'Objetivo recomendado: 6 contactos positivos diarios',
                      style: TextStyle(
                        color: const Color(0xFF53627A),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _summaryPanel() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFF1F5FA),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFDCE5F2)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: _miniKpi(
                  'Base',
                  totalContactos.toString(),
                  Icons.groups_rounded,
                  const Color(0xFF2454D3),
                ),
              ),
              Expanded(
                child: _miniKpi(
                  'Positivos',
                  positivos.toString(),
                  Icons.verified_rounded,
                  const Color(0xFF198754),
                ),
              ),
              Expanded(
                child: _miniKpi(
                  'Negativos',
                  negativos.toString(),
                  Icons.close_rounded,
                  const Color(0xFFB42318),
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          Row(
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(30),
                  child: LinearProgressIndicator(
                    minHeight: 10,
                    value: progreso,
                    backgroundColor: const Color(0xFFF1F5FA),
                    color: objetivoCumplido
                        ? const Color(0xFF198754)
                        : const Color(0xFFB45309),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Text(
                '$positivos/6',
                style: TextStyle(
                  color: objetivoCumplido
                      ? const Color(0xFF198754)
                      : const Color(0xFFB45309),
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _miniKpi(String label, String value, IconData icon, Color color) {
    return Column(
      children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(height: 6),
        Text(
          value,
          style: const TextStyle(
            color: const Color(0xFF071A3A),
            fontWeight: FontWeight.w900,
            fontSize: 18,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: const Color(0xFF53627A),
            fontWeight: FontWeight.w600,
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Widget _sectionTitle(String title, String subtitle) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: const Color(0xFF071A3A),
            fontSize: 17,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          subtitle,
          style: TextStyle(
            color: const Color(0xFF53627A),
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget _numberInput({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    required Color color,
    required Function(String) onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: controller,
        keyboardType: TextInputType.number,
        style: const TextStyle(
          color: const Color(0xFF071A3A),
          fontWeight: FontWeight.w800,
        ),
        onChanged: onChanged,
        validator: (value) {
          if (value == null || value.trim().isEmpty) {
            return 'Obligatorio';
          }

          final n = int.tryParse(value.trim());
          if (n == null || n < 0) {
            return 'Introduce un número válido';
          }

          return null;
        },
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: const Color(0xFF53627A)),
          prefixIcon: Icon(icon, color: color),
          filled: true,
          fillColor: const Color(0xFFF1F5FA),
          errorStyle: const TextStyle(
            color: const Color(0xFFB45309),
            fontWeight: FontWeight.w700,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide(color: const Color(0xFFDCE5F2)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide(color: color.withOpacity(0.75), width: 1.4),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: const BorderSide(color: const Color(0xFFB45309)),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: const BorderSide(color: const Color(0xFFB45309)),
          ),
        ),
      ),
    );
  }

  Widget _positivoCard(int index) {
    final hasError =
        showErrors &&
        (nombres[index].text.trim().isEmpty ||
            telefonos[index].text.trim().isEmpty);

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [const Color(0xFFDCE5F2), const Color(0xFFF1F5FA)],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: hasError
              ? const Color(0xFFB45309).withOpacity(0.65)
              : const Color(0xFF198754).withOpacity(0.18),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                height: 38,
                width: 38,
                decoration: BoxDecoration(
                  color: const Color(0xFF198754).withOpacity(0.14),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(
                  Icons.person_add_alt_1_rounded,
                  color: const Color(0xFF198754),
                  size: 21,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Positivo ${index + 1}',
                  style: const TextStyle(
                    color: const Color(0xFF071A3A),
                    fontWeight: FontWeight.w900,
                    fontSize: 15,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          _detailInput(
            controller: nombres[index],
            label: 'Nombre completo',
            icon: Icons.person_rounded,
            keyboardType: TextInputType.name,
          ),

          const SizedBox(height: 10),

          _detailInput(
            controller: telefonos[index],
            label: 'Teléfono',
            icon: Icons.phone_rounded,
            keyboardType: TextInputType.phone,
          ),
        ],
      ),
    );
  }

  Widget _detailInput({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    required TextInputType keyboardType,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      style: const TextStyle(
        color: const Color(0xFF071A3A),
        fontWeight: FontWeight.w700,
      ),
      onChanged: (_) => setState(() {}),
      validator: (value) {
        if (value == null || value.trim().isEmpty) {
          return 'Obligatorio';
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: const Color(0xFF53627A)),
        prefixIcon: Icon(icon, color: const Color(0xFF2454D3)),
        filled: true,
        fillColor: const Color(0xFFF1F5FA),
        errorStyle: const TextStyle(
          color: const Color(0xFFB45309),
          fontWeight: FontWeight.w700,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: const Color(0xFFF1F5FA)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: const Color(0xFF2454D3)),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: const Color(0xFFB45309)),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: const Color(0xFFB45309)),
        ),
      ),
    );
  }

  Widget _bottomButton() {
    return Positioned(
      bottom: 18,
      left: 16,
      right: 16,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFFFFFFFF).withOpacity(0.76),
              border: Border.all(color: const Color(0xFFF1F5FA)),
              borderRadius: BorderRadius.circular(22),
            ),
            child: SizedBox(
              height: 56,
              child: ElevatedButton(
                onPressed: loading ? null : guardar,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF2454D3),
                  disabledBackgroundColor: const Color(0xFFDCE5F2),
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(17),
                  ),
                ),
                child: loading
                    ? const SizedBox(
                        height: 24,
                        width: 24,
                        child: CircularProgressIndicator(
                          strokeWidth: 2.6,
                          color: Colors.white,
                        ),
                      )
                    : const Text(
                        'GUARDAR CONTACTOS',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.4,
                        ),
                      ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _PremiumBackground extends StatelessWidget {
  const _PremiumBackground();
  @override
  Widget build(BuildContext context) => const SizedBox.expand(
    child: DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFFF5F7FC), Color(0xFFEAF1FF)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
    ),
  );
}
