import 'package:flutter/material.dart';
import 'referencias_screen.dart';

/// Legacy entry point uses the same form as Referencias viables → Nueva.
class ReferenciaDiariaScreen extends StatelessWidget {
  const ReferenciaDiariaScreen({super.key});

  @override
  Widget build(BuildContext context) =>
      const ReferenciasScreen(abrirNueva: true);
}
