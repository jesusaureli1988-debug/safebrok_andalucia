import 'package:flutter/material.dart';
import '../team/agenda_jefe_equipo_screen.dart';

class AgendaScreen extends StatelessWidget {
  const AgendaScreen({super.key});

  @override
  Widget build(BuildContext context) =>
      const AgendaJefeEquipoScreen(personal: true);
}
