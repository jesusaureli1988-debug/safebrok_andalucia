/// Route-local futures: rebuilds share in-flight requests and loaded results.
/// Never shared between sessions. Failed requests remain retryable.
class PanelRequestCache {
  final Map<String, Future<dynamic>> _requests = {};

  Future<T> get<T>(String key, Future<T> Function() load) {
    final existing = _requests[key];
    if (existing != null) return existing as Future<T>;
    late final Future<T> request;
    request = Future<T>.sync(load).then(
      (value) => value,
      onError: (Object e, StackTrace stack) {
        if (identical(_requests[key], request)) _requests.remove(key);
        Error.throwWithStackTrace(e, stack);
      },
    );
    _requests[key] = request;
    return request;
  }

  void clear() => _requests.clear();
}
