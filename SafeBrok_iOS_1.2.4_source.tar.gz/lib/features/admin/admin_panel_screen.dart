import 'panel_request_cache.dart';
import 'sales_excel_export.dart';
import 'package:safebrok_andalucia/core/widgets/progressive_records.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:safebrok_andalucia/core/production/premium_weighting.dart';
import 'package:safebrok_andalucia/core/production/policy_sales_query.dart';
import 'package:safebrok_andalucia/core/import_excel_text.dart';
import 'package:safebrok_andalucia/core/import_policy_defaults.dart';
import 'package:file_picker/file_picker.dart';
import 'package:excel/excel.dart' as excel;
import 'package:supabase_flutter/supabase_flutter.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'dart:typed_data';
import 'dart:convert';
import 'dart:async';
import 'package:intl/intl.dart';
import 'package:open_filex/open_filex.dart';
import 'package:safebrok_andalucia/features/incorporaciones/incorporaciones_screen.dart';
import 'package:safebrok_andalucia/features/admin/usuarios_accesos_screen.dart';
import 'package:safebrok_andalucia/features/admin/ventas_sin_agentes_screen.dart';
import 'package:safebrok_andalucia/features/admin/policy_edit_dialog.dart';

class AdminPanelScreen extends StatefulWidget {
  const AdminPanelScreen({super.key});

  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen> {
  final supabase = Supabase.instance.client;
  final _polizasPreviewHorizontal = ScrollController();
  final _polizasPreviewVertical = ScrollController();

  final _panelRequests = PanelRequestCache();
  Future<void>? _receiptFiltersFuture;

  Future<T?> _showPanelDialog<T>({
    required BuildContext context,
    required WidgetBuilder builder,
    bool barrierDismissible = true,
  }) async {
    try {
      return await showDialog<T>(context: context, builder: builder,
          barrierDismissible: barrierDismissible);
    } finally {
      // A dialog may save/edit data. Refresh on return, never on filter changes.
      _panelRequests.clear();
      _agentesErpFuture = null;
      if (mounted) setState(() {});
    }
  }

  Future<void> _prepareReceiptFilters() async {
    try {
      await Future.wait([cargarFiltrosClientes(), cargarJefesFiltro()]);
    } catch (error) {
      _receiptFiltersFuture = null;
      debugPrint('No se pudieron cargar los filtros: $error');
    }
  }

  @override
  void initState() {
    super.initState();
    inicializarPermisosERP();
    _agentesScrollController.addListener(_cargarSiguienteBloqueAgentes);
  }

  @override
  void dispose() {
    _polizasPreviewHorizontal.dispose();
    _polizasPreviewVertical.dispose();
    _buscarAgentesController.dispose();
    _agentesScrollController.dispose();
    super.dispose();
  }

  double produccionTotal = 0;
  int ventasTotales = 0;

  Map<String, dynamic>? usuarioActualERP;
  List<String> authIdsPermitidosERP = [];
  bool cargandoPermisosERP = true;
  bool accesoAdminPanelERP = false;

  double recibosCobrados = 0;
  double recibosDevueltos = 0;

  double produccionVsMesAnterior = 0;
  double ventasVsMesAnterior = 0;
  double cobradosVsMesAnterior = 0;
  double devueltosVsMesAnterior = 0;

  final TextEditingController polizaCtrl = TextEditingController();
  final TextEditingController clienteCtrl = TextEditingController();
  final TextEditingController importeCtrl = TextEditingController();
  final TextEditingController companiaCtrl = TextEditingController();
  final TextEditingController estadoCtrl = TextEditingController();
  final TextEditingController fechaCtrl = TextEditingController();
  final TextEditingController numeroReciboCtrl = TextEditingController();

  int importProgress = 0;
  int importTotal = 0;

  List<List<dynamic>> excelPreview = [];

  List<String> headers = [];
  List<List<dynamic>> dataRows = [];

  List<Map<String, dynamic>> recibos = [];
  bool loadingRecibos = false;

  Map<String, String> columnMapping = {};

  List<String> polizasHeaders = [];
  List<List<dynamic>> polizasRows = [];
  List<List<dynamic>> polizasPreview = [];

  Map<String, String> polizasColumnMapping = {};

  int polizasImportProgress = 0;
  int polizasImportTotal = 0;
  bool importingPolizas = false;
  bool validandoPolizas = false;
  String? resultadoCargaPolizas;
  String? informeCargaPolizasPath;
  int polizasGuardadasCarga = 0;
  List<Map<String, dynamic>> erroresCargaPolizas = [];
  List<Map<String, dynamic>> polizasNuevasValidadas = [];
  List<Map<String, dynamic>> polizasSinAgente = [];
  List<Map<String, dynamic>> polizasPendientesAsignacion = [];
  List<Map<String, dynamic>> polizasExistentesValidadas = [];

  final List<String> camposCargaPolizas = [
    "cliente.nombre",
    "cliente.apellidos",
    "aux.apellido_1",
    "aux.apellido_2",
    "aux.movil",
    "cliente.telefono",
    "cliente.email",
    "cliente.codigo_postal",
    "cliente.provincia",
    "cliente.poblacion",
    "cliente.direccion",
    "cliente.numero",
    "cliente.dni",

    "venta.agente_auth_id",
    "aux.colaborador_id",
    "aux.colaborador_nombre",
    "venta.producto",
    "venta.compania",
    "venta.forma_pago",
    "venta.precio",
    "venta.numero_asegurados",
    "venta.fecha_efecto",
    "venta.prima_anual",
    "venta.categoria_producto",
    "venta.prima_anual_bruta",
    "venta.prima_anual_neta",
    "venta.comision",
    "venta.numero_poliza",
    "venta.estado_poliza",
  ];

  bool isImporting = false;
  double progress = 0;

  final List<String> camposCargaRecibos = [
    "numero_recibo",
    "poliza",
    "cliente",
    "importe",
    "compania",
    "estado",
    "fecha",
    "agente",
    "motivo",
    "estado_recibo",
    "fecha_anulacion",
    "motivo_anulacion",
    "observaciones_anulacion",
    "anulacion_id",
    "anulado_por",
  ];

  String tipoReciboSeleccionado = "all";

  String? filtroCompania;
  String? filtroAgente;
  String? filtroEstado;
  String? filtroJefeEquipo;

  DateTime? fechaDesde;
  DateTime? fechaHasta;

  List<String> listaAgentes = [];
  List<String> listaJefes = [];
  List<String> listaCompanias = [];

  String? filtroVentaCompania;
  String? filtroVentaCategoria;

  DateTime? ventaFechaDesde;
  DateTime? ventaFechaHasta;

  List<String> listaVentaCompanias = [];
  List<String> listaVentaCategorias = [];

  String? filtroVentaAgente;
  String? filtroVentaJefe;

  List<String> listaVentaAgentes = [];
  List<String> listaVentaJefes = [];

  String modoCarga = '';
  String selectedMenu = "dashboard";

  Future<List<Map<String, dynamic>>>? _agentesErpFuture;
  final TextEditingController _buscarAgentesController =
      TextEditingController();
  final ScrollController _agentesScrollController = ScrollController();
  String _filtroEstadoAgentes = 'TODOS';
  int _agentesVisibles = 10;

  Future<void> _recargarAgentesERP() async {
    final future = getAgentesERP();
    if (mounted) {
      setState(() {
        _agentesVisibles = 10;
        _agentesErpFuture = future;
      });
    }
    await future;
  }

  void _cargarSiguienteBloqueAgentes() {
    if (!_agentesScrollController.hasClients) return;
    final posicion = _agentesScrollController.position;
    if (posicion.pixels < posicion.maxScrollExtent - 120) return;
    if (!mounted) return;
    setState(() => _agentesVisibles += 10);
  }

  Future<void> seleccionarExcel() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx', 'xls', 'csv'],
      withData: true,
    );

    if (result == null) return;

    final file = result.files.first;
    Uint8List? bytes = file.bytes;

    if (bytes == null && file.path != null) {
      bytes = await File(file.path!).readAsBytes();
    }

    if (bytes == null) return;

    headers.clear();
    dataRows.clear();
    excelPreview.clear();
    columnMapping.clear();

    if (file.extension?.toLowerCase() == 'csv') {
      final content = utf8.decode(bytes, allowMalformed: true);
      final lines = const LineSplitter()
          .convert(content)
          .where((line) => line.trim().isNotEmpty)
          .toList();
      if (lines.isEmpty) return;

      final separator = lines.first.contains(';') ? ';' : ',';
      headers = _parsearLineaCsv(
        lines.first,
        separator,
      ).map((value) => value.trim().toUpperCase()).toList();
      dataRows = lines
          .skip(1)
          .map((line) => _parsearLineaCsv(line, separator))
          .where(_filaReciboConDatos)
          .toList();
    } else {
      final archivoExcel = excel.Excel.decodeBytes(bytes);
      if (archivoExcel.tables.isEmpty) return;
      final rows = archivoExcel.tables.values.first.rows;
      if (rows.isEmpty) return;

      headers = rows.first
          .map((cell) => cell?.value.toString().trim().toUpperCase() ?? '')
          .toList();
      dataRows = rows
          .skip(1)
          .map((row) => row.map((cell) => cell?.value ?? '').toList())
          .where(_filaReciboConDatos)
          .toList();
    }

    autoDetectMapping();

    // Solo se limita la vista previa; se importan todas las filas.
    excelPreview = [headers, ...dataRows.take(80)];

    setState(() {});
  }

  Future<void> importarASupabase() async {
    await importarMasivoASupabase();
  }

  Future<void> insertarManual() async {
    print("🚀 INSERT MANUAL INICIADO");

    final supabase = Supabase.instance.client;
    final numeroRecibo = numeroReciboCtrl.text.trim().toUpperCase();

    if (numeroRecibo.isEmpty) {
      _mostrarMensajeRecibos("El número de recibo es obligatorio.");
      return;
    }

    final data = {
      'numero_recibo': numeroRecibo,
      'poliza': polizaCtrl.text,
      'cliente': clienteCtrl.text,
      'importe': double.tryParse(importeCtrl.text) ?? 0,
      'compania': companiaCtrl.text,
      'estado': estadoCtrl.text,
      'fecha': convertirFecha(fechaCtrl.text),
    };

    print("📦 DATA A INSERTAR:");
    print(data);

    try {
      final existente = await supabase
          .from('recibos')
          .select('id')
          .eq('numero_recibo', numeroRecibo)
          .limit(1)
          .maybeSingle();

      if (existente != null) {
        _mostrarMensajeRecibos(
          "Ese número de recibo ya existe. No se ha duplicado.",
        );
        return;
      }

      final response = await supabase.from('recibos').insert(data).select();

      print("✅ INSERT OK:");
      print(response);

      // El aviso se ejecuta después de guardar y gestiona internamente
      // cualquier error, por lo que nunca revierte la creación del recibo.
      _notificarRecibosDevueltos([data]);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Recibo guardado correctamente")),
      );
    } catch (e) {
      print("❌ ERROR INSERT MANUAL:");
      print(e);

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Error: $e")));
    }
  }

  String convertirFecha(String input) {
    try {
      final parts = input.split('/');

      if (parts.length == 3) {
        final day = parts[0];
        final month = parts[1];
        final year = parts[2];

        return "$year-$month-$day";
      }

      return input;
    } catch (e) {
      return input;
    }
  }

  Future<void> exportarExcel(List<Map<String, dynamic>> recibos) async {
    print("RECIBOS RECIBIDOS: ${recibos.length}");

    final excelFile = excel.Excel.createExcel();

    final sheet = excelFile['Recibos'];

    sheet.appendRow([
      excel.TextCellValue('Número de recibo'),
      excel.TextCellValue('Fecha'),
      excel.TextCellValue('Compañía'),
      excel.TextCellValue('Póliza'),
      excel.TextCellValue('Cliente'),
      excel.TextCellValue('Agente'),
      excel.TextCellValue('Importe'),
      excel.TextCellValue('Estado'),
    ]);

    for (final r in recibos) {
      sheet.appendRow([
        excel.TextCellValue(r['numero_recibo']?.toString() ?? ''),
        excel.TextCellValue(r['fecha']?.toString() ?? ''),
        excel.TextCellValue(r['compania']?.toString() ?? ''),
        excel.TextCellValue(r['poliza']?.toString() ?? ''),
        excel.TextCellValue(r['cliente']?.toString() ?? ''),
        excel.TextCellValue(r['agente']?.toString() ?? ''),
        excel.TextCellValue(r['importe']?.toString() ?? ''),
        excel.TextCellValue(r['estado']?.toString() ?? ''),
      ]);
    }
    print("FILAS EXCEL: ${sheet.maxRows}");
    final bytes = excelFile.save();
    excelFile.setDefaultSheet('Recibos');
    print("BYTES EXCEL: ${bytes?.length}");

    if (bytes == null) return;

    final dir = await getApplicationDocumentsDirectory();

    final file = File('${dir.path}/recibos.xlsx');

    await file.writeAsBytes(bytes, flush: true);

    await OpenFilex.open(file.path);
  }

  bool _filaReciboConDatos(List<dynamic> row) => row.any((cell) {
    final value = cleanExcelValue(cell);
    return value != null && value.toString().trim().isNotEmpty;
  });

  String? _normalizarEstadoImportado(String? value) {
    final estado = (value ?? '')
        .toLowerCase()
        .replaceAll('á', 'a')
        .replaceAll('é', 'e')
        .replaceAll('í', 'i')
        .replaceAll('ó', 'o')
        .replaceAll('ú', 'u')
        .trim()
        .replaceAll(RegExp(r'[_\s]+'), ' ');
    if (const {'cobrado', 'pagado', 'abonado'}.contains(estado)) {
      return 'COBRADO';
    }
    if (const {'devuelto', 'impagado', 'impago'}.contains(estado)) {
      return 'DEVUELTO';
    }
    if (const {'pendiente', 'pendiente de cobro'}.contains(estado)) {
      return 'PENDIENTE';
    }
    if (const {'en gestion', 'gestion'}.contains(estado)) {
      return 'En gestión';
    }
    if (const {'para baja', 'baja'}.contains(estado)) return 'PARA BAJA';
    return null;
  }

  Future<void> importarMasivoASupabase() async {
    if (dataRows.isEmpty) {
      _mostrarMensajeRecibos("Selecciona primero un archivo Excel o CSV.");
      return;
    }

    const camposObligatorios = <String>{
      'numero_recibo',
      'poliza',
      'importe',
      'estado',
      'fecha',
    };
    final camposFaltantes = camposObligatorios
        .where((campo) => !columnMapping.containsValue(campo))
        .toList();
    if (camposFaltantes.isNotEmpty) {
      _mostrarMensajeRecibos(
        'Falta mapear: ${camposFaltantes.join(', ')}. '
        'No se iniciará la carga hasta completar los campos obligatorios.',
      );
      return;
    }

    final cabecerasNormalizadas = headers
        .map(_normalizarCabeceraRecibo)
        .toList();
    if (cabecerasNormalizadas.toSet().length != cabecerasNormalizadas.length) {
      _mostrarMensajeRecibos(
        'El archivo contiene columnas repetidas. Renómbralas antes de importar.',
      );
      return;
    }

    final supabase = Supabase.instance.client;

    setState(() {
      isImporting = true;
      importProgress = 0;
      importTotal = dataRows.length;
      progress = 0;
    });

    var importados = 0;
    var actualizados = 0;
    var duplicados = 0;
    var errores = 0;
    final detallesError = <String>[];
    final preparados = <Map<String, dynamic>>[];
    final numerosDelArchivo = <String>{};
    final recibosInsertados = <Map<String, dynamic>>[];

    try {
      for (var rowIndex = 0; rowIndex < dataRows.length; rowIndex++) {
        try {
          final item = _crearReciboDesdeFila(dataRows[rowIndex]);
          final numero = item['numero_recibo'] as String;

          if (!numerosDelArchivo.add(numero)) {
            duplicados++;
          } else {
            preparados.add(item);
          }
        } catch (error) {
          errores++;
          if (detallesError.length < 5) {
            detallesError.add("Fila ${rowIndex + 2}: $error");
          }
        }

        if (mounted) {
          setState(() {
            importProgress = rowIndex + 1;
            progress = importProgress / importTotal;
          });
        }
      }

      final existentesResponse = await supabase
          .from('recibos')
          .select('id, numero_recibo, estado, estado_recibo')
          .not('numero_recibo', 'is', null);

      final existentesPorNumero = <String, Map<String, dynamic>>{};
      for (final existente in List<Map<String, dynamic>>.from(
        existentesResponse,
      )) {
        final numero =
            existente['numero_recibo']?.toString().trim().toUpperCase() ?? '';
        if (numero.isNotEmpty) existentesPorNumero[numero] = existente;
      }

      final nuevos = <Map<String, dynamic>>[];
      final cambiosADevuelto = <Map<String, dynamic>>[];

      for (final item in preparados) {
        final numero = item['numero_recibo'] as String;
        final existente = existentesPorNumero[numero];

        if (existente == null) {
          nuevos.add(item);
          continue;
        }

        // Si ya existía como pendiente/cobrado y el nuevo archivo lo marca
        // como devuelto, actualizamos el mismo registro sin duplicarlo.
        if (_esReciboDevuelto(item) && !_esReciboDevuelto(existente)) {
          cambiosADevuelto.add({
            'id_existente': existente['id'],
            'datos': item,
          });
        } else {
          duplicados++;
        }
      }

      for (final cambio in cambiosADevuelto) {
        final datos = Map<String, dynamic>.from(cambio['datos'] as Map);

        try {
          await supabase
              .from('recibos')
              .update(datos)
              .eq('id', cambio['id_existente']);
          actualizados++;
          recibosInsertados.add(datos);
        } catch (errorActualizacion) {
          errores++;
          if (detallesError.length < 5) {
            detallesError.add(
              "Recibo ${datos['numero_recibo']}: "
              "no se pudo actualizar ($errorActualizacion)",
            );
          }
        }
      }

      const batchSize = 200;
      for (var i = 0; i < nuevos.length; i += batchSize) {
        final fin = (i + batchSize < nuevos.length)
            ? i + batchSize
            : nuevos.length;
        final lote = nuevos.sublist(i, fin);

        try {
          await supabase.from('recibos').insert(lote);
          importados += lote.length;
          recibosInsertados.addAll(lote);
        } catch (_) {
          // Si una fila falla, se reintenta el lote individualmente.
          for (final recibo in lote) {
            try {
              await supabase.from('recibos').insert(recibo);
              importados++;
              recibosInsertados.add(recibo);
            } catch (errorFila) {
              errores++;
              if (detallesError.length < 5) {
                detallesError.add(
                  "Recibo ${recibo['numero_recibo']}: $errorFila",
                );
              }
            }
          }
        }
      }

      if (!mounted) return;

      // No se espera el resultado: las notificaciones no retrasan ni bloquean
      // la importación. El método captura sus propios errores.
      _notificarRecibosDevueltos(recibosInsertados);

      final detalle = detallesError.isEmpty
          ? ''
          : "\n${detallesError.join('\n')}";
      _mostrarMensajeRecibos(
        "Importación terminada. Nuevos: $importados · "
        "Actualizados a devuelto: $actualizados · "
        "Duplicados omitidos: $duplicados · Errores: $errores$detalle",
      );
    } catch (error) {
      if (!mounted) return;
      _mostrarMensajeRecibos("No se pudo completar la importación: $error");
    } finally {
      if (mounted) {
        setState(() {
          isImporting = false;
          progress = 1;
        });
      }
    }
  }

  Map<String, dynamic> _crearReciboDesdeFila(List<dynamic> row) {
    final item = <String, dynamic>{};

    for (var index = 0; index < headers.length; index++) {
      final mapped = columnMapping[headers[index]];
      if (mapped == null || index >= row.length) continue;

      final value = cleanExcelValue(row[index]);
      if (value == null || value.toString().trim().isEmpty) continue;

      if (mapped == 'importe') {
        final importe = toDoublePoliza(value);
        if (importe == null) {
          throw FormatException("importe no válido: $value");
        }
        item[mapped] = importe;
      } else if (mapped == 'fecha' || mapped == 'fecha_anulacion') {
        final fecha = toFechaSupabase(value);
        if (fecha == null || DateTime.tryParse(fecha) == null) {
          throw FormatException("$mapped no válida: $value");
        }
        item[mapped] = fecha;
      } else {
        item[mapped] = value.toString().trim();
      }
    }

    final numero = item['numero_recibo']?.toString().trim().toUpperCase() ?? '';
    if (numero.isEmpty) {
      throw const FormatException('numero_recibo está vacío');
    }
    item['numero_recibo'] = numero;

    final poliza = item['poliza']?.toString().trim().toUpperCase() ?? '';
    if (poliza.isEmpty) throw const FormatException('poliza está vacía');
    item['poliza'] = poliza;

    if (item['importe'] == null) {
      throw const FormatException('importe está vacío');
    }
    if (item['fecha'] == null) {
      throw const FormatException('fecha está vacía');
    }

    final estadoOriginal = (item['estado'] ?? item['estado_recibo'])
        ?.toString()
        .trim();
    final estado = _normalizarEstadoImportado(estadoOriginal);
    if (estado == null) {
      throw FormatException(
        'estado no reconocido: ${estadoOriginal ?? 'vacío'}',
      );
    }
    item['estado'] = estado;
    item['estado_recibo'] = 'ACTIVO';

    if (item['agente'] != null) {
      item['agente'] = item['agente'].toString().trim();
    }

    return item;
  }

  bool _esReciboDevuelto(Map<String, dynamic> recibo) {
    final estado = (recibo['estado_recibo'] ?? recibo['estado'] ?? '')
        .toString()
        .trim()
        .toLowerCase();

    return estado == 'devuelto' ||
        estado == 'impagado' ||
        estado.contains('devuelt') ||
        estado.contains('impagad');
  }

  Future<void> _notificarRecibosDevueltos(
    List<Map<String, dynamic>> recibosNuevos,
  ) async {
    final devueltos = recibosNuevos.where(_esReciboDevuelto).toList();
    if (devueltos.isEmpty) return;

    try {
      final usuariosResponse = await supabase
          .from('usuarios')
          .select('id, auth_id, parent_id');

      final usuarios = List<Map<String, dynamic>>.from(usuariosResponse);
      final usuariosPorId = <String, Map<String, dynamic>>{};
      final usuariosPorAuthId = <String, Map<String, dynamic>>{};

      for (final usuario in usuarios) {
        final id = usuario['id']?.toString().trim() ?? '';
        final authId = usuario['auth_id']?.toString().trim() ?? '';

        if (id.isNotEmpty) usuariosPorId[id] = usuario;
        if (authId.isNotEmpty) usuariosPorAuthId[authId] = usuario;
      }

      final polizas = devueltos
          .map((recibo) => recibo['poliza']?.toString().trim() ?? '')
          .where((poliza) => poliza.isNotEmpty)
          .toSet()
          .toList();

      final agentePorPoliza = <String, String>{};
      const tamanoConsulta = 200;

      for (var i = 0; i < polizas.length; i += tamanoConsulta) {
        final fin = (i + tamanoConsulta < polizas.length)
            ? i + tamanoConsulta
            : polizas.length;

        final ventasResponse = await supabase
            .from('ventas')
            .select('numero_poliza, agente_auth_id')
            .inFilter('numero_poliza', polizas.sublist(i, fin));

        for (final venta in List<Map<String, dynamic>>.from(ventasResponse)) {
          final poliza = venta['numero_poliza']?.toString().trim() ?? '';
          final agente = venta['agente_auth_id']?.toString().trim() ?? '';

          if (poliza.isNotEmpty && agente.isNotEmpty) {
            agentePorPoliza.putIfAbsent(poliza, () => agente);
          }
        }
      }

      for (final recibo in devueltos) {
        try {
          final poliza = recibo['poliza']?.toString().trim() ?? '';
          final agenteGuardado = recibo['agente']?.toString().trim() ?? '';

          final agenteAuthId = usuariosPorAuthId.containsKey(agenteGuardado)
              ? agenteGuardado
              : agentePorPoliza[poliza];

          if (agenteAuthId == null || agenteAuthId.isEmpty) {
            debugPrint(
              'PUSH RECIBO OMITIDO: no se encontró agente para '
              '${recibo['numero_recibo'] ?? poliza}.',
            );
            continue;
          }

          final destinatarios = <String>{};
          final idsVisitados = <String>{};
          Map<String, dynamic>? usuarioActual = usuariosPorAuthId[agenteAuthId];

          while (usuarioActual != null) {
            final id = usuarioActual['id']?.toString().trim() ?? '';
            final authId = usuarioActual['auth_id']?.toString().trim() ?? '';

            if (id.isNotEmpty && !idsVisitados.add(id)) {
              debugPrint('PUSH RECIBO: ciclo de parent_id detectado en $id.');
              break;
            }

            if (authId.isNotEmpty) destinatarios.add(authId);

            final parentId =
                usuarioActual['parent_id']?.toString().trim() ?? '';
            usuarioActual = parentId.isEmpty ? null : usuariosPorId[parentId];
          }

          final numeroRecibo = recibo['numero_recibo']?.toString().trim() ?? '';
          final cliente = recibo['cliente']?.toString().trim() ?? 'Cliente';
          final compania = recibo['compania']?.toString().trim() ?? '';
          final motivo = recibo['motivo']?.toString().trim() ?? '';
          final importe = toDoublePoliza(recibo['importe']) ?? 0;

          final detalleImporte = importe > 0
              ? ' por ${importe.toStringAsFixed(2)} €'
              : '';
          final detalleMotivo = motivo.isEmpty ? '' : ' Motivo: $motivo.';

          final mensaje =
              'El recibo ${numeroRecibo.isEmpty ? poliza : numeroRecibo} '
              'de $cliente$detalleImporte ha sido devuelto.'
              '$detalleMotivo Revisa la incidencia y comienza el seguimiento.';

          for (final authIdDestino in destinatarios) {
            try {
              await supabase.functions.invoke(
                'enviar-push',
                body: {
                  'auth_id_destino': authIdDestino,
                  'titulo': 'Recibo devuelto',
                  'mensaje': mensaje,
                  'data': {
                    'tipo': 'recibo_devuelto',
                    'numero_recibo': numeroRecibo,
                    'poliza': poliza,
                    'cliente': cliente,
                    'compania': compania,
                    'importe': importe,
                    'estado':
                        recibo['estado_recibo'] ??
                        recibo['estado'] ??
                        'Devuelto',
                  },
                },
              );
            } catch (errorPush) {
              debugPrint('ERROR PUSH RECIBO A $authIdDestino: $errorPush');
            }
          }
        } catch (errorRecibo) {
          debugPrint('ERROR PREPARANDO PUSH DE RECIBO: $errorRecibo');
        }
      }
    } catch (error) {
      // Este error nunca se propaga al importador.
      debugPrint('ERROR GENERAL NOTIFICACIONES DE RECIBOS: $error');
    }
  }

  void _mostrarMensajeRecibos(String mensaje) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(mensaje), duration: const Duration(seconds: 8)),
    );
  }

  Future<void> cargarRecibos() async {
    _panelRequests.clear();
    if (!mounted) return;
    setState(() {
      loadingRecibos = true;
    });

    try {
      final data = await getRecibos(selectedMenu);
      if (!mounted) return;

      setState(() {
        recibos = data;
        loadingRecibos = false;
      });

      print("📦 RECIBOS CARGADOS: ${recibos.length}");
    } catch (e) {
      setState(() {
        loadingRecibos = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Error al cargar recibos: $e"),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<List<Map<String, dynamic>>> _getRecibos() async {
    return await getRecibos(selectedMenu);
  }

  dynamic cleanExcelValue(dynamic value) {
    if (value == null) return null;
    if (value is excel.TextCellValue) return importExcelText(value);

    // 🧠 SI YA ES STRING / NUMERO
    if (value is String || value is num || value is bool) {
      return value;
    }

    // 🧠 EXCEL TYPES
    try {
      final type = value.runtimeType.toString();

      if (type.contains('IntCellValue')) {
        return value.value;
      }

      if (type.contains('DoubleCellValue')) {
        return value.value;
      }

      if (type.contains('TextCellValue')) {
        return value.value.toString();
      }

      if (type.contains('DateCellValue')) {
        return DateTime(value.year, value.month, value.day);
      }

      if (type.contains('DateTimeCellValue')) {
        return DateTime(
          value.year,
          value.month,
          value.day,
          value.hour,
          value.minute,
          value.second,
        );
      }

      // 🚨 CASO PROBLEMÁTICO REAL
      if (type.contains('TextSpan')) {
        try {
          return value.toPlainText();
        } catch (_) {
          return value.toString();
        }
      }
    } catch (e) {
      return value.toString();
    }

    // 🧯 FALLBACK TOTAL
    try {
      return value.toString();
    } catch (e) {
      return null;
    }
  }

  Future<List<Map<String, dynamic>>> getRecibos(String tipo) {
    final key = jsonEncode([tipo, filtroCompania, filtroAgente, filtroEstado,
      filtroJefeEquipo, fechaDesde?.toIso8601String(), fechaHasta?.toIso8601String()]);
    return _panelRequests.get('recibos:$key', () => _loadRecibos(tipo));
  }

  Future<List<Map<String, dynamic>>> _loadRecibos(String tipo) async {
    final supabase = Supabase.instance.client;

    List<String> polizasPermitidas = [];

    if (!veTodoERP) {
      if (authIdsPermitidosERP.isEmpty) return [];

      final ventasPermitidas = await supabase
          .from('ventas')
          .select('numero_poliza')
          .inFilter('agente_auth_id', authIdsPermitidosERP);

      polizasPermitidas = List<Map<String, dynamic>>.from(ventasPermitidas)
          .map((v) => v['numero_poliza']?.toString() ?? '')
          .where((p) => p.isNotEmpty)
          .toSet()
          .toList();

      if (polizasPermitidas.isEmpty) return [];
    }

    dynamic query = supabase.from('recibos').select();

    if (!veTodoERP) {
      query = query.inFilter('poliza', polizasPermitidas);
    }

    if (tipo == "recibos_cobrados") {
      query = query.eq('estado', 'COBRADO');
    }

    if (tipo == "recibos_devueltos") {
      query = query.eq('estado', 'DEVUELTO');
    }

    if (tipo == "recibos_pendientes") {
      query = query.eq('estado', 'PENDIENTE');
    }

    if (filtroCompania != null &&
        filtroCompania!.isNotEmpty &&
        filtroCompania != "Todas") {
      query = query.eq('compania', filtroCompania!);
    }

    if (filtroAgente != null &&
        filtroAgente!.isNotEmpty &&
        filtroAgente != "Todos") {
      query = query.eq('agente', filtroAgente!);
    }

    if (filtroEstado != null &&
        filtroEstado!.isNotEmpty &&
        filtroEstado != "Todos") {
      query = query.eq('estado', filtroEstado!);
    }

    if (fechaDesde != null) {
      final inicioDia = DateTime(
        fechaDesde!.year,
        fechaDesde!.month,
        fechaDesde!.day,
        0,
        0,
        0,
      );

      query = query.gte('fecha', inicioDia.toIso8601String());
    }

    if (fechaHasta != null) {
      final finDia = DateTime(
        fechaHasta!.year,
        fechaHasta!.month,
        fechaHasta!.day,
        23,
        59,
        59,
      );

      query = query.lte('fecha', finDia.toIso8601String());
    }

    final response = await query.order('fecha', ascending: false);

    final data = List<Map<String, dynamic>>.from(response);

    print("📦 RECIBOS FILTRADOS: ${data.length}");

    return data;
  }

  double totalImporteRecibos(List<Map<String, dynamic>> lista) {
    return lista.fold<double>(0, (suma, r) {
      return suma +
          _toDoubleKpi(
            r['importe'] ?? r['precio'] ?? r['prima'] ?? r['total'] ?? 0,
          );
    });
  }

  int totalRecibosPorEstado(List<Map<String, dynamic>> lista, String estado) {
    return lista.where((r) {
      return (r['estado']?.toString().toUpperCase() ?? '') ==
          estado.toUpperCase();
    }).length;
  }

  double totalDineroRecibosPorEstado(
    List<Map<String, dynamic>> lista,
    String estado,
  ) {
    final filtrados = lista.where((r) {
      return (r['estado']?.toString().toUpperCase() ?? '') ==
          estado.toUpperCase();
    }).toList();

    return totalImporteRecibos(filtrados);
  }

  Future<void> seleccionarArchivoPolizas() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx', 'csv'],
      withData: true,
    );

    if (result == null) return;

    final file = result.files.first;
    Uint8List? bytes = file.bytes;

    if (bytes == null && file.path != null) {
      bytes = await File(file.path!).readAsBytes();
    }

    if (bytes == null) return;

    polizasHeaders.clear();
    polizasRows.clear();
    polizasPreview.clear();
    polizasColumnMapping.clear();
    polizasNuevasValidadas.clear();
    polizasSinAgente.clear();
    polizasPendientesAsignacion.clear();
    polizasExistentesValidadas.clear();

    final extension = file.extension?.toLowerCase();

    if (extension == 'csv') {
      final content = utf8.decode(bytes, allowMalformed: true);
      final lines = const LineSplitter()
          .convert(content)
          .where((l) => l.trim().isNotEmpty)
          .toList();

      if (lines.isEmpty) return;

      final separator = lines.first.contains(';') ? ';' : ',';

      final filasCsv = lines
          .map((line) => _parsearLineaCsv(line, separator))
          .toList();
      final indiceCabecera = _indiceCabeceraPolizas(filasCsv);

      polizasHeaders = filasCsv[indiceCabecera]
          .map((e) => e.toString().trim())
          .toList();

      polizasRows = filasCsv
          .skip(indiceCabecera + 1)
          .where(_filaReciboConDatos)
          .toList();
    } else {
      final archivoExcel = excel.Excel.decodeBytes(bytes);
      final sheet = archivoExcel.tables.values.first;
      final rows = sheet.rows;

      if (rows.isEmpty) return;

      final filasExcel = rows
          .map((row) => row.map((e) => e?.value ?? '').toList())
          .toList();
      final indiceCabecera = _indiceCabeceraPolizas(filasExcel);

      polizasHeaders = filasExcel[indiceCabecera]
          .map((e) => e.toString().trim())
          .toList();

      polizasRows = filasExcel
          .skip(indiceCabecera + 1)
          .where(_filaReciboConDatos)
          .toList();
    }

    autoMapearPolizas();

    polizasPreview = [polizasHeaders, ...polizasRows.take(80)];

    setState(() {});
  }

  List<String> _parsearLineaCsv(String line, String separator) {
    final resultado = <String>[];
    final actual = StringBuffer();
    var entreComillas = false;

    for (var i = 0; i < line.length; i++) {
      final caracter = line[i];

      if (caracter == '"') {
        if (entreComillas && i + 1 < line.length && line[i + 1] == '"') {
          actual.write('"');
          i++;
        } else {
          entreComillas = !entreComillas;
        }
        continue;
      }

      if (caracter == separator && !entreComillas) {
        resultado.add(actual.toString().trim());
        actual.clear();
      } else {
        actual.write(caracter);
      }
    }

    resultado.add(actual.toString().trim());
    return resultado;
  }

  String _normalizarCabeceraPoliza(dynamic value) {
    var texto = value
        .toString()
        .replaceAll('\uFEFF', '')
        .replaceAll('\u00A0', ' ')
        .trim()
        .toUpperCase();

    const reemplazos = <String, String>{
      'Á': 'A',
      'É': 'E',
      'Í': 'I',
      'Ó': 'O',
      'Ú': 'U',
      'Ü': 'U',
      'Ñ': 'N',
      'º': ' ',
      '°': ' ',
      'ª': ' ',
      '№': 'N ',
    };
    reemplazos.forEach((origen, destino) {
      texto = texto.replaceAll(origen, destino);
    });

    texto = texto
        .replaceAll(RegExp(r'[_./\\\-]+'), ' ')
        .replaceAll(RegExp(r'[^A-Z0-9 ]'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();

    if (RegExp(r'^(N|NO|NUMERO)( DE)? POLIZA$').hasMatch(texto)) {
      return 'NUMERO POLIZA';
    }
    return texto;
  }

  int _indiceCabeceraPolizas(List<List<dynamic>> filas) {
    const nombresReconocidos = <String>{
      'NUMERO POLIZA',
      'POLIZA',
      'NIF',
      'APELLIDO 1',
      'APELLIDO 2',
      'TOMADOR',
      'ESTADO',
      'DIRECCION',
      'C POSTAL',
      'CODIGO POSTAL',
      'LOCALIDAD',
      'MOVIL',
      'TELEFONO',
      'EMAIL',
      'RAMO',
      'COMPANIA',
      'PRIMA NETA',
      'PRIMA TOTAL',
      'FECHA EFECTO',
      'COLABORADOR 1 ID',
      'COLABORADOR 1',
    };

    var mejorIndice = 0;
    var mejorPuntuacion = -1;
    final limite = filas.length < 30 ? filas.length : 30;

    for (var i = 0; i < limite; i++) {
      final puntuacion = filas[i]
          .map(_normalizarCabeceraPoliza)
          .where(nombresReconocidos.contains)
          .length;
      if (puntuacion > mejorPuntuacion) {
        mejorPuntuacion = puntuacion;
        mejorIndice = i;
      }
    }

    return mejorIndice;
  }

  void autoMapearPolizas() {
    final Map<String, String> auto = {
      "Nº PÓLIZA": "venta.numero_poliza",
      "Nº POLIZA": "venta.numero_poliza",

      "NIF": "cliente.dni",

      "APELLIDO 1": "aux.apellido_1",
      "APELLIDO1": "aux.apellido_1",
      "PRIMER APELLIDO": "aux.apellido_1",
      "APELLIDO 2": "aux.apellido_2",
      "APELLIDO2": "aux.apellido_2",
      "SEGUNDO APELLIDO": "aux.apellido_2",

      "TOMADOR": "cliente.nombre",

      "ESTADO": "venta.estado_poliza",

      "DIRECCION": "cliente.direccion",
      "DIRECCIÓN": "cliente.direccion",

      "CÓDIGO POSTAL": "cliente.codigo_postal",
      "CODIGO POSTAL": "cliente.codigo_postal",
      "C. POSTAL": "cliente.codigo_postal",
      "C.POSTAL": "cliente.codigo_postal",

      "LOCALIDAD": "cliente.poblacion",

      "MOVIL": "aux.movil",
      "MÓVIL": "aux.movil",
      "TELEFONO": "cliente.telefono",
      "TELÉFONO": "cliente.telefono",

      "E-MAIL": "cliente.email",
      "EMAIL": "cliente.email",

      "RAMO": "venta.producto",

      "COMPAÑIA": "venta.compania",
      "COMPAÑÍA": "venta.compania",

      "P. NETA": "venta.prima_anual_neta",
      "P.NETA": "venta.prima_anual_neta",
      "PRIMA NETA": "venta.prima_anual_neta",

      "P. TOTAL": "venta.prima_anual_bruta",
      "P.TOTAL": "venta.prima_anual_bruta",
      "PRIMA TOTAL": "venta.prima_anual_bruta",

      "F. EFECTO": "venta.fecha_efecto",
      "F.EFECTO": "venta.fecha_efecto",
      "FECHA EFECTO": "venta.fecha_efecto",

      "AGENTE AUTH ID": "venta.agente_auth_id",
      "AGENTE_AUTH_ID": "venta.agente_auth_id",
      "AUTH ID AGENTE": "venta.agente_auth_id",
      "COLABORADOR 1 ID": "aux.colaborador_id",
      "COLABORADOR 1": "aux.colaborador_nombre",

      "NOMBRE": "cliente.nombre",
      "CLIENTE": "cliente.nombre",
      "NOMBRE CLIENTE": "cliente.nombre",

      "APELLIDOS": "cliente.apellidos",
      "APELLIDO": "cliente.apellidos",

      "CORREO": "cliente.email",

      "CP": "cliente.codigo_postal",

      "PROVINCIA": "cliente.provincia",
      "POBLACION": "cliente.poblacion",
      "POBLACIÓN": "cliente.poblacion",

      "DOMICILIO": "cliente.direccion",

      "NUMERO": "cliente.numero",
      "NÚMERO": "cliente.numero",
      "NUM": "cliente.numero",

      "DNI": "cliente.dni",
      "NIE": "cliente.dni",
      // Colaborador 1 contiene nombre y apellidos.
      // Se usa para localizar al usuario y obtener su auth_id.

      // Compatibilidad con otros posibles Excel.
      "AGENTE": "aux.colaborador_nombre",
      "COMERCIAL": "aux.colaborador_nombre",
      "MEDIADOR": "aux.colaborador_nombre",
      "ASESOR": "aux.colaborador_nombre",
      "VENDEDOR": "aux.colaborador_nombre",
      "NOMBRE COMERCIAL": "aux.colaborador_nombre",
      "NOMBRE MEDIADOR": "aux.colaborador_nombre",
      "NOMBRE AGENTE": "aux.colaborador_nombre",
      "NOMBRE DEL AGENTE": "aux.colaborador_nombre",

      "PRODUCTO": "venta.producto",

      "COMPANIA": "venta.compania",
      "ASEGURADORA": "venta.compania",

      "FORMA PAGO": "venta.forma_pago",
      "FORMA DE PAGO": "venta.forma_pago",
      "PAGO": "venta.forma_pago",

      "FRECUENCIA": "venta.forma_pago",
      "PERIODICIDAD": "venta.forma_pago",
      "PERIOCIDAD": "venta.forma_pago",
      "PERIODO": "venta.forma_pago",
      "PERÍODO": "venta.forma_pago",
      "FRACCIONAMIENTO": "venta.forma_pago",

      "PRECIO": "venta.precio",
      "IMPORTE": "venta.precio",

      "CUOTA": "venta.precio",
      "PRIMA": "venta.precio",
      "IMPORTE RECIBO": "venta.precio",
      "RECIBO": "venta.precio",

      "ASEGURADOS": "venta.numero_asegurados",
      "NUMERO ASEGURADOS": "venta.numero_asegurados",
      "Nº ASEGURADOS": "venta.numero_asegurados",

      "FECHA_EFECTO": "venta.fecha_efecto",
      "EFECTO": "venta.fecha_efecto",

      "PRIMA ANUAL": "venta.prima_anual",
      "PRIMA_ANUAL": "venta.prima_anual",

      "CATEGORIA": "venta.categoria_producto",
      "CATEGORIA PRODUCTO": "venta.categoria_producto",
      "CATEGORÍA PRODUCTO": "venta.categoria_producto",

      "PRIMA BRUTA": "venta.prima_anual_bruta",
      "PRIMA ANUAL BRUTA": "venta.prima_anual_bruta",
      "PRIMA_ANUAL_BRUTA": "venta.prima_anual_bruta",

      "PRIMA ANUAL NETA": "venta.prima_anual_neta",
      "PRIMA_ANUAL_NETA": "venta.prima_anual_neta",
      "NETA": "venta.prima_anual_neta",

      "COMISION": "venta.comision",
      "COMISIÓN": "venta.comision",

      "POLIZA": "venta.numero_poliza",
      "PÓLIZA": "venta.numero_poliza",
      "NUMERO POLIZA": "venta.numero_poliza",

      "ESTADO POLIZA": "venta.estado_poliza",
      "ESTADO PÓLIZA": "venta.estado_poliza",
    };

    final autoNormalizado = <String, String>{
      for (final entrada in auto.entries)
        _normalizarCabeceraPoliza(entrada.key): entrada.value,
    };
    final destinosUsados = <String>{};

    for (final h in polizasHeaders) {
      final key = _normalizarCabeceraPoliza(h);
      if (autoNormalizado.containsKey(key)) {
        final destino = autoNormalizado[key]!;
        if (destinosUsados.add(destino)) {
          polizasColumnMapping[key] = destino;
        }
      }
    }
  }

  dynamic valorPolizaMapeado(List<dynamic> row, String campo) {
    for (int i = 0; i < polizasHeaders.length; i++) {
      final header = _normalizarCabeceraPoliza(polizasHeaders[i]);
      final mapped = polizasColumnMapping[header];

      if (mapped == campo && i < row.length) {
        final value = cleanExcelValue(row[i]);

        if (value == null) return null;

        if (value is String) {
          final text = value.trim();
          return text.isEmpty ? null : text;
        }

        return value;
      }
    }

    return null;
  }

  double? toDoublePoliza(dynamic value) {
    if (value == null) return null;

    if (value is num) return value.toDouble();

    var text = value
        .toString()
        .replaceAll('€', '')
        .replaceAll(RegExp(r'\s+'), '')
        .trim();

    if (text.isEmpty) return null;

    final ultimaComa = text.lastIndexOf(',');
    final ultimoPunto = text.lastIndexOf('.');

    if (ultimaComa >= 0 && ultimoPunto >= 0) {
      if (ultimaComa > ultimoPunto) {
        text = text.replaceAll('.', '').replaceAll(',', '.');
      } else {
        text = text.replaceAll(',', '');
      }
    } else if (ultimaComa >= 0) {
      final decimales = text.length - ultimaComa - 1;
      text = decimales == 3 && ultimaComa > 0
          ? text.replaceAll(',', '')
          : text.replaceAll(',', '.');
    } else if (ultimoPunto >= 0) {
      final decimales = text.length - ultimoPunto - 1;
      if (decimales == 3 && ultimoPunto > 0) {
        text = text.replaceAll('.', '');
      }
    }

    return double.tryParse(text);
  }

  int? toIntPoliza(dynamic value) {
    if (value == null) return null;

    if (value is int) return value;
    if (value is num) return value.toInt();

    final text = value.toString().trim().replaceAll(RegExp(r'\.0$'), '');

    return int.tryParse(text);
  }

  String? toFechaSupabase(dynamic value) {
    if (value == null) return null;

    DateTime? validar(int year, int month, int day) {
      if (year < 1900 || year > 2200 || month < 1 || month > 12 || day < 1) {
        return null;
      }
      final fecha = DateTime(year, month, day);
      return fecha.year == year && fecha.month == month && fecha.day == day
          ? fecha
          : null;
    }

    if (value is DateTime) {
      return validar(value.year, value.month, value.day)?.toIso8601String();
    }

    // Excel puede entregar la fecha como número de serie.
    if (value is num) {
      final fecha = DateTime(1899, 12, 30).add(Duration(days: value.floor()));
      return validar(fecha.year, fecha.month, fecha.day)?.toIso8601String();
    }

    final text = value.toString().trim();
    if (text.isEmpty) return null;

    final match = RegExp(
      r'^(\d{1,4})[\/\-.](\d{1,2})[\/\-.](\d{1,4})$',
    ).firstMatch(text);
    if (match != null) {
      final primero = int.tryParse(match.group(1)!);
      final segundo = int.tryParse(match.group(2)!);
      final tercero = int.tryParse(match.group(3)!);
      if (primero == null || segundo == null || tercero == null) return null;

      final year = match.group(1)!.length == 4 ? primero : tercero;
      final month = segundo;
      final day = match.group(1)!.length == 4 ? tercero : primero;
      return validar(year, month, day)?.toIso8601String();
    }

    final parsed = DateTime.tryParse(text);
    return parsed == null
        ? null
        : validar(parsed.year, parsed.month, parsed.day)?.toIso8601String();
  }

  double calcularPrimaAnualMasiva({
    required double precio,
    required String? formaPago,
  }) {
    final pago =
        formaPago
            ?.toLowerCase()
            .replaceAll('á', 'a')
            .replaceAll('é', 'e')
            .replaceAll('í', 'i')
            .replaceAll('ó', 'o')
            .replaceAll('ú', 'u')
            .trim() ??
        '';

    if (pago.contains('mensual') || pago == 'm') {
      return precio * 12;
    }

    if (pago.contains('trimestral') || pago == 't') {
      return precio * 4;
    }

    if (pago.contains('semestral') || pago == 's') {
      return precio * 2;
    }

    if (pago.contains('anual') ||
        pago == 'a' ||
        pago.contains('unico') ||
        pago.contains('único')) {
      return precio;
    }

    return precio;
  }

  Future<String?> resolverAgenteAuthId(dynamic value) async {
    if (value == null || value.toString().trim().isEmpty) return null;

    String normalizarTexto(String texto) {
      return texto
          .toLowerCase()
          .replaceAll('á', 'a')
          .replaceAll('é', 'e')
          .replaceAll('í', 'i')
          .replaceAll('ó', 'o')
          .replaceAll('ú', 'u')
          .replaceAll('ü', 'u')
          .replaceAll('ñ', 'n')
          .replaceAll(RegExp(r'[^a-z0-9]+'), ' ')
          .replaceAll(RegExp(r'\s+'), ' ')
          .trim();
    }

    bool estadoActivo(dynamic estado) {
      final normalizado = normalizarTexto(estado?.toString() ?? 'activo');
      return !{
        'baja',
        'inactivo',
        'inactiva',
        'bloqueado',
        'bloqueada',
        'desactivado',
        'desactivada',
        'suspendido',
        'suspendida',
      }.contains(normalizado);
    }

    final referencia = value.toString().trim();
    final referenciaNormalizada = normalizarTexto(referencia);
    final usuariosResponse = await supabase
        .from('usuarios')
        .select('id, auth_id, nombre, apellidos, email, estado');
    final usuarios = List<Map<String, dynamic>>.from(usuariosResponse)
        .where(
          (u) =>
              (u['auth_id']?.toString().trim().isNotEmpty ?? false) &&
              estadoActivo(u['estado']),
        )
        .toList();

    final directos = usuarios.where((u) {
      return u['auth_id']?.toString() == referencia ||
          u['id']?.toString() == referencia ||
          (u['email']?.toString().trim().toLowerCase() ?? '') ==
              referencia.toLowerCase();
    }).toList();

    if (directos.length == 1) return directos.single['auth_id'].toString();
    if (directos.length > 1) return null;

    final exactos = usuarios.where((u) {
      final nombre = normalizarTexto(u['nombre']?.toString() ?? '');
      final apellidos = normalizarTexto(u['apellidos']?.toString() ?? '');
      return normalizarTexto('$nombre $apellidos') == referenciaNormalizada ||
          normalizarTexto('$apellidos $nombre') == referenciaNormalizada;
    }).toList();

    // Nunca se elige arbitrariamente entre personas con el mismo nombre.
    if (exactos.length == 1) return exactos.single['auth_id'].toString();
    if (exactos.length > 1) return null;

    final contenidos = usuarios.where((u) {
      final nombre = normalizarTexto(u['nombre']?.toString() ?? '');
      final apellidos = normalizarTexto(u['apellidos']?.toString() ?? '');
      return nombre.isNotEmpty &&
          apellidos.isNotEmpty &&
          referenciaNormalizada.contains(nombre) &&
          referenciaNormalizada.contains(apellidos);
    }).toList();

    return contenidos.length == 1
        ? contenidos.single['auth_id'].toString()
        : null;
  }

  Map<String, String> separarNombreApellidos(String nombreCompleto) {
    final texto = nombreCompleto.replaceAll(RegExp(r'\s+'), ' ').trim();

    if (texto.isEmpty) {
      return {'nombre': '', 'apellidos': ''};
    }

    if (texto.contains(',')) {
      final partesComa = texto.split(',');
      final apellidos = partesComa.first.trim();
      final nombre = partesComa.skip(1).join(' ').trim();

      if (nombre.isNotEmpty && apellidos.isNotEmpty) {
        return {'nombre': nombre, 'apellidos': apellidos};
      }
    }

    final partes = texto.split(' ');

    if (partes.length == 1) {
      return {'nombre': partes.first, 'apellidos': ''};
    }

    if (partes.length == 2) {
      return {'nombre': partes[0], 'apellidos': partes[1]};
    }

    return {
      'nombre': partes.sublist(0, partes.length - 2).join(' '),
      'apellidos': partes.sublist(partes.length - 2).join(' '),
    };
  }

  Map<String, dynamic> limpiarNulls(Map<String, dynamic> data) {
    data.removeWhere((key, value) {
      if (value == null) return true;
      if (value is String && value.trim().isEmpty) return true;
      return false;
    });

    return data;
  }

  Future<String> _resolverAgenteImportacion(List<dynamic> row) async {
    final authIdDirecto = valorPolizaMapeado(
      row,
      'venta.agente_auth_id',
    )?.toString().trim();

    if (authIdDirecto != null && authIdDirecto.isNotEmpty) {
      final usuario = await supabase
          .from('usuarios')
          .select('auth_id, estado')
          .eq('auth_id', authIdDirecto)
          .maybeSingle();

      if (usuario == null) {
        throw Exception(
          'El agente_auth_id $authIdDirecto no existe en usuarios.',
        );
      }

      final estado = (usuario['estado'] ?? 'activo')
          .toString()
          .trim()
          .toLowerCase();
      if ({
        'baja',
        'inactivo',
        'inactiva',
        'bloqueado',
        'bloqueada',
        'desactivado',
        'desactivada',
        'suspendido',
        'suspendida',
      }.contains(estado)) {
        throw Exception(
          'El usuario asignado está inactivo o de baja: $authIdDirecto',
        );
      }
      return authIdDirecto;
    }

    final colaboradorNombre = valorPolizaMapeado(
      row,
      'aux.colaborador_nombre',
    )?.toString().trim();

    if (colaboradorNombre == null || colaboradorNombre.isEmpty) {
      throw Exception('Falta el agente: mapea Colaborador 1 o AGENTE AUTH ID.');
    }

    final agenteAuthId = await resolverAgenteAuthId(colaboradorNombre);

    if (agenteAuthId == null || agenteAuthId.trim().isEmpty) {
      throw Exception(
        'No se ha encontrado en usuarios al agente: $colaboradorNombre',
      );
    }

    return agenteAuthId.trim();
  }

  String _normalizarImportacion(String value) {
    return value
        .toLowerCase()
        .replaceAll('á', 'a')
        .replaceAll('é', 'e')
        .replaceAll('í', 'i')
        .replaceAll('ó', 'o')
        .replaceAll('ú', 'u')
        .replaceAll('ü', 'u')
        .replaceAll('ñ', 'n')
        .replaceAll(RegExp(r'[^a-z0-9]+'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  bool _usuarioImportacionActivo(dynamic estado) {
    return !{
      'baja',
      'inactivo',
      'inactiva',
      'bloqueado',
      'bloqueada',
      'desactivado',
      'desactivada',
      'suspendido',
      'suspendida',
    }.contains(_normalizarImportacion(estado?.toString() ?? 'activo'));
  }

  Map<String, dynamic>? _buscarUsuarioImportacion(
    String colaborador,
    List<Map<String, dynamic>> usuarios,
  ) {
    final buscado = _normalizarImportacion(colaborador);
    if (buscado.isEmpty) return null;

    final exactos = usuarios.where((u) {
      final nombre = _normalizarImportacion(u['nombre']?.toString() ?? '');
      final apellidos = _normalizarImportacion(
        u['apellidos']?.toString() ?? '',
      );
      return _normalizarImportacion('$nombre $apellidos') == buscado ||
          _normalizarImportacion('$apellidos $nombre') == buscado;
    }).toList();
    if (exactos.length == 1) return exactos.single;

    final tokensBuscados = buscado
        .split(' ')
        .where((e) => e.isNotEmpty)
        .toSet();
    final contenidos = usuarios.where((u) {
      final completo = _normalizarImportacion(
        '${u['nombre'] ?? ''} ${u['apellidos'] ?? ''}',
      );
      final tokensUsuario = completo
          .split(' ')
          .where((e) => e.isNotEmpty)
          .toSet();
      return tokensUsuario.isNotEmpty &&
          tokensUsuario.every(tokensBuscados.contains);
    }).toList();
    return contenidos.length == 1 ? contenidos.single : null;
  }

  Future<void> validarImportacionPolizas() async {
    if (polizasRows.isEmpty || validandoPolizas || importingPolizas) return;

    final destinos = polizasColumnMapping.values.toSet();
    final requeridos = <String, String>{
      'cliente.nombre': 'Tomador',
      'venta.numero_poliza': 'Nº póliza',
      'venta.producto': 'Ramo',
      'venta.compania': 'Compañía',
      'venta.fecha_efecto': 'Fecha efecto',
      'venta.prima_anual_neta': 'Prima neta',
      'venta.prima_anual_bruta': 'Prima total',
      'aux.colaborador_nombre': 'Colaborador 1',
    };
    final faltantes = requeridos.entries
        .where((e) => !destinos.contains(e.key))
        .map((e) => e.value)
        .toList();
    final cabeceras = polizasHeaders
        .map(_normalizarCabeceraPoliza)
        .where((h) => h.isNotEmpty)
        .toList();

    if (cabeceras.toSet().length != cabeceras.length) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('El Excel contiene columnas repetidas.'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }
    if (faltantes.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'No se reconocen estas columnas: ${faltantes.join(', ')}',
          ),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() {
      validandoPolizas = true;
      polizasNuevasValidadas = [];
      polizasSinAgente = [];
      polizasPendientesAsignacion = [];
      polizasExistentesValidadas = [];
    });

    try {
      final usuarios = <Map<String, dynamic>>[];
      var desde = 0;
      const pagina = 1000;
      while (true) {
        final bloque = List<Map<String, dynamic>>.from(
          await supabase
              .from('usuarios')
              .select('id, auth_id, nombre, apellidos, email, estado')
              .range(desde, desde + pagina - 1),
        );
        usuarios.addAll(
          bloque.where(
            (u) =>
                (u['auth_id']?.toString().trim().isNotEmpty ?? false) &&
                _usuarioImportacionActivo(u['estado']),
          ),
        );
        if (bloque.length < pagina) break;
        desde += pagina;
      }

      final numeros = polizasRows
          .map(
            (row) => valorPolizaMapeado(
              row,
              'venta.numero_poliza',
            )?.toString().trim().toUpperCase(),
          )
          .whereType<String>()
          .where((e) => e.isNotEmpty)
          .toSet()
          .toList();
      final existentes = <String, Map<String, dynamic>>{};
      for (var i = 0; i < numeros.length; i += 100) {
        final fin = (i + 100 < numeros.length) ? i + 100 : numeros.length;
        final bloque = List<Map<String, dynamic>>.from(
          await supabase
              .from('ventas')
              .select('id, numero_poliza, cliente_id, agente_auth_id')
              .inFilter('numero_poliza', numeros.sublist(i, fin)),
        );
        for (final venta in bloque) {
          final numero = venta['numero_poliza']
              ?.toString()
              .trim()
              .toUpperCase();
          if (numero != null && numero.isNotEmpty) existentes[numero] = venta;
        }
        final pendientesYaGuardadas = await supabase.rpc(
          'app_polizas_ya_importadas',
          params: {'p_numeros': numeros.sublist(i, fin)},
        );
        for (final fila in List<Map<String, dynamic>>.from(
          pendientesYaGuardadas,
        )) {
          final numero = fila['numero_poliza'].toString().trim().toUpperCase();
          existentes.putIfAbsent(numero, () => fila);
        }
      }

      final nuevas = <Map<String, dynamic>>[];
      final sinAgente = <Map<String, dynamic>>[];
      final pendientesAsignacion = <Map<String, dynamic>>[];
      final repetidas = <Map<String, dynamic>>[];
      final vistosExcel = <String>{};

      for (var index = 0; index < polizasRows.length; index++) {
        final row = polizasRows[index];
        final numero =
            valorPolizaMapeado(
              row,
              'venta.numero_poliza',
            )?.toString().trim().toUpperCase() ??
            '';
        final colaborador =
            valorPolizaMapeado(
              row,
              'aux.colaborador_nombre',
            )?.toString().trim() ??
            '';
        final usuario = _buscarUsuarioImportacion(colaborador, usuarios);
        final tomador =
            valorPolizaMapeado(row, 'cliente.nombre')?.toString().trim() ?? '';
        final producto =
            valorPolizaMapeado(row, 'venta.producto')?.toString().trim() ?? '';
        final compania =
            valorPolizaMapeado(row, 'venta.compania')?.toString().trim() ?? '';
        final primaNeta = toDoublePoliza(
          valorPolizaMapeado(row, 'venta.prima_anual_neta'),
        );
        final primaTotal = toDoublePoliza(
          valorPolizaMapeado(row, 'venta.prima_anual_bruta'),
        );
        final fechaEfecto = toFechaSupabase(
          valorPolizaMapeado(row, 'venta.fecha_efecto'),
        );
        final base = <String, dynamic>{
          'fila': index + 2,
          'row': row,
          'numero_poliza': numero,
          'colaborador': colaborador,
          'nif': valorPolizaMapeado(row, 'cliente.dni')?.toString() ?? '',
          'tomador': tomador,
        };

        if (numero.isEmpty) {
          sinAgente.add({...base, 'motivo': 'Falta el número de póliza'});
          continue;
        }
        if (!vistosExcel.add(numero)) {
          sinAgente.add({
            ...base,
            'motivo': 'Póliza repetida dentro del Excel',
          });
          continue;
        }
        // Las existentes se omiten incluso si el Excel cambia el agente
        // o contiene datos que no pasarían la validación de una póliza nueva.
        if (existentes.containsKey(numero)) {
          repetidas.add({
            ...base,
            'motivo': 'Ya registrada: se omite sin modificar',
          });
          continue;
        }
        final erroresFila = <String>[];
        if (tomador.isEmpty) erroresFila.add('falta Tomador');
        if (producto.isEmpty) erroresFila.add('falta Ramo');
        if (compania.isEmpty) erroresFila.add('falta Compañía');
        if (primaNeta == null || primaNeta < 0) {
          erroresFila.add('Prima neta no válida');
        }
        if (primaTotal == null || primaTotal < 0) {
          erroresFila.add('Prima total no válida');
        }
        if (fechaEfecto == null) erroresFila.add('Fecha efecto no válida');
        if (erroresFila.isNotEmpty) {
          sinAgente.add({...base, 'motivo': erroresFila.join(' · ')});
          continue;
        }
        if (usuario == null) {
          if (colaborador.isEmpty) {
            sinAgente.add({
              ...base,
              'motivo': 'Falta el nombre del agente en Colaborador 1',
            });
            continue;
          }
          pendientesAsignacion.add({
            ...base,
            'agente_auth_id': null,
            'agente_nombre': colaborador,
            'motivo':
                'Se guardará pendiente de asignación con el agente del Excel',
          });
          continue;
        }

        final agenteNombre =
            '${usuario['nombre'] ?? ''} ${usuario['apellidos'] ?? ''}'
                .replaceAll(RegExp(r'\s+'), ' ')
                .trim();
        final validada = <String, dynamic>{
          ...base,
          'agente_auth_id': usuario['auth_id'].toString(),
          'agente_nombre': agenteNombre,
        };
        final existente = existentes[numero];
        if (existente == null) {
          nuevas.add(validada);
        } else {
          repetidas.add({
            ...validada,
            'venta_id': existente['id'].toString(),
            'cliente_id_existente': existente['cliente_id']?.toString(),
            'agente_anterior': existente['agente_auth_id']?.toString(),
          });
        }
      }

      if (!mounted) return;
      setState(() {
        polizasNuevasValidadas = nuevas;
        polizasSinAgente = sinAgente;
        polizasPendientesAsignacion = pendientesAsignacion;
        polizasExistentesValidadas = repetidas;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('No se pudo analizar el Excel: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => validandoPolizas = false);
    }
  }

  Future<void> exportarListadoPolizas(
    List<Map<String, dynamic>> listado,
    String nombre,
  ) async {
    final libro = excel.Excel.createExcel();
    final hoja = libro['Pólizas'];
    libro.delete('Sheet1');
    hoja.appendRow([
      excel.TextCellValue('Fila'),
      excel.TextCellValue('Nº póliza'),
      excel.TextCellValue('NIF'),
      excel.TextCellValue('Tomador'),
      excel.TextCellValue('Colaborador 1'),
      excel.TextCellValue('Agente identificado'),
      excel.TextCellValue('Motivo / acción'),
    ]);
    for (final item in listado) {
      hoja.appendRow([
        excel.TextCellValue(item['fila']?.toString() ?? ''),
        excel.TextCellValue(item['numero_poliza']?.toString() ?? ''),
        excel.TextCellValue(item['nif']?.toString() ?? ''),
        excel.TextCellValue(item['tomador']?.toString() ?? ''),
        excel.TextCellValue(item['colaborador']?.toString() ?? ''),
        excel.TextCellValue(item['agente_nombre']?.toString() ?? ''),
        excel.TextCellValue(
          item['motivo']?.toString() ??
              'Se actualizará con los datos del Excel',
        ),
      ]);
    }
    final bytes = libro.encode();
    if (bytes == null) return;
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/$nombre.xlsx');
    await file.writeAsBytes(bytes, flush: true);
    await OpenFilex.open(file.path);
  }

  bool _falloGlobalImportacion(Object error) {
    if (error is TimeoutException ||
        error is SocketException ||
        error is AuthException)
      return true;
    if (error is PostgrestException) {
      return {
        '42501',
        'PGRST202',
        'PGRST204',
        'PGRST205',
        'PGRST301',
        'PGRST302',
        '42P01',
        '42883',
      }.contains(error.code);
    }
    return false;
  }

  String _detalleErrorImportacion(Object error) {
    if (error is PostgrestException) {
      final detalle =
          '${error.message}\nCodigo: ${error.code ?? '-'}'
          '${error.details == null ? '' : '\nDetalle: ${error.details}'}'
          '${error.hint == null ? '' : '\nAyuda: ${error.hint}'}';
      if ({
        'PGRST202',
        'PGRST204',
        'PGRST205',
        '42P01',
        '42883',
      }.contains(error.code)) {
        return 'Falta una tabla, columna o funcion necesaria en Supabase. Comprueba que la migracion de pendientes se ha ejecutado completa.\n$detalle';
      }
      if (error.code == '42501') {
        return 'Supabase ha rechazado el acceso por permisos del usuario conectado.\n$detalle';
      }
      return detalle;
    }
    return error.toString();
  }

  Future<void> importarPolizasMasivasASupabase() async {
    if (importingPolizas) return;
    final pendientes = [
      ...polizasNuevasValidadas,
      ...polizasPendientesAsignacion,
    ];
    if (pendientes.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Analiza primero el Excel y comprueba los listados.'),
        ),
      );
      return;
    }

    setState(() => importingPolizas = true);
    // Verificar configuracion y sesion antes de crear ningun cliente.
    try {
      if (supabase.auth.currentSession == null) {
        throw const AuthException(
          'La sesion ha caducado. Vuelve a iniciar sesion.',
        );
      }
      await supabase
          .rpc('app_polizas_ya_importadas', params: {'p_numeros': <String>[]})
          .timeout(const Duration(seconds: 45));
      if (polizasPendientesAsignacion.isNotEmpty) {
        await supabase
            .from('polizas_pendientes_asignacion')
            .select('id')
            .limit(1)
            .timeout(const Duration(seconds: 45));
      }
    } catch (error) {
      if (!mounted) return;
      setState(() {
        importingPolizas = false;
        resultadoCargaPolizas =
            'La carga no se ha iniciado.\n${_detalleErrorImportacion(error)}';
      });
      return;
    }
    Directory? directorio;
    try {
      if (!kIsWeb) {
        directorio = await getApplicationSupportDirectory();
        await directorio.create(recursive: true);
      }
    } catch (error) {
      // El informe local es opcional. Un plugin de archivos no disponible
      // nunca debe impedir el guardado de pólizas en Supabase.
      directorio = null;
      debugPrint(
        'Informe local no disponible; se conserva el resumen en pantalla: $error',
      );
    }
    if (!mounted) return;
    setState(() {
      importingPolizas = true;
      polizasImportProgress = 0;
      polizasImportTotal = pendientes.length;
      resultadoCargaPolizas = null;
      erroresCargaPolizas = [];
      polizasGuardadasCarga = 0;
    });

    var ventasInsertadas = 0;
    var ventasPendientesGuardadas = 0;
    var ventasOmitidas = 0;
    final erroresDetalle = <String>[];
    final completadas = <int>{};
    final resultados = <Map<String, dynamic>>[];
    String? motivoInterrupcion;
    final informe = directorio == null
        ? null
        : File(
            '${directorio.path}/importacion_polizas_${DateTime.now().millisecondsSinceEpoch}.json',
          );
    informeCargaPolizasPath = informe?.path;

    Future<void> guardarInforme() async {
      if (informe == null) return;
      try {
        await informe.writeAsString(
          jsonEncode({
            'fecha': DateTime.now().toIso8601String(),
            'total': pendientes.length,
            'nuevas': ventasInsertadas,
            'pendientes_asignacion_guardadas': ventasPendientesGuardadas,
            'omitidas': ventasOmitidas,
            'errores': erroresDetalle,
            'resultados': resultados,
            'pendientes': pendientes
                .where((item) => !completadas.contains(item['fila']))
                .map((item) => item['numero_poliza'])
                .toList(),
          }),
          flush: true,
        );
      } catch (error) {
        debugPrint('No se pudo guardar el informe de importación: $error');
      }
    }

    for (final item in pendientes) {
      if (!mounted) break;
      final row = List<dynamic>.from(item['row'] as List);
      final filaExcel = item['fila'] as int;
      String? clienteCreadoId;
      String operacionImportacion = 'Comprobar si la poliza ya existe';

      try {
        // Reconsultar antes de escribir permite reanudar una carga parcial
        // sin usar el listado de existentes que pudo quedar desactualizado.
        final existenteAhora = await supabase
            .rpc(
              'app_polizas_ya_importadas',
              params: {
                'p_numeros': [item['numero_poliza'].toString()],
              },
            )
            .timeout(const Duration(seconds: 45));
        if ((existenteAhora as List).isNotEmpty) {
          ventasOmitidas++;
          completadas.add(filaExcel);
          resultados.add({
            'fila': filaExcel,
            'numero_poliza': item['numero_poliza'],
            'resultado': 'omitida: ya registrada',
          });
          if (mounted) setState(() => polizasImportProgress++);
          continue;
        }
        final agenteAuthId = item['agente_auth_id']?.toString();
        final numeroPoliza = item['numero_poliza'].toString();
        operacionImportacion = 'Preparar y convertir los datos del Excel';

        final tomadorCompleto =
            valorPolizaMapeado(row, 'cliente.nombre')?.toString().trim() ?? '';

        if (tomadorCompleto.isEmpty) {
          throw Exception('Falta el nombre del tomador.');
        }

        final apellido1 =
            valorPolizaMapeado(row, 'aux.apellido_1')?.toString().trim() ?? '';
        final apellido2 =
            valorPolizaMapeado(row, 'aux.apellido_2')?.toString().trim() ?? '';
        final apellidosSeparados = [
          apellido1,
          apellido2,
        ].where((e) => e.isNotEmpty).join(' ').trim();

        final datosTomador = apellidosSeparados.isNotEmpty
            ? {'nombre': tomadorCompleto, 'apellidos': apellidosSeparados}
            : separarNombreApellidos(tomadorCompleto);

        final producto = valorPolizaMapeado(
          row,
          'venta.producto',
        )?.toString().trim();
        final formaPago = importPaymentFrequency(
          valorPolizaMapeado(row, 'venta.forma_pago'),
        );
        final primaBrutaExcel = toDoublePoliza(
          valorPolizaMapeado(row, 'venta.prima_anual_bruta'),
        );
        final primaNeta = toDoublePoliza(
          valorPolizaMapeado(row, 'venta.prima_anual_neta'),
        );

        if (primaNeta == null) {
          throw Exception('Falta o no es válida la prima anual neta.');
        }
        if (primaBrutaExcel == null) {
          throw Exception('Falta o no es válida la prima total.');
        }

        final primaAnual = primaBrutaExcel;

        final fechaEfecto = toFechaSupabase(
          valorPolizaMapeado(row, 'venta.fecha_efecto'),
        );
        if (producto == null || producto.isEmpty) {
          throw Exception('Falta el producto o ramo de la póliza.');
        }
        if (fechaEfecto == null) {
          throw Exception(
            'Falta la fecha de efecto o su formato no es válido.',
          );
        }
        if (primaNeta < 0) {
          throw Exception('La prima anual neta no puede ser negativa.');
        }
        if (primaBrutaExcel < 0) {
          throw Exception('La prima anual bruta no puede ser negativa.');
        }
        if (primaAnual < 0) {
          throw Exception('La prima anual no puede ser negativa.');
        }

        final dni = valorPolizaMapeado(
          row,
          'cliente.dni',
        )?.toString().trim().toUpperCase();
        final email = valorPolizaMapeado(
          row,
          'cliente.email',
        )?.toString().trim().toLowerCase();

        Map<String, dynamic>? clienteExistente;

        if (agenteAuthId != null && dni != null && dni.isNotEmpty) {
          operacionImportacion = 'Buscar cliente por NIF en clientes';
          clienteExistente = await supabase
              .from('clientes')
              .select('id')
              .eq('auth_id', agenteAuthId)
              .eq('dni', dni)
              .limit(1)
              .maybeSingle()
              .timeout(const Duration(seconds: 45));
        } else if (agenteAuthId != null && email != null && email.isNotEmpty) {
          operacionImportacion = 'Buscar cliente por email en clientes';
          clienteExistente = await supabase
              .from('clientes')
              .select('id')
              .eq('auth_id', agenteAuthId)
              .eq('email', email)
              .limit(1)
              .maybeSingle()
              .timeout(const Duration(seconds: 45));
        }

        if (clienteExistente == null &&
            item['cliente_id_existente'] != null &&
            item['agente_anterior']?.toString() == agenteAuthId) {
          clienteExistente = {'id': item['cliente_id_existente']};
        }

        final telefono =
            valorPolizaMapeado(row, 'aux.movil') ??
            valorPolizaMapeado(row, 'cliente.telefono');
        final clienteData = limpiarNulls({
          'auth_id': agenteAuthId,
          'nombre': datosTomador['nombre'],
          'apellidos': datosTomador['apellidos'],
          'telefono': telefono?.toString(),
          'email': email,
          'codigo_postal': importPostalCode(
            valorPolizaMapeado(row, 'cliente.codigo_postal'),
          ),
          'provincia': importProvince(
            valorPolizaMapeado(row, 'cliente.provincia'),
            valorPolizaMapeado(row, 'cliente.codigo_postal'),
          ),
          'poblacion': valorPolizaMapeado(row, 'cliente.poblacion'),
          'direccion': valorPolizaMapeado(row, 'cliente.direccion'),
          'numero': importAddressNumber(
            valorPolizaMapeado(row, 'cliente.numero'),
          ),
          'dni': dni,
        });
        if (clienteExistente == null) {
          clienteData.addAll(importNewClientContacts(clienteData));
        }

        final ventaData = limpiarNulls({
          'agente_auth_id': agenteAuthId,
          'producto': producto,
          'compania': valorPolizaMapeado(row, 'venta.compania'),
          'forma_pago': formaPago,
          'precio': primaBrutaExcel,
          'numero_asegurados': toIntPoliza(
            valorPolizaMapeado(row, 'venta.numero_asegurados'),
          ),
          'fecha_efecto': fechaEfecto,
          'prima_anual': primaAnual,
          'prima_anual_bruta': primaBrutaExcel,
          'prima_anual_neta': primaNeta,
          'comision':
              toDoublePoliza(valorPolizaMapeado(row, 'venta.comision')) ?? 0,
          'categoria_producto':
              valorPolizaMapeado(row, 'venta.categoria_producto') ?? producto,
          'numero_poliza': numeroPoliza,
          'estado_poliza':
              valorPolizaMapeado(row, 'venta.estado_poliza') ?? 'ACTIVA',
        });
        if (agenteAuthId == null) {
          operacionImportacion =
              'Guardar en polizas_pendientes_asignacion mediante app_importar_poliza_pendiente';
          final pendienteId = await supabase
              .rpc(
                'app_importar_poliza_pendiente',
                params: {
                  'p_numero_poliza': numeroPoliza,
                  'p_agente_nombre': item['colaborador'].toString(),
                  'p_cliente_datos': clienteData,
                  'p_venta_datos': ventaData,
                },
              )
              .timeout(const Duration(seconds: 45));
          if (pendienteId == null) {
            ventasOmitidas++;
          } else {
            ventasPendientesGuardadas++;
          }
        } else {
          late String clienteId;
          if (clienteExistente != null) {
            operacionImportacion = 'Actualizar cliente existente en clientes';
            clienteId = clienteExistente['id'].toString();
            await supabase
                .from('clientes')
                .update(clienteData)
                .eq('id', clienteId)
                .select('id')
                .single()
                .timeout(const Duration(seconds: 45));
          } else {
            operacionImportacion = 'Crear cliente en clientes';
            final clienteResponse = await supabase
                .from('clientes')
                .insert(clienteData)
                .select('id')
                .single()
                .timeout(const Duration(seconds: 45));
            clienteId = clienteResponse['id'].toString();
            clienteCreadoId = clienteId;
          }
          ventaData['cliente_id'] = clienteId;
          operacionImportacion = 'Insertar poliza en ventas';
          await supabase
              .from('ventas')
              .insert(ventaData)
              .select('id')
              .single()
              .timeout(const Duration(seconds: 45));
          ventasInsertadas++;
        }
        clienteCreadoId = null;
        completadas.add(filaExcel);
        resultados.add({
          'fila': filaExcel,
          'numero_poliza': numeroPoliza,
          'resultado': agenteAuthId == null
              ? 'nueva pendiente de asignación'
              : 'nueva',
        });
      } catch (e, stackTrace) {
        // Un timeout no prueba que el servidor no haya guardado la venta.
        // Conservar el cliente permite reconciliarla en el siguiente intento.
        if (clienteCreadoId != null &&
            e is! TimeoutException &&
            e is! SocketException) {
          try {
            await supabase
                .from('clientes')
                .delete()
                .eq('id', clienteCreadoId)
                .timeout(const Duration(seconds: 45));
          } catch (rollbackError) {
            debugPrint(
              'ERROR LIMPIANDO CLIENTE DE FILA $filaExcel: '
              '$rollbackError',
            );
          }
        }

        final motivo = _detalleErrorImportacion(e);
        // Registro explicito solicitado para ver el motivo en consola,
        // tanto en Flutter como en las herramientas del navegador.
        print(
          '[IMPORTACION POLIZAS] ERROR #${erroresDetalle.length + 1} '
          '| fila Excel: $filaExcel | poliza: ${item['numero_poliza']} '
          '| operacion: $operacionImportacion | tipo: ${e.runtimeType}',
        );
        print('[IMPORTACION POLIZAS] MOTIVO COMPLETO:\n$motivo');
        print('[IMPORTACION POLIZAS] STACK TRACE:\n$stackTrace');
        final detalle = 'Fila $filaExcel: $motivo';
        erroresDetalle.add(detalle);
        erroresCargaPolizas.add({...item, 'motivo': motivo});
        resultados.add({
          'fila': filaExcel,
          'numero_poliza': item['numero_poliza'],
          'resultado': 'error',
          'motivo': motivo,
        });
        if (_falloGlobalImportacion(e)) motivoInterrupcion = motivo;
        debugPrint('ERROR FILA CARGA PÓLIZA: $detalle');
      }

      if (mounted) {
        setState(() {
          polizasImportProgress++;
          polizasGuardadasCarga = ventasInsertadas + ventasPendientesGuardadas;
        });
        if (resultados.isNotEmpty && resultados.last['resultado'] == 'error') {
          print(
            '[IMPORTACION POLIZAS] CONTADOR '
            'Procesadas: $polizasImportProgress/$polizasImportTotal '
            '| Guardadas: $polizasGuardadasCarga '
            '| Errores: ${erroresCargaPolizas.length}',
          );
        }
      }
      if (resultados.length % 20 == 0 || motivoInterrupcion != null) {
        await guardarInforme();
      }
      // Un error de datos afecta solo a su fila. Una averia global debe
      // detenerse con un motivo visible y conservar todas las pendientes.
      if (motivoInterrupcion != null) break;
    }

    await guardarInforme();
    if (!mounted) return;

    setState(() {
      importingPolizas = false;
      polizasNuevasValidadas.removeWhere(
        (item) => completadas.contains(item['fila']),
      );
      polizasExistentesValidadas.removeWhere(
        (item) => completadas.contains(item['fila']),
      );
      polizasPendientesAsignacion.removeWhere(
        (item) => completadas.contains(item['fila']),
      );
      resultadoCargaPolizas =
          'Resultado: $ventasInsertadas nuevas asignadas · $ventasPendientesGuardadas guardadas sin asignar · $ventasOmitidas omitidas por existir · '
          '${erroresDetalle.length} errores · '
          '${pendientes.length - completadas.length} pendientes de guardar'
          '${motivoInterrupcion == null ? '' : '\nCarga interrumpida: $motivoInterrupcion'}';
    });

    final errores = erroresDetalle.length;
    final resumen =
        'Carga finalizada: $ventasInsertadas nuevas · '
        '$ventasPendientesGuardadas guardadas sin asignar · $ventasOmitidas omitidas · $errores errores';

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          errores == 0
              ? resumen
              : '$resumen\n${erroresDetalle.take(3).join('\n')}',
        ),
        backgroundColor: errores == 0 ? Colors.green : Colors.orange,
        duration: const Duration(seconds: 8),
      ),
    );
  }

  Future<void> importarPolizasMasivasASupabaseLegacy() async {
    if (polizasRows.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Primero selecciona un archivo")),
      );
      return;
    }

    final supabase = Supabase.instance.client;

    setState(() {
      importingPolizas = true;
      polizasImportProgress = 0;
      polizasImportTotal = polizasRows.length;
    });

    int ventasInsertadas = 0;
    int errores = 0;

    try {
      for (final row in polizasRows) {
        try {
          final colaboradorNombre = valorPolizaMapeado(
            row,
            'aux.colaborador_nombre',
          )?.toString().trim();

          if (colaboradorNombre == null || colaboradorNombre.isEmpty) {
            throw Exception('La fila no contiene Colaborador 1.');
          }

          final agenteAuthId = await resolverAgenteAuthId(colaboradorNombre);

          if (agenteAuthId == null || agenteAuthId.trim().isEmpty) {
            throw Exception(
              'No se ha encontrado en usuarios al agente: '
              '$colaboradorNombre',
            );
          }

          final tomadorCompleto =
              valorPolizaMapeado(row, 'cliente.nombre')?.toString().trim() ??
              '';

          final datosTomador = separarNombreApellidos(tomadorCompleto);

          final clienteData = limpiarNulls({
            'auth_id': agenteAuthId,

            'nombre': datosTomador['nombre'],
            'apellidos': datosTomador['apellidos'],

            'telefono': valorPolizaMapeado(row, 'cliente.telefono'),

            'email': valorPolizaMapeado(row, 'cliente.email'),

            'codigo_postal': valorPolizaMapeado(row, 'cliente.codigo_postal'),

            'provincia': valorPolizaMapeado(row, 'cliente.provincia'),

            'poblacion': valorPolizaMapeado(row, 'cliente.poblacion'),

            'direccion': valorPolizaMapeado(row, 'cliente.direccion'),

            'numero': valorPolizaMapeado(row, 'cliente.numero'),

            'dni': valorPolizaMapeado(row, 'cliente.dni'),
          });

          final clienteResponse = await supabase
              .from('clientes')
              .insert(clienteData)
              .select('id')
              .single();

          final clienteId = clienteResponse['id'];

          final producto = valorPolizaMapeado(
            row,
            'venta.producto',
          )?.toString();
          final formaPago = valorPolizaMapeado(
            row,
            'venta.forma_pago',
          )?.toString();

          final precio = toDoublePoliza(
            valorPolizaMapeado(row, 'venta.precio'),
          );

          final primaAnualExcel = toDoublePoliza(
            valorPolizaMapeado(row, 'venta.prima_anual'),
          );

          final primaBrutaExcel = toDoublePoliza(
            valorPolizaMapeado(row, 'venta.prima_anual_bruta'),
          );

          final primaNetaExcel = toDoublePoliza(
            valorPolizaMapeado(row, 'venta.prima_anual_neta'),
          );

          final comisionExcel = toDoublePoliza(
            valorPolizaMapeado(row, 'venta.comision'),
          );

          /*
 * La prima anual puede seguir deduciéndose desde el precio y
 * la periodicidad porque esto no tiene relación con impuestos.
 *
 * Mensual   → precio × 12
 * Trimestral → precio × 4
 * Semestral → precio × 2
 * Anual     → precio
 */
          final primaAnual =
              primaAnualExcel ??
              (precio == null
                  ? null
                  : calcularPrimaAnualMasiva(
                      precio: precio,
                      formaPago: formaPago,
                    ));

          /*
 * La prima neta y la comisión nunca se recalculan aquí.
 * Deben venir expresamente informadas en el Excel.
 */
          final primaNeta = primaNetaExcel;
          final comision = comisionExcel;

          if (primaNeta == null) {
            throw Exception('La fila no contiene prima_anual_neta.');
          }

          if (comision == null) {
            throw Exception('La fila no contiene comision.');
          }

          final ventaData = limpiarNulls({
            'cliente_id': clienteId,
            'agente_auth_id': agenteAuthId,

            'producto': producto,
            'compania': valorPolizaMapeado(row, 'venta.compania'),
            'forma_pago': formaPago,

            'precio': precio,
            'numero_asegurados': toIntPoliza(
              valorPolizaMapeado(row, 'venta.numero_asegurados'),
            ),

            'fecha_efecto': toFechaSupabase(
              valorPolizaMapeado(row, 'venta.fecha_efecto'),
            ),

            'prima_anual': primaAnual,

            'prima_anual_bruta': primaBrutaExcel ?? primaAnual,

            'prima_anual_neta': primaNeta,

            'comision': comision,

            'categoria_producto':
                valorPolizaMapeado(row, 'venta.categoria_producto') ?? producto,

            'numero_poliza': valorPolizaMapeado(row, 'venta.numero_poliza'),
            'estado_poliza':
                valorPolizaMapeado(row, 'venta.estado_poliza') ?? 'ACTIVA',
          });

          await supabase.from('ventas').insert(ventaData);

          ventasInsertadas++;
        } catch (e) {
          errores++;
          debugPrint("ERROR FILA CARGA PÓLIZA: $e");
        }

        setState(() {
          polizasImportProgress++;
        });
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "Carga finalizada: $ventasInsertadas ventas importadas · $errores errores",
          ),
          backgroundColor: errores == 0 ? Colors.green : Colors.orange,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Error en carga masiva: $e"),
          backgroundColor: Colors.red,
        ),
      );
    }

    setState(() {
      importingPolizas = false;
    });
  }

  Widget _buildListadoValidacionPolizas({
    required String titulo,
    required String descripcion,
    required Color color,
    required IconData icono,
    required List<Map<String, dynamic>> datos,
    VoidCallback? onDescargar,
  }) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: ExpansionTile(
        leading: CircleAvatar(
          backgroundColor: color.withOpacity(0.12),
          foregroundColor: color,
          child: Icon(icono),
        ),
        title: Text(
          '$titulo (${datos.length})',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(descripcion),
        trailing: onDescargar == null
            ? null
            : OutlinedButton.icon(
                onPressed: onDescargar,
                icon: const Icon(Icons.download_rounded, size: 18),
                label: const Text('Descargar Excel'),
              ),
        children: [
          if (datos.isEmpty)
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 0, 20, 18),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('No hay pólizas en este listado.'),
              ),
            )
          else
            Container(
              constraints: const BoxConstraints(maxHeight: 300),
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: ProgressiveListView.separated(
                shrinkWrap: true,
                itemCount: datos.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, index) {
                  final item = datos[index];
                  final detalle =
                      item['motivo']?.toString() ??
                      item['agente_nombre']?.toString() ??
                      '';
                  return ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    title: Text(
                      '${item['numero_poliza'] ?? 'Sin número'} · ${item['tomador'] ?? ''}',
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                    subtitle: Text(
                      'Fila ${item['fila']} · ${item['colaborador'] ?? ''}'
                      '${detalle.isEmpty ? '' : ' · $detalle'}',
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }

  Widget buildCargaMasivaPolizas() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Carga Masiva de Pólizas",
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          ),

          const SizedBox(height: 8),

          Text(
            "Importa ventas completas desde Excel o CSV. Se crearán clientes y ventas en Supabase.",
            style: TextStyle(color: Colors.grey.shade600, fontSize: 14),
          ),

          const SizedBox(height: 24),

          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: Colors.grey.shade300),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: Colors.indigo.shade50,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Icon(
                    Icons.cloud_upload_rounded,
                    color: Colors.indigo.shade700,
                    size: 36,
                  ),
                ),

                const SizedBox(width: 14),

                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Importador inteligente",
                        style: TextStyle(
                          fontSize: 21,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        "Detecta columnas automáticamente y permite corregir el mapeo antes de subir.",
                        style: TextStyle(color: Colors.grey),
                      ),
                    ],
                  ),
                ),

                ElevatedButton.icon(
                  onPressed: importingPolizas
                      ? null
                      : seleccionarArchivoPolizas,
                  icon: const Icon(Icons.file_open_rounded),
                  label: const Text("Seleccionar archivo"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.indigo.shade700,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 16,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          if (resultadoCargaPolizas != null) ...[
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SelectableText(
                      resultadoCargaPolizas!,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Las pendientes se conservan. Puedes volver a guardar para continuar la carga.',
                    ),
                    if (informeCargaPolizasPath != null)
                      TextButton.icon(
                        onPressed: () =>
                            OpenFilex.open(informeCargaPolizasPath!),
                        icon: const Icon(Icons.description_outlined),
                        label: const Text('Abrir informe de la carga'),
                      ),
                  ],
                ),
              ),
            ),
            if (erroresCargaPolizas.isNotEmpty)
              _buildListadoValidacionPolizas(
                titulo: 'Errores al guardar en Supabase',
                descripcion:
                    'Estas pólizas siguen pendientes. El motivo real aparece en cada fila.',
                color: Colors.red,
                icono: Icons.error_outline,
                datos: erroresCargaPolizas,
                onDescargar: () => exportarListadoPolizas(
                  erroresCargaPolizas,
                  'errores_ultima_carga_polizas',
                ),
              ),
          ],
          if (polizasHeaders.isNotEmpty) buildMapeoPolizas(),

          const SizedBox(height: 20),

          if (polizasPreview.isNotEmpty) buildPreviewPolizas(),

          const SizedBox(height: 20),

          if (polizasRows.isNotEmpty)
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: validandoPolizas || importingPolizas
                    ? null
                    : validarImportacionPolizas,
                icon: validandoPolizas
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2,
                        ),
                      )
                    : const Icon(Icons.fact_check_rounded),
                label: Text(
                  validandoPolizas
                      ? 'Analizando pólizas y agentes...'
                      : 'Analizar antes de guardar',
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.indigo.shade700,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
              ),
            ),

          if (polizasNuevasValidadas.isNotEmpty ||
              polizasPendientesAsignacion.isNotEmpty ||
              polizasSinAgente.isNotEmpty ||
              polizasExistentesValidadas.isNotEmpty) ...[
            const SizedBox(height: 20),
            _buildListadoValidacionPolizas(
              titulo: '1. Nuevas con agente identificado',
              descripcion: 'Se crearán en clientes y ventas al guardar.',
              color: Colors.green,
              icono: Icons.verified_rounded,
              datos: polizasNuevasValidadas,
            ),
            const SizedBox(height: 12),
            _buildListadoValidacionPolizas(
              titulo: 'Filas inválidas / repetidas en el Excel',
              descripcion:
                  'Datos inválidos o filas repetidas: no se enviarán a Supabase.',
              color: Colors.red,
              icono: Icons.person_off_rounded,
              datos: polizasSinAgente,
              onDescargar: polizasSinAgente.isEmpty
                  ? null
                  : () => exportarListadoPolizas(
                      polizasSinAgente,
                      'polizas_no_importadas',
                    ),
            ),
            const SizedBox(height: 12),
            _buildListadoValidacionPolizas(
              titulo: '2. Nuevas pendientes de asignación',
              descripcion:
                  'Se guardarán en Supabase con los datos y el nombre completo del agente del Excel.',
              color: Colors.blue,
              icono: Icons.person_search_rounded,
              datos: polizasPendientesAsignacion,
              onDescargar: polizasPendientesAsignacion.isEmpty
                  ? null
                  : () => exportarListadoPolizas(
                      polizasPendientesAsignacion,
                      'polizas_pendientes_asignacion',
                    ),
            ),
            const SizedBox(height: 12),
            _buildListadoValidacionPolizas(
              titulo: '3. Pólizas ya registradas',
              descripcion:
                  'Se omiten. No se guardan ni se modifican sus datos.',
              color: Colors.orange,
              icono: Icons.sync_rounded,
              datos: polizasExistentesValidadas,
              onDescargar: polizasExistentesValidadas.isEmpty
                  ? null
                  : () => exportarListadoPolizas(
                      polizasExistentesValidadas,
                      'polizas_existentes_omitidas',
                    ),
            ),
          ],

          const SizedBox(height: 20),

          if (polizasRows.isNotEmpty)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Filas detectadas: ${polizasRows.length}",
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 17,
                    ),
                  ),

                  const SizedBox(height: 12),

                  if (importingPolizas)
                    LinearProgressIndicator(
                      value: polizasImportTotal == 0
                          ? 0
                          : polizasImportProgress / polizasImportTotal,
                      minHeight: 8,
                      borderRadius: BorderRadius.circular(20),
                    ),

                  if (importingPolizas) const SizedBox(height: 8),

                  if (importingPolizas)
                    Text(
                      "Procesadas: $polizasImportProgress / $polizasImportTotal · Guardadas: $polizasGuardadasCarga · Errores: ${erroresCargaPolizas.length}",
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),

                  const SizedBox(height: 16),

                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: ElevatedButton.icon(
                      onPressed:
                          importingPolizas ||
                              validandoPolizas ||
                              (polizasNuevasValidadas.isEmpty &&
                                  polizasPendientesAsignacion.isEmpty)
                          ? null
                          : importarPolizasMasivasASupabase,
                      icon: importingPolizas
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                color: Colors.white,
                                strokeWidth: 2,
                              ),
                            )
                          : const Icon(Icons.save_alt_rounded),
                      label: Text(
                        importingPolizas
                            ? "Subiendo pólizas..."
                            : "Guardar validadas en Supabase",
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green.shade700,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget buildMapeoPolizas() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  "Mapeo de columnas",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ),
              OutlinedButton.icon(
                onPressed: () {
                  autoMapearPolizas();
                  setState(() {
                    polizasNuevasValidadas = [];
                    polizasSinAgente = [];
                    polizasPendientesAsignacion = [];
                    polizasExistentesValidadas = [];
                  });
                },
                icon: const Icon(Icons.auto_fix_high_rounded),
                label: const Text("Auto-mapear"),
              ),
            ],
          ),

          const SizedBox(height: 14),

          ...polizasHeaders.map((header) {
            final key = _normalizarCabeceraPoliza(header);

            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: Text(
                      header.trim(),
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),

                  const SizedBox(width: 12),

                  Expanded(
                    flex: 3,
                    child: DropdownButtonFormField<String>(
                      value: polizasColumnMapping[key],
                      isExpanded: true,
                      decoration: InputDecoration(
                        labelText: "Campo destino",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 12,
                        ),
                      ),
                      items: [
                        const DropdownMenuItem<String>(
                          value: null,
                          child: Text("No importar"),
                        ),
                        ...camposCargaPolizas.map((campo) {
                          return DropdownMenuItem<String>(
                            value: campo,
                            child: Text(campo),
                          );
                        }),
                      ],
                      onChanged: (value) {
                        setState(() {
                          polizasNuevasValidadas = [];
                          polizasSinAgente = [];
                          polizasPendientesAsignacion = [];
                          polizasExistentesValidadas = [];
                          if (value == null) {
                            polizasColumnMapping.remove(key);
                          } else {
                            polizasColumnMapping.removeWhere(
                              (origen, destino) =>
                                  origen != key && destino == value,
                            );
                            polizasColumnMapping[key] = value;
                          }
                        });
                      },
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget buildPreviewPolizas() {
    return Container(
      height: 360,
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Vista previa",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
          ),

          const SizedBox(height: 12),

          Expanded(
            child: Scrollbar(
              controller: _polizasPreviewHorizontal,
              notificationPredicate: (notification) =>
                  notification.metrics.axis == Axis.horizontal,
              thumbVisibility: true,
              child: SingleChildScrollView(
                controller: _polizasPreviewHorizontal,
                scrollDirection: Axis.horizontal,
                child: SingleChildScrollView(
                  controller: _polizasPreviewVertical,
                  primary: false,
                  child: ProgressiveRecords(
                    count: (polizasPreview.length - 1).clamp(
                      0,
                      polizasPreview.length,
                    ),
                    resetKey: progressiveRecordKey(polizasPreview),
                    showFooter: true,
                    builder: (context, _visibleRows) => DataTable(
                      headingRowColor: WidgetStateProperty.all(
                        Colors.grey.shade100,
                      ),
                      columns: polizasPreview.first.map((e) {
                        return DataColumn(
                          label: Text(
                            e.toString(),
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                        );
                      }).toList(),
                      rows: polizasPreview.skip(1).take(_visibleRows).map((
                        row,
                      ) {
                        return DataRow(
                          cells: row.map((cell) {
                            return DataCell(
                              Text(
                                cell.toString(),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            );
                          }).toList(),
                        );
                      }).toList(),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> inicializarPermisosERP() async {
    try {
      print("ERP -> 1 INICIO");

      if (mounted) {
        setState(() {
          cargandoPermisosERP = true;
        });
      }

      await cargarPermisosERP();

      print("ERP -> 2 permisos cargados");
      print("ACCESO ERP: $accesoAdminPanelERP");
      print("VE TODO ERP: $veTodoERP");
      print("AUTH IDS PERMITIDOS: ${authIdsPermitidosERP.length}");

    } catch (e, stack) {
      debugPrint("❌ ERROR GENERAL inicializarPermisosERP: $e");
      debugPrintStack(stackTrace: stack);
    } finally {
      if (mounted) {
        setState(() {
          cargandoPermisosERP = false;
        });
      }

      print("ERP -> FIN");
    }
  }

  Future<void> cargarPermisosERP() async {
    _panelRequests.clear();
    _agentesErpFuture = null;
    _receiptFiltersFuture = null;
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;

    if (user == null) {
      accesoAdminPanelERP = false;
      authIdsPermitidosERP = [];
      usuarioActualERP = null;
      return;
    }

    final usuarioResponse = await supabase
        .from('usuarios')
        .select('id, auth_id, rol_usuario, parent_id, nombre, apellidos, email')
        .eq('auth_id', user.id)
        .maybeSingle();

    if (usuarioResponse == null) {
      accesoAdminPanelERP = false;
      authIdsPermitidosERP = [];
      usuarioActualERP = null;
      return;
    }

    final usuario = Map<String, dynamic>.from(usuarioResponse);

    usuarioActualERP = usuario;

    final rol = _normalizarRolERP(usuario['rol_usuario']);

    debugPrint('===================================');
    debugPrint('USUARIO ERP: ${usuario['nombre']} ${usuario['apellidos']}');
    debugPrint('ROL REAL ERP: $rol');
    debugPrint('AUTH ID ERP: ${usuario['auth_id']}');
    debugPrint('ID INTERNO ERP: ${usuario['id']}');
    debugPrint('===================================');

    const rolesPermitidos = {
      'jefe_equipo',
      'jefe_ventas',
      'director_zona',
      'director_nacional',
      'admin',
      'administracion',
    };

    accesoAdminPanelERP = rolesPermitidos.contains(rol);

    if (!accesoAdminPanelERP) {
      authIdsPermitidosERP = [];
      return;
    }

    /*
   * Únicamente administración puede verlo todo.
   */
    if (rol == 'admin' || rol == 'administracion') {
      authIdsPermitidosERP = [];

      debugPrint('ERP: administración puede ver toda la base de datos');
      return;
    }

    final usuariosResponse = await supabase
        .from('usuarios')
        .select('id, auth_id, parent_id, rol_usuario, nombre, apellidos');

    final usuarios = List<Map<String, dynamic>>.from(usuariosResponse);

    final porParentId = <String, List<Map<String, dynamic>>>{};

    for (final usuarioLista in usuarios) {
      final parentId = usuarioLista['parent_id']?.toString().trim() ?? '';

      if (parentId.isEmpty || parentId.toLowerCase() == 'null') {
        continue;
      }

      porParentId
          .putIfAbsent(parentId, () => <Map<String, dynamic>>[])
          .add(usuarioLista);
    }

    final permitidos = <String>{};
    final visitados = <String>{};

    int nivelRol(dynamic rol) {
      switch (_normalizarRolERP(rol)) {
        case 'director_nacional':
          return 5;

        case 'director_zona':
          return 4;

        case 'jefe_ventas':
          return 3;

        case 'jefe_equipo':
          return 2;

        case 'agente':
          return 1;

        default:
          return 0;
      }
    }

    void recorrerEstructura(Map<String, dynamic> usuarioActual) {
      final usuarioId = usuarioActual['id']?.toString().trim() ?? '';

      final authId = usuarioActual['auth_id']?.toString().trim() ?? '';

      if (usuarioId.isEmpty || visitados.contains(usuarioId)) {
        return;
      }

      visitados.add(usuarioId);

      if (authId.isNotEmpty && authId.toLowerCase() != 'null') {
        permitidos.add(authId);
      }

      final nivelActual = nivelRol(usuarioActual['rol_usuario']);

      if (nivelActual <= 0) {
        return;
      }

      final hijos = porParentId[usuarioId] ?? <Map<String, dynamic>>[];

      for (final hijo in hijos) {
        final nivelHijo = nivelRol(hijo['rol_usuario']);

        /*
     * Solo se admite un usuario que:
     * 1. tenga parent_id real del usuario actual;
     * 2. tenga un nivel inferior;
     * 3. no sea compañero ni superior.
     */
        if (nivelHijo <= 0 || nivelHijo >= nivelActual) {
          continue;
        }

        recorrerEstructura(hijo);
      }
    }

    recorrerEstructura(usuario);

    authIdsPermitidosERP = permitidos.toList();

    debugPrint('========== PERMISOS ERP ==========');
    debugPrint('ROL: $rol');
    debugPrint('VE TODO: $veTodoERP');
    debugPrint('AUTH IDS PERMITIDOS: ${authIdsPermitidosERP.length}');

    for (final usuarioLista in usuarios) {
      final authId = usuarioLista['auth_id']?.toString() ?? '';

      if (permitidos.contains(authId)) {
        debugPrint(
          '- ${usuarioLista['nombre']} '
          '${usuarioLista['apellidos']} '
          '| ${usuarioLista['rol_usuario']}',
        );
      }
    }

    debugPrint('==================================');
  }

  bool get veTodoERP {
    final rol = _normalizarRolERP(usuarioActualERP?['rol_usuario']);

    return rol == 'admin' || rol == 'administracion';
  }

  bool get puedeGestionarUsuariosERP {
    final rol = _normalizarRolERP(usuarioActualERP?['rol_usuario']);
    return rol == 'admin' ||
        rol == 'administracion' ||
        rol == 'director_nacional';
  }

  String _normalizarRolERP(dynamic rol) {
    return (rol ?? '')
        .toString()
        .trim()
        .toLowerCase()
        .replaceAll('-', '_')
        .replaceAll(' ', '_')
        .replaceAll('ó', 'o');
  }

  String _nombreRolERP(dynamic rol) {
    switch (_normalizarRolERP(rol)) {
      case 'director_nacional':
        return 'Director nacional';

      case 'director_zona':
        return 'Director de zona';

      case 'jefe_ventas':
        return 'Jefe de ventas';

      case 'jefe_equipo':
        return 'Jefe de equipo';

      case 'agente':
        return 'Agente';

      case 'admin':
      case 'administracion':
        return 'Administración';

      default:
        return rol?.toString() ?? 'Usuario';
    }
  }

  @override
  Widget build(BuildContext context) {
    if (cargandoPermisosERP) {
      return const Scaffold(
        backgroundColor: Color(0xFFF3F6FA),
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (!accesoAdminPanelERP) {
      return Scaffold(
        backgroundColor: const Color(0xFFF3F6FA),
        body: Center(
          child: Container(
            width: 520,
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.lock_outline, size: 54, color: Colors.red),
                SizedBox(height: 16),
                Text(
                  "Acceso no autorizado",
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                Text(
                  "Esta pantalla solo está disponible para jefes, dirección y administración.",
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF3F6FA),
      body: Row(
        children: [
          // MENÚ IZQUIERDO ERP
          Container(
            width: 285,
            decoration: BoxDecoration(
              color: const Color(0xFF0F172A),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.12),
                  blurRadius: 18,
                  offset: const Offset(4, 0),
                ),
              ],
            ),
            child: Column(
              children: [
                const SizedBox(height: 34),

                // LOGO / MARCA
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 18),
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: Colors.white.withOpacity(0.08)),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Image.asset(
                        'assets/images/logo.png',
                        height: 85,
                        fit: BoxFit.contain,
                      ),

                      const SizedBox(height: 12),

                      const Text(
                        'Centro de Control',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 22),

                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    children: [
                      _menuSection("GENERAL"),

                      _menuItem(
                        "Dashboard",
                        "dashboard",
                        Icons.dashboard_rounded,
                      ),

                      _menuItem("Ventas", "ventas", Icons.euro_rounded),
                      if (_normalizarRolERP(usuarioActualERP?['rol_usuario']) ==
                          'director_nacional')
                        _menuItem(
                          'Ventas sin agentes',
                          'ventas_sin_agentes',
                          Icons.person_search_rounded,
                        ),

                      _menuItem(
                        "Clientes",
                        "clientes",
                        Icons.people_alt_rounded,
                      ),

                      const SizedBox(height: 14),

                      _menuSection("RECIBOS"),

                      _menuItem(
                        "Recibos Cobrados",
                        "recibos_cobrados",
                        Icons.check_circle_rounded,
                      ),

                      _menuItem(
                        "Recibos Devueltos",
                        "recibos_devueltos",
                        Icons.cancel_rounded,
                      ),

                      _menuItem(
                        "Recibos Pendientes",
                        "recibos_pendientes",
                        Icons.schedule_rounded,
                      ),

                      _menuItem(
                        "Cargar Recibos",
                        "cargar_recibos",
                        Icons.upload_file_rounded,
                      ),

                      _menuItem(
                        "Cargar Pólizas",
                        "cargar_polizas",
                        Icons.cloud_upload_rounded,
                      ),
                      const SizedBox(height: 14),

                      _menuSection("EQUIPO"),

                      _menuItem("Agentes", "agentes", Icons.person_rounded),

                      _menuItem("Jefes Equipo", "jefes", Icons.groups_rounded),

                      _menuItem(
                        "Referencias",
                        "referencias",
                        Icons.flag_rounded,
                      ),

                      _menuItem("Nóminas", "nominas", Icons.payments_rounded),

                      _menuItem(
                        "Incorporaciones",
                        "incorporaciones",
                        Icons.badge_outlined,
                      ),

                      const SizedBox(height: 14),

                      _menuSection("SISTEMA"),

                      if (puedeGestionarUsuariosERP)
                        _menuItem(
                          "Usuarios y accesos",
                          "usuarios_accesos",
                          Icons.manage_accounts_rounded,
                        ),

                      _menuItem("Mensajes", "mensajes", Icons.message_rounded),

                      _menuItem(
                        "Alertas",
                        "alertas",
                        Icons.notification_important_rounded,
                      ),

                      _menuItem(
                        "Configuración",
                        "configuracion",
                        Icons.settings_rounded,
                      ),
                    ],
                  ),
                ),

                // USUARIO ABAJO
                Container(
                  margin: const EdgeInsets.all(16),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: Colors.white.withOpacity(0.08)),
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 18,
                        backgroundColor: Colors.blue.shade600,
                        child: const Text(
                          "A",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${usuarioActualERP?['nombre'] ?? ''} '
                                      '${usuarioActualERP?['apellidos'] ?? ''}'
                                  .trim(),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              _nombreRolERP(usuarioActualERP?['rol_usuario']),
                              style: const TextStyle(
                                color: Colors.white60,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // CONTENIDO DERECHO
          Expanded(
            child: Column(
              children: [
                buildTopBar(),

                Expanded(
                  child: Container(
                    width: double.infinity,
                    color: const Color(0xFFF3F6FA),
                    padding: const EdgeInsets.all(22),
                    child: buildContent(),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _menuItem(String title, String value, IconData icon) {
    final selected = selectedMenu == value;

    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          setState(() {
            if (selectedMenu != value) _panelRequests.clear();
            selectedMenu = value;
          });

          if (value == "recibos_cobrados" ||
              value == "recibos_devueltos" ||
              value == "recibos_pendientes") {
            _receiptFiltersFuture ??= _prepareReceiptFilters();
          }
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
          decoration: BoxDecoration(
            color: selected ? Colors.blue.shade600 : Colors.transparent,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected
                  ? Colors.blue.shade400
                  : Colors.white.withOpacity(0.04),
            ),
          ),
          child: Row(
            children: [
              Icon(
                icon,
                size: 22,
                color: selected ? Colors.white : Colors.white70,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    color: selected ? Colors.white : Colors.white70,
                    fontWeight: selected ? FontWeight.bold : FontWeight.w500,
                    fontSize: 14,
                  ),
                ),
              ),
              if (selected)
                const Icon(
                  Icons.chevron_right_rounded,
                  color: Colors.white,
                  size: 20,
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _menuSection(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 10, right: 10, bottom: 8, top: 6),
      child: Text(
        title,
        style: TextStyle(
          color: Colors.white.withOpacity(0.38),
          fontSize: 11,
          fontWeight: FontWeight.bold,
          letterSpacing: 1.1,
        ),
      ),
    );
  }

  Widget buildTopBar() {
    final email = Supabase.instance.client.auth.currentUser?.email ?? "";

    return Container(
      height: 78,
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 25),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: Colors.grey.shade200)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(14),
            ),
            child: IconButton(
              tooltip: 'Volver',
              icon: Icon(
                Icons.arrow_back_ios_new_rounded,
                color: Colors.blue.shade700,
                size: 20,
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ),

          const SizedBox(width: 10),

          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(Icons.menu, size: 26, color: Colors.blue.shade700),
          ),

          const SizedBox(width: 15),

          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _nombreRolERP(usuarioActualERP?['rol_usuario']),
                style: const TextStyle(color: Colors.grey, fontSize: 12),
              ),
              Text(
                "SafeBrok ERP · Control operativo",
                style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
              ),
            ],
          ),

          const Spacer(),

          IconButton(
            tooltip: 'Actualizar datos del panel',
            onPressed: inicializarPermisosERP,
            icon: const Icon(Icons.refresh_rounded),
          ),
          FutureBuilder<int>(
            future: _panelRequests.get('notifications', contarNotificacionesPendientes),
            builder: (context, snapshot) {
              final pendientes = snapshot.data ?? 0;

              return InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () async {
                  await abrirNotificacionesDialog();
                  setState(() {});
                },
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(11),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: const Icon(Icons.notifications_outlined, size: 28),
                    ),

                    if (pendientes > 0)
                      Positioned(
                        right: -5,
                        top: -5,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 6,
                            vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.red.shade700,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: Colors.white, width: 2),
                          ),
                          child: Text(
                            pendientes > 99 ? "99+" : pendientes.toString(),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              );
            },
          ),

          const SizedBox(width: 26),

          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.grey.shade50,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.grey.shade300),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 18,
                  backgroundColor: Colors.blue.shade700,
                  child: Text(
                    email.isNotEmpty ? email[0].toUpperCase() : "A",
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

                const SizedBox(width: 10),

                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 210,
                      child: Text(
                        email,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    const Text(
                      "Administrador",
                      style: TextStyle(color: Colors.grey, fontSize: 12),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<int> contarNotificacionesPendientes() async {
    final email = Supabase.instance.client.auth.currentUser?.email;

    dynamic query = Supabase.instance.client
        .from('notificaciones')
        .select('id')
        .eq('leida', false);

    if (email != null && email.isNotEmpty) {
      query = query.or('usuario_email.eq.$email,usuario_email.is.null');
    }

    final data = await query;

    return data.length;
  }

  Future<void> abrirNotificacionesDialog() async {
    final email = Supabase.instance.client.auth.currentUser?.email;

    dynamic query = Supabase.instance.client.from('notificaciones').select();

    if (email != null && email.isNotEmpty) {
      query = query.or('usuario_email.eq.$email,usuario_email.is.null');
    }

    final notificaciones = await query.order('created_at', ascending: false);

    final pendientes = notificaciones.where((n) => n['leida'] != true).length;
    final leidas = notificaciones.where((n) => n['leida'] == true).length;

    await _showPanelDialog(
      context: context,
      builder: (_) {
        return Dialog(
          insetPadding: const EdgeInsets.symmetric(
            horizontal: 18,
            vertical: 24,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(26),
          ),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 900, maxHeight: 760),
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(26),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Colors.orange.shade50,
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Icon(
                        Icons.notifications_active_outlined,
                        color: Colors.orange.shade700,
                        size: 34,
                      ),
                    ),

                    const SizedBox(width: 14),

                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "Centro de notificaciones",
                            style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            "Avisos operativos, recibos, agentes, gestiones y documentación adjunta",
                            style: TextStyle(color: Colors.grey.shade600),
                          ),
                        ],
                      ),
                    ),

                    TextButton.icon(
                      onPressed: pendientes == 0
                          ? null
                          : () async {
                              dynamic updateQuery = Supabase.instance.client
                                  .from('notificaciones')
                                  .update({'leida': true})
                                  .eq('leida', false);

                              if (email != null && email.isNotEmpty) {
                                updateQuery = updateQuery.or(
                                  'usuario_email.eq.$email,usuario_email.is.null',
                                );
                              }

                              await updateQuery;

                              Navigator.pop(context);
                              await abrirNotificacionesDialog();
                            },
                      icon: const Icon(Icons.done_all),
                      label: const Text("Marcar todas"),
                    ),

                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.close),
                    ),
                  ],
                ),

                const SizedBox(height: 18),

                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    _kpiNotificacionERP(
                      "Pendientes",
                      pendientes.toString(),
                      Icons.mark_email_unread_outlined,
                      Colors.red,
                    ),
                    _kpiNotificacionERP(
                      "Leídas",
                      leidas.toString(),
                      Icons.mark_email_read_outlined,
                      Colors.green,
                    ),
                    _kpiNotificacionERP(
                      "Total",
                      notificaciones.length.toString(),
                      Icons.notifications_outlined,
                      Colors.blue,
                    ),
                  ],
                ),

                const SizedBox(height: 18),

                Expanded(
                  child: notificaciones.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.notifications_off_outlined,
                                size: 64,
                                color: Colors.grey.shade400,
                              ),
                              const SizedBox(height: 12),
                              const Text(
                                "No hay notificaciones",
                                style: TextStyle(
                                  fontSize: 19,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 5),
                              Text(
                                "Cuando haya avisos, recibos, gestiones o archivos compartidos aparecerán aquí.",
                                style: TextStyle(color: Colors.grey.shade600),
                              ),
                            ],
                          ),
                        )
                      : ProgressiveListView.builder(
                          itemCount: notificaciones.length,
                          itemBuilder: (context, index) {
                            final n = Map<String, dynamic>.from(
                              notificaciones[index],
                            );

                            final leida = n['leida'] == true;

                            return _tarjetaNotificacionERP(n, leida);
                          },
                        ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _kpiNotificacionERP(
    String titulo,
    String valor,
    IconData icono,
    MaterialColor color,
  ) {
    return Container(
      width: 180,
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.shade50,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icono, color: color.shade700, size: 24),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  titulo,
                  style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
                ),
                Text(
                  valor,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 19,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _tarjetaNotificacionERP(Map<String, dynamic> n, bool leida) {
    final tipo = n['tipo']?.toString() ?? 'general';
    final prioridad = n['prioridad']?.toString() ?? 'normal';

    IconData icono = Icons.notifications_outlined;
    Color color = Colors.blue;

    if (tipo.contains('recibo')) {
      icono = Icons.receipt_long_outlined;
      color = Colors.red;
    } else if (tipo.contains('gestion')) {
      icono = Icons.manage_accounts_outlined;
      color = Colors.deepPurple;
    } else if (tipo.contains('anulacion')) {
      icono = Icons.cancel_outlined;
      color = Colors.red;
    } else if (tipo.contains('poliza')) {
      icono = Icons.description_outlined;
      color = Colors.indigo;
    }

    if (prioridad == 'alta') {
      color = Colors.red;
    }

    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () async {
        await Supabase.instance.client
            .from('notificaciones')
            .update({'leida': true})
            .eq('id', n['id']);

        setState(() {});
        Navigator.pop(context);
        await abrirNotificacionesDialog();
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: leida ? Colors.grey.shade50 : color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: leida ? Colors.grey.shade300 : color.withOpacity(0.35),
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Icon(icono, color: color, size: 28),
                ),

                if (!leida)
                  Positioned(
                    right: 0,
                    top: 0,
                    child: Container(
                      width: 11,
                      height: 11,
                      decoration: BoxDecoration(
                        color: Colors.red.shade700,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 2),
                      ),
                    ),
                  ),
              ],
            ),

            const SizedBox(width: 14),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          n['titulo']?.toString() ?? 'Notificación',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: leida
                                ? FontWeight.w600
                                : FontWeight.bold,
                          ),
                        ),
                      ),

                      if (!leida)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 9,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.red.shade700,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Text(
                            "PENDIENTE",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                    ],
                  ),

                  const SizedBox(height: 6),

                  Text(
                    n['mensaje']?.toString() ?? '',
                    style: TextStyle(color: Colors.grey.shade700, height: 1.35),
                  ),

                  const SizedBox(height: 10),

                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _chipNotificacion("Tipo", tipo),
                      if ((n['poliza']?.toString() ?? '').isNotEmpty)
                        _chipNotificacion("Póliza", n['poliza'].toString()),
                      _chipNotificacion(
                        "Fecha",
                        n['created_at']?.toString().split('T').first ?? '',
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _chipNotificacion(String titulo, String valor) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Text(
        "$titulo: $valor",
        style: TextStyle(
          fontSize: 11,
          color: Colors.grey.shade700,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Future<void> crearNotificacionReciboDevuelto({
    required dynamic ventaId,
    required String poliza,
    required dynamic reciboId,
    required dynamic importe,
  }) async {
    await Supabase.instance.client.from('notificaciones').insert({
      'titulo': 'Recibo devuelto',
      'mensaje':
          'Se ha detectado un recibo devuelto de la póliza $poliza por importe de $importe €.',
      'tipo': 'recibo_devuelto',
      'leida': false,
      'venta_id': ventaId,
      'poliza': poliza,
      'recibo_id': reciboId,
      'usuario_email': Supabase.instance.client.auth.currentUser?.email,
      'prioridad': 'alta',
    });
  }

  Widget buildFilters() {
    return Text(
      "Filtros: $selectedMenu",
      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
    );
  }

  Widget buildContent() {
    // DASHBOARD
    if (selectedMenu == 'dashboard') {
      return buildDashboardPageERP();
    }

    // CARGAR RECIBOS
    if (selectedMenu == 'cargar_recibos') {
      return buildCargarRecibos();
    }
    if (selectedMenu == 'cargar_polizas') {
      return buildCargaMasivaPolizas();
    }

    if (selectedMenu == 'agentes') {
      return buildAgentesPageERP();
    }

    if (selectedMenu == 'incorporaciones') {
      return const IncorporacionesScreen();
    }
    if (selectedMenu == 'usuarios_accesos') {
      return UsuariosAccesosScreen(allowed: puedeGestionarUsuariosERP);
    }
    // CLIENTES
    if (selectedMenu == 'clientes') {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 210, child: buildDashboardKpis()),
          const SizedBox(height: 20),
          Expanded(child: buildClientesPage()),
        ],
      );
    }

    if (selectedMenu == 'ventas_sin_agentes') {
      if (_normalizarRolERP(usuarioActualERP?['rol_usuario']) !=
          'director_nacional') {
        return const Center(
          child: Text('Acceso exclusivo del director nacional.'),
        );
      }
      return const VentasSinAgentesScreen();
    }
    // VENTAS
    if (selectedMenu == 'ventas') {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 210, child: buildDashboardKpis()),
          const SizedBox(height: 20),
          Expanded(child: buildVentasPage()),
        ],
      );
    }

    // RECIBOS
    if (selectedMenu == 'recibos_cobrados' ||
        selectedMenu == 'recibos_devueltos' ||
        selectedMenu == 'recibos_pendientes') {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 210, child: buildDashboardKpis()),
          const SizedBox(height: 20),
          Expanded(child: buildRecibosPage(selectedMenu)),
        ],
      );
    }

    // DEFAULT
    return buildDashboardPageERP();
  }

  Future<List<Map<String, dynamic>>> getAgentesERP() async {
    try {
      final supabase = Supabase.instance.client;

      dynamic usuariosQuery = supabase
          .from('usuarios')
          .select(
            'id, auth_id, parent_id, nombre, apellidos, email, rol_usuario, estado',
          );

      if (!veTodoERP) {
        if (authIdsPermitidosERP.isEmpty) return [];

        usuariosQuery = usuariosQuery.inFilter('auth_id', authIdsPermitidosERP);
      }

      final usuariosResponse = await usuariosQuery;

      dynamic ventasQuery = supabase.from('ventas').select();

      if (!veTodoERP) {
        ventasQuery = ventasQuery.inFilter(
          'agente_auth_id',
          authIdsPermitidosERP,
        );
      }

      final ventasResponse = await ventasQuery;

      final usuarios = List<Map<String, dynamic>>.from(usuariosResponse);
      final ventas = List<Map<String, dynamic>>.from(ventasResponse);

      final agentes = <Map<String, dynamic>>[];

      for (final u in usuarios) {
        final authId = u['auth_id']?.toString() ?? '';

        final ventasAgente = ventas.where((v) {
          return v['agente_auth_id']?.toString() == authId;
        }).toList();

        final jefe = usuarios.firstWhere(
          (j) => j['id']?.toString() == u['parent_id']?.toString(),
          orElse: () => <String, dynamic>{},
        );

        final primaTotal = ventasAgente.fold<double>(0, (suma, v) {
          return suma + PremiumWeighting.gross(v);
        });

        final comisionTotal = ventasAgente.fold<double>(0, (suma, v) {
          return suma + _toDoubleKpi(v['comision'] ?? v['comison'] ?? 0);
        });

        agentes.add({
          ...u,
          'nombre_completo': "${u['nombre'] ?? ''} ${u['apellidos'] ?? ''}"
              .trim(),
          'jefe_nombre': jefe.isEmpty
              ? 'Sin jefe'
              : "${jefe['nombre'] ?? ''} ${jefe['apellidos'] ?? ''}".trim(),
          'total_ventas': ventasAgente.length,
          'prima_total': primaTotal,
          'comision_total': comisionTotal,
          'recibos_devueltos': 0,
        });
      }

      print("AGENTES CARGADOS ERP: ${agentes.length}");
      return agentes;
    } catch (e) {
      print("❌ ERROR getAgentesERP: $e");
      return [];
    }
  }

  Widget buildAgentesPageERP() {
    _agentesErpFuture ??= getAgentesERP();

    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _agentesErpFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting &&
            !snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline, color: Colors.red, size: 42),
                const SizedBox(height: 10),
                const Text('No se pudo cargar el listado de agentes.'),
                const SizedBox(height: 12),
                ElevatedButton.icon(
                  onPressed: _recargarAgentesERP,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Reintentar'),
                ),
              ],
            ),
          );
        }

        final agentes = snapshot.data ?? <Map<String, dynamic>>[];
        final busqueda = _buscarAgentesController.text.trim().toLowerCase();

        String estadoNormalizado(Map<String, dynamic> agente) {
          final estado =
              agente['estado']?.toString().trim().toUpperCase() ?? '';
          return estado.isEmpty ? 'ACTIVO' : estado;
        }

        final filtrados = agentes.where((agente) {
          final coincideEstado =
              _filtroEstadoAgentes == 'TODOS' ||
              estadoNormalizado(agente) == _filtroEstadoAgentes;
          if (!coincideEstado) return false;
          if (busqueda.isEmpty) return true;

          final texto = [
            agente['nombre_completo'],
            agente['email'],
            agente['rol_usuario'],
            agente['jefe_nombre'],
          ].map((valor) => valor?.toString().toLowerCase() ?? '').join(' ');
          return texto.contains(busqueda);
        }).toList();

        final visibles = filtrados.take(_agentesVisibles).toList();
        final quedanRegistros = visibles.length < filtrados.length;
        final totalAgentes = agentes.length;
        final comerciales = agentes.where((a) {
          final rol = a['rol_usuario']?.toString().toLowerCase() ?? '';
          return rol.contains('agente') || rol.contains('comercial');
        }).length;
        final jefes = agentes.where((a) {
          final rol = a['rol_usuario']?.toString().toLowerCase() ?? '';
          return rol.contains('jefe') && rol.contains('equipo');
        }).length;
        final jefesVentas = agentes.where((a) {
          final rol = a['rol_usuario']?.toString().toLowerCase() ?? '';
          return rol.contains('jefe') && rol.contains('venta');
        }).length;
        final produccion = agentes.fold<double>(
          0,
          (suma, a) => suma + _toDoubleKpi(a['prima_total']),
        );

        return RefreshIndicator(
          onRefresh: _recargarAgentesERP,
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(22),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: Colors.grey.shade300),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.04),
                        blurRadius: 16,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Colors.blue.shade50,
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Icon(
                          Icons.groups_rounded,
                          color: Colors.blue.shade700,
                          size: 36,
                        ),
                      ),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Centro de Agentes',
                              style: TextStyle(
                                fontSize: 27,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 5),
                            Text(
                              'Consulta y gestión de usuarios, estados, responsables y producción',
                              style: TextStyle(color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                      IconButton.filledTonal(
                        tooltip: 'Actualizar listado',
                        onPressed: _recargarAgentesERP,
                        icon: const Icon(Icons.refresh_rounded),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 14,
                  runSpacing: 14,
                  children: [
                    _kpiAgenteERP(
                      'Usuarios',
                      totalAgentes.toString(),
                      Icons.people_alt_outlined,
                      Colors.blue,
                    ),
                    _kpiAgenteERP(
                      'Agentes',
                      comerciales.toString(),
                      Icons.person_outline,
                      Colors.green,
                    ),
                    _kpiAgenteERP(
                      'Jefes equipo',
                      jefes.toString(),
                      Icons.groups_outlined,
                      Colors.indigo,
                    ),
                    _kpiAgenteERP(
                      'Jefes ventas',
                      jefesVentas.toString(),
                      Icons.workspace_premium_outlined,
                      Colors.deepPurple,
                    ),
                    _kpiAgenteERP(
                      'Producción',
                      _formatoEuroKpi(produccion),
                      Icons.euro_outlined,
                      Colors.orange,
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: _decoracionAgenteERP(),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Expanded(
                            child: Text(
                              'Listado profesional de agentes',
                              style: TextStyle(
                                fontSize: 19,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          Text(
                            '${filtrados.length} registros',
                            style: TextStyle(
                              color: Colors.grey.shade600,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      LayoutBuilder(
                        builder: (context, constraints) {
                          final campoBusqueda = TextField(
                            controller: _buscarAgentesController,
                            onChanged: (_) {
                              setState(() => _agentesVisibles = 10);
                            },
                            decoration: InputDecoration(
                              hintText:
                                  'Buscar por nombre, email, rol o responsable',
                              prefixIcon: const Icon(Icons.search_rounded),
                              suffixIcon: busqueda.isEmpty
                                  ? null
                                  : IconButton(
                                      tooltip: 'Limpiar búsqueda',
                                      onPressed: () {
                                        _buscarAgentesController.clear();
                                        setState(() => _agentesVisibles = 10);
                                      },
                                      icon: const Icon(Icons.close),
                                    ),
                              filled: true,
                              fillColor: Colors.grey.shade50,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(14),
                                borderSide: BorderSide(
                                  color: Colors.grey.shade300,
                                ),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(14),
                                borderSide: BorderSide(
                                  color: Colors.grey.shade300,
                                ),
                              ),
                            ),
                          );

                          final filtro = DropdownButtonFormField<String>(
                            value: _filtroEstadoAgentes,
                            decoration: InputDecoration(
                              labelText: 'Estado',
                              prefixIcon: const Icon(Icons.filter_alt_outlined),
                              filled: true,
                              fillColor: Colors.grey.shade50,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(14),
                              ),
                            ),
                            items: const [
                              DropdownMenuItem(
                                value: 'TODOS',
                                child: Text('Todos'),
                              ),
                              DropdownMenuItem(
                                value: 'ACTIVO',
                                child: Text('Activos'),
                              ),
                              DropdownMenuItem(
                                value: 'INACTIVO',
                                child: Text('Inactivos'),
                              ),
                              DropdownMenuItem(
                                value: 'BAJA',
                                child: Text('Bajas'),
                              ),
                              DropdownMenuItem(
                                value: 'SUSPENDIDO',
                                child: Text('Suspendidos'),
                              ),
                            ],
                            onChanged: (value) {
                              if (value == null) return;
                              setState(() {
                                _filtroEstadoAgentes = value;
                                _agentesVisibles = 10;
                              });
                            },
                          );

                          if (constraints.maxWidth < 720) {
                            return Column(
                              children: [
                                campoBusqueda,
                                const SizedBox(height: 10),
                                filtro,
                              ],
                            );
                          }
                          return Row(
                            children: [
                              Expanded(flex: 3, child: campoBusqueda),
                              const SizedBox(width: 12),
                              SizedBox(width: 220, child: filtro),
                            ],
                          );
                        },
                      ),
                      const SizedBox(height: 14),
                      if (filtrados.isEmpty)
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 55),
                          alignment: Alignment.center,
                          child: const Column(
                            children: [
                              Icon(
                                Icons.person_search_outlined,
                                size: 48,
                                color: Colors.grey,
                              ),
                              SizedBox(height: 10),
                              Text('No hay agentes con estos criterios.'),
                            ],
                          ),
                        )
                      else
                        SizedBox(
                          height: 620,
                          child: Scrollbar(
                            controller: _agentesScrollController,
                            thumbVisibility: true,
                            child: SingleChildScrollView(
                              controller: _agentesScrollController,
                              scrollDirection: Axis.vertical,
                              child: Column(
                                children: [
                                  TablaConScrollHorizontalERP(
                                    child: ConstrainedBox(
                                      constraints: BoxConstraints(
                                        minWidth:
                                            MediaQuery.of(context).size.width -
                                            360,
                                      ),
                                      child: DataTable(
                                        headingRowColor:
                                            WidgetStateProperty.all(
                                              Colors.grey.shade100,
                                            ),
                                        dataRowMinHeight: 64,
                                        dataRowMaxHeight: 78,
                                        columnSpacing: 28,
                                        horizontalMargin: 14,
                                        border: TableBorder(
                                          horizontalInside: BorderSide(
                                            color: Colors.grey.shade200,
                                          ),
                                        ),
                                        columns: const [
                                          DataColumn(label: Text('Agente')),
                                          DataColumn(label: Text('Rol')),
                                          DataColumn(
                                            label: Text('Responsable directo'),
                                          ),
                                          DataColumn(label: Text('Ventas')),
                                          DataColumn(label: Text('Producción')),
                                          DataColumn(label: Text('Comisión')),
                                          DataColumn(label: Text('Devueltos')),
                                          DataColumn(label: Text('Estado')),
                                          DataColumn(label: Text('Acciones')),
                                        ],
                                        rows: visibles.map((a) {
                                          final nombre =
                                              a['nombre_completo']
                                                  ?.toString() ??
                                              'Sin nombre';
                                          return DataRow(
                                            onSelectChanged: (_) async {
                                              await mostrarEnviarNotificacionAgenteERP(
                                                a,
                                              );
                                            },
                                            cells: [
                                              DataCell(
                                                Row(
                                                  children: [
                                                    CircleAvatar(
                                                      radius: 17,
                                                      backgroundColor:
                                                          Colors.blue.shade700,
                                                      child: Text(
                                                        nombre.isNotEmpty
                                                            ? nombre[0]
                                                                  .toUpperCase()
                                                            : 'A',
                                                        style: const TextStyle(
                                                          color: Colors.white,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                      ),
                                                    ),
                                                    const SizedBox(width: 10),
                                                    Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          nombre,
                                                          style:
                                                              const TextStyle(
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                              ),
                                                        ),
                                                        Text(
                                                          a['email']
                                                                  ?.toString() ??
                                                              '',
                                                          style: TextStyle(
                                                            fontSize: 12,
                                                            color: Colors
                                                                .grey
                                                                .shade600,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              DataCell(
                                                _chipRolAgenteERP(
                                                  a['rol_usuario']
                                                          ?.toString() ??
                                                      '',
                                                ),
                                              ),
                                              DataCell(
                                                Text(
                                                  a['jefe_nombre']
                                                          ?.toString() ??
                                                      '',
                                                ),
                                              ),
                                              DataCell(
                                                Text(
                                                  a['total_ventas'].toString(),
                                                ),
                                              ),
                                              DataCell(
                                                Text(
                                                  _formatoEuroKpi(
                                                    a['prima_total'],
                                                  ),
                                                ),
                                              ),
                                              DataCell(
                                                Text(
                                                  _formatoEuroKpi(
                                                    a['comision_total'],
                                                  ),
                                                ),
                                              ),
                                              DataCell(
                                                Text(
                                                  a['recibos_devueltos']
                                                      .toString(),
                                                ),
                                              ),
                                              DataCell(_chipEstadoAgenteERP(a)),
                                              DataCell(
                                                PopupMenuButton<String>(
                                                  icon: const Icon(
                                                    Icons.more_vert,
                                                  ),
                                                  itemBuilder: (context) => const [
                                                    PopupMenuItem(
                                                      value: 'detalle',
                                                      child: ListTile(
                                                        leading: Icon(
                                                          Icons
                                                              .visibility_outlined,
                                                        ),
                                                        title: Text(
                                                          'Ver ficha',
                                                        ),
                                                      ),
                                                    ),
                                                    PopupMenuItem(
                                                      value: 'produccion',
                                                      child: ListTile(
                                                        leading: Icon(
                                                          Icons
                                                              .bar_chart_outlined,
                                                        ),
                                                        title: Text(
                                                          'Ver producción',
                                                        ),
                                                      ),
                                                    ),
                                                    PopupMenuItem(
                                                      value: 'gestionar',
                                                      child: ListTile(
                                                        leading: Icon(
                                                          Icons
                                                              .admin_panel_settings_outlined,
                                                        ),
                                                        title: Text(
                                                          'Gestionar agente',
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                  onSelected: (value) async {
                                                    if (value == 'detalle') {
                                                      await mostrarDetalleAgenteERP(
                                                        a,
                                                      );
                                                    } else if (value ==
                                                        'produccion') {
                                                      await mostrarProduccionAgenteERP(
                                                        a,
                                                      );
                                                    } else if (value ==
                                                        'gestionar') {
                                                      await mostrarGestionarAgenteERP(
                                                        a,
                                                      );
                                                    }
                                                  },
                                                ),
                                              ),
                                            ],
                                          );
                                        }).toList(),
                                      ),
                                    ),
                                  ),
                                  if (quedanRegistros)
                                    const Padding(
                                      padding: EdgeInsets.symmetric(
                                        vertical: 18,
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          SizedBox(
                                            width: 18,
                                            height: 18,
                                            child: CircularProgressIndicator(
                                              strokeWidth: 2,
                                            ),
                                          ),
                                          SizedBox(width: 10),
                                          Text('Desplázate para cargar 10 más'),
                                        ],
                                      ),
                                    )
                                  else
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 16,
                                      ),
                                      child: Text(
                                        'Mostrados ${visibles.length} de ${filtrados.length}',
                                        style: TextStyle(
                                          color: Colors.grey.shade600,
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  BoxDecoration _decoracionAgenteERP() {
    return BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22),
      border: Border.all(color: Colors.grey.shade300),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.03),
          blurRadius: 14,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _kpiAgenteERP(
    String titulo,
    String valor,
    IconData icono,
    MaterialColor color,
  ) {
    return Container(
      width: 220,
      padding: const EdgeInsets.all(17),
      decoration: _decoracionAgenteERP(),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(11),
            decoration: BoxDecoration(
              color: color.shade50,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icono, color: color.shade700, size: 27),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  titulo,
                  style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
                ),
                const SizedBox(height: 4),
                Text(
                  valor,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _chipRolAgenteERP(String rol) {
    final rolUpper = rol.toUpperCase();

    MaterialColor color = Colors.blue;
    IconData icono = Icons.person_outline;
    String texto = rolUpper.isEmpty ? "SIN ROL" : rolUpper;

    if (rolUpper == "JEFE_EQUIPO") {
      color = Colors.indigo;
      icono = Icons.groups_outlined;
      texto = "JEFE EQUIPO";
    }

    if (rolUpper == "AGENTE") {
      color = Colors.green;
      icono = Icons.person_outline;
      texto = "AGENTE";
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: color.shade50,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: color.shade100),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icono, size: 16, color: color.shade700),
          const SizedBox(width: 6),
          Text(
            texto,
            style: TextStyle(
              color: color.shade800,
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _chipEstadoAgenteERP(Map<String, dynamic> a) {
    final estado = (a['estado'] ?? 'ACTIVO').toString().trim().toUpperCase();

    String texto;
    MaterialColor color;
    IconData icono;

    switch (estado) {
      case 'INACTIVO':
      case 'DESACTIVADO':
        texto = 'Inactivo';
        color = Colors.grey;
        icono = Icons.pause_circle_outline_rounded;
        break;
      case 'BAJA':
        texto = 'Baja';
        color = Colors.red;
        icono = Icons.person_off_outlined;
        break;
      case 'SUSPENDIDO':
        texto = 'Suspendido';
        color = Colors.orange;
        icono = Icons.timer_off_outlined;
        break;
      case 'BLOQUEADO':
        texto = 'Bloqueado';
        color = Colors.red;
        icono = Icons.lock_outline_rounded;
        break;
      case 'ACTIVO':
      default:
        texto = estado.isEmpty
            ? 'Activo'
            : estado.substring(0, 1) + estado.substring(1).toLowerCase();
        color = Colors.green;
        icono = Icons.check_circle_outline;
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: color.shade50,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: color.shade100),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icono, size: 16, color: color.shade700),
          const SizedBox(width: 6),
          Text(
            texto,
            style: TextStyle(
              color: color.shade800,
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> mostrarDetalleAgenteERP(Map<String, dynamic> a) async {
    await _showPanelDialog(
      context: context,
      builder: (_) {
        return Dialog(
          insetPadding: const EdgeInsets.symmetric(
            horizontal: 18,
            vertical: 24,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 720),
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      radius: 28,
                      backgroundColor: Colors.blue.shade700,
                      child: Text(
                        (a['nombre_completo']?.toString().isNotEmpty ?? false)
                            ? a['nombre_completo'].toString()[0].toUpperCase()
                            : "A",
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 22,
                        ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            a['nombre_completo']?.toString() ?? 'Agente',
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            a['email']?.toString() ?? '',
                            style: TextStyle(color: Colors.grey.shade600),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.close),
                    ),
                  ],
                ),

                const SizedBox(height: 22),

                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    _miniDatoAgenteERP("Rol", a['rol_usuario']),
                    _miniDatoAgenteERP("Jefe equipo", a['jefe_nombre']),
                    _miniDatoAgenteERP("Ventas", a['total_ventas']),
                    _miniDatoAgenteERP(
                      "Producción",
                      _formatoEuroKpi(a['prima_total']),
                    ),
                    _miniDatoAgenteERP(
                      "Comisión",
                      _formatoEuroKpi(a['comision_total']),
                    ),
                    _miniDatoAgenteERP("Devueltos", a['recibos_devueltos']),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> mostrarProduccionAgenteERP(Map<String, dynamic> a) async {
    await _showPanelDialog(
      context: context,
      builder: (_) {
        return Dialog(
          insetPadding: const EdgeInsets.symmetric(
            horizontal: 18,
            vertical: 24,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 760),
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 28,
                        backgroundColor: Colors.indigo.shade700,
                        child: Text(
                          (a['nombre_completo']?.toString().isNotEmpty ?? false)
                              ? a['nombre_completo'].toString()[0].toUpperCase()
                              : "A",
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 22,
                          ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Producción del agente",
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              a['nombre_completo']?.toString() ?? 'Agente',
                              style: TextStyle(color: Colors.grey.shade600),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.close),
                      ),
                    ],
                  ),

                  const SizedBox(height: 22),

                  Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: [
                      _miniDatoAgenteERP(
                        "Ventas realizadas",
                        a['total_ventas'],
                      ),
                      _miniDatoAgenteERP(
                        "Producción bruta",
                        _formatoEuroKpi(a['prima_total']),
                      ),
                      _miniDatoAgenteERP(
                        "Comisión generada",
                        _formatoEuroKpi(a['comision_total']),
                      ),
                      _miniDatoAgenteERP(
                        "Recibos devueltos",
                        a['recibos_devueltos'],
                      ),
                      _miniDatoAgenteERP("Rol", a['rol_usuario']),
                      _miniDatoAgenteERP("Jefe equipo", a['jefe_nombre']),
                    ],
                  ),

                  const SizedBox(height: 22),

                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.indigo.shade50,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Colors.indigo.shade100),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.insights_outlined,
                          color: Colors.indigo.shade700,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            "Este resumen muestra la producción vinculada al agente según las ventas registradas y los recibos asociados a sus pólizas.",
                            style: TextStyle(
                              color: Colors.indigo.shade900,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> mostrarGestionarAgenteERP(Map<String, dynamic> a) async {
    final supabase = Supabase.instance.client;

    String normalizarRol(dynamic rol) {
      return (rol ?? '')
          .toString()
          .trim()
          .toLowerCase()
          .replaceAll('-', '_')
          .replaceAll(' ', '_')
          .replaceAll('ó', 'o');
    }

    String rolTexto(dynamic rol) {
      switch (normalizarRol(rol)) {
        case 'director_nacional':
          return 'Director nacional';

        case 'director_zona':
          return 'Director de zona';

        case 'jefe_ventas':
          return 'Jefe de ventas';

        case 'jefe_equipo':
          return 'Jefe de equipo';

        case 'agente':
          return 'Agente';

        case 'administracion':
        case 'admin':
          return 'Administración';

        default:
          return rol?.toString() ?? 'Usuario';
      }
    }

    String nombreCompleto(Map<String, dynamic> usuario) {
      final nombre = usuario['nombre']?.toString().trim() ?? '';

      final apellidos = usuario['apellidos']?.toString().trim() ?? '';

      final completo = '$nombre $apellidos'.trim();

      if (completo.isNotEmpty) {
        return completo;
      }

      final email = usuario['email']?.toString().trim() ?? '';

      return email.isNotEmpty ? email : 'Usuario sin nombre';
    }

    /*
   * Volvemos a leer el usuario para asegurarnos de tener
   * el parent_id más reciente.
   */
    final usuarioResponse = await supabase
        .from('usuarios')
        .select(
          'id, auth_id, parent_id, rol_usuario, estado, '
          'nombre, apellidos, email, direccion, '
          'numero_direccion, codigo_postal, provincia, localidad',
        )
        .eq('id', a['id'])
        .maybeSingle();

    if (usuarioResponse == null) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No se ha encontrado el usuario.'),
          backgroundColor: Colors.red,
        ),
      );

      return;
    }

    final usuarioActual = Map<String, dynamic>.from(usuarioResponse);

    /*
   * Cargamos usuarios para mostrar nombres en lugar de IDs.
   */
    final usuariosResponse = await supabase
        .from('usuarios')
        .select(
          'id, auth_id, parent_id, rol_usuario, '
          'nombre, apellidos, email',
        );

    final todosUsuarios = List<Map<String, dynamic>>.from(usuariosResponse);

    /*
   * Si no es administración, limitamos los posibles responsables
   * a los usuarios de la estructura permitida.
   */
    final authPermitidos = authIdsPermitidosERP.toSet();

    final usuariosGestionables = todosUsuarios.where((usuario) {
      if (veTodoERP) {
        return true;
      }

      final authId = usuario['auth_id']?.toString().trim() ?? '';

      return authPermitidos.contains(authId);
    }).toList();

    List<Map<String, dynamic>> responsablesDisponibles() {
      final usuarioEditadoId = usuarioActual['id']?.toString().trim() ?? '';

      // Puede depender de cualquier figura. Solo bloqueamos la propia persona
      // y sus descendientes para impedir ciclos en la estructura.
      final descendientes = <String>{};
      var hayCambios = true;
      while (hayCambios) {
        hayCambios = false;
        for (final usuario in todosUsuarios) {
          final id = usuario['id']?.toString().trim() ?? '';
          final parentId = usuario['parent_id']?.toString().trim() ?? '';
          if (id.isEmpty || descendientes.contains(id)) continue;
          if (parentId == usuarioEditadoId ||
              descendientes.contains(parentId)) {
            descendientes.add(id);
            hayCambios = true;
          }
        }
      }

      final responsables = usuariosGestionables.where((usuario) {
        final id = usuario['id']?.toString().trim() ?? '';
        return id.isNotEmpty &&
            id != usuarioEditadoId &&
            !descendientes.contains(id);
      }).toList();

      responsables.sort(
        (a, b) => nombreCompleto(
          a,
        ).toLowerCase().compareTo(nombreCompleto(b).toLowerCase()),
      );
      return responsables;
    }

    final nombreController = TextEditingController(
      text: usuarioActual['nombre']?.toString() ?? '',
    );

    final apellidosController = TextEditingController(
      text: usuarioActual['apellidos']?.toString() ?? '',
    );

    final emailController = TextEditingController(
      text: usuarioActual['email']?.toString() ?? '',
    );

    final direccionController = TextEditingController(
      text: usuarioActual['direccion']?.toString() ?? '',
    );

    final numeroController = TextEditingController(
      text: usuarioActual['numero_direccion']?.toString() ?? '',
    );

    final cpController = TextEditingController(
      text: usuarioActual['codigo_postal']?.toString() ?? '',
    );

    final provinciaController = TextEditingController(
      text: usuarioActual['provincia']?.toString() ?? '',
    );

    final localidadController = TextEditingController(
      text: usuarioActual['localidad']?.toString() ?? '',
    );

    String rolSeleccionado = normalizarRol(usuarioActual['rol_usuario']);

    const rolesValidos = {
      'director_nacional',
      'director_zona',
      'jefe_ventas',
      'jefe_equipo',
      'agente',
      'administracion',
    };

    if (!rolesValidos.contains(rolSeleccionado)) {
      rolSeleccionado = 'agente';
    }

    String estadoSeleccionado =
        usuarioActual['estado']?.toString().trim().toUpperCase() ?? 'ACTIVO';

    if (![
      'ACTIVO',
      'INACTIVO',
      'BAJA',
      'SUSPENDIDO',
    ].contains(estadoSeleccionado)) {
      estadoSeleccionado = 'ACTIVO';
    }

    String? parentIdSeleccionado = usuarioActual['parent_id']
        ?.toString()
        .trim();

    if (parentIdSeleccionado == null ||
        parentIdSeleccionado!.isEmpty ||
        parentIdSeleccionado!.toLowerCase() == 'null') {
      parentIdSeleccionado = null;
    }

    bool guardando = false;

    if (!mounted) return;

    await _showPanelDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            final responsables = responsablesDisponibles();

            final parentActualValido =
                parentIdSeleccionado != null &&
                responsables.any(
                  (responsable) =>
                      responsable['id']?.toString() == parentIdSeleccionado,
                );

            /*
           * Si el responsable actual no coincide con el rol superior
           * requerido, el selector aparece sin asignación.
           */
            final valorDependencia = parentActualValido
                ? parentIdSeleccionado
                : '__SIN_DEPENDENCIA__';

            String textoDependenciaActual() {
              if (!parentActualValido) {
                return 'No tiene una dependencia directa asignada.';
              }

              final responsable = responsables.firstWhere(
                (usuario) => usuario['id']?.toString() == parentIdSeleccionado,
              );

              return 'Actualmente depende de '
                  '${nombreCompleto(responsable)} '
                  '(${rolTexto(responsable['rol_usuario'])}).';
            }

            return Dialog(
              insetPadding: const EdgeInsets.symmetric(
                horizontal: 18,
                vertical: 24,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              child: Container(
                constraints: const BoxConstraints(
                  maxWidth: 820,
                  maxHeight: 850,
                ),
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: Colors.blue.shade50,
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: Icon(
                              Icons.admin_panel_settings_outlined,
                              color: Colors.blue.shade700,
                              size: 34,
                            ),
                          ),
                          const SizedBox(width: 14),
                          const Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Gestionar usuario',
                                  style: TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  'Edita sus datos, rol, estado y dependencia directa',
                                  style: TextStyle(color: Colors.grey),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            onPressed: guardando
                                ? null
                                : () => Navigator.pop(context),
                            icon: const Icon(Icons.close),
                          ),
                        ],
                      ),

                      const SizedBox(height: 22),

                      Row(
                        children: [
                          Expanded(
                            child: _campoGestionAgente(
                              'Nombre',
                              Icons.person_outline,
                              nombreController,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _campoGestionAgente(
                              'Apellidos',
                              Icons.badge_outlined,
                              apellidosController,
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 12),

                      _campoGestionAgente(
                        'Email',
                        Icons.email_outlined,
                        emailController,
                      ),

                      const SizedBox(height: 12),

                      Row(
                        children: [
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: rolSeleccionado,
                              isExpanded: true,
                              decoration: _decoracionGestionAgente(
                                'Rol usuario',
                                Icons.manage_accounts_outlined,
                              ),
                              items: const [
                                DropdownMenuItem(
                                  value: 'director_nacional',
                                  child: Text('Director nacional'),
                                ),
                                DropdownMenuItem(
                                  value: 'director_zona',
                                  child: Text('Director de zona'),
                                ),
                                DropdownMenuItem(
                                  value: 'jefe_ventas',
                                  child: Text('Jefe de ventas'),
                                ),
                                DropdownMenuItem(
                                  value: 'jefe_equipo',
                                  child: Text('Jefe de equipo'),
                                ),
                                DropdownMenuItem(
                                  value: 'agente',
                                  child: Text('Agente'),
                                ),
                                DropdownMenuItem(
                                  value: 'administracion',
                                  child: Text('Administración'),
                                ),
                              ],
                              onChanged: guardando
                                  ? null
                                  : (value) {
                                      if (value == null) {
                                        return;
                                      }

                                      setDialogState(() {
                                        rolSeleccionado = value;

                                        final nuevosResponsables =
                                            responsablesDisponibles();

                                        final actualSigueValido =
                                            nuevosResponsables.any(
                                              (usuario) =>
                                                  usuario['id']?.toString() ==
                                                  parentIdSeleccionado,
                                            );

                                        if (!actualSigueValido) {
                                          parentIdSeleccionado = null;
                                        }
                                      });
                                    },
                            ),
                          ),

                          const SizedBox(width: 12),

                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: estadoSeleccionado,
                              isExpanded: true,
                              decoration: _decoracionGestionAgente(
                                'Estado',
                                Icons.power_settings_new_outlined,
                              ),
                              items: const [
                                DropdownMenuItem(
                                  value: 'ACTIVO',
                                  child: Text('Activo'),
                                ),
                                DropdownMenuItem(
                                  value: 'INACTIVO',
                                  child: Text('Inactivo'),
                                ),
                                DropdownMenuItem(
                                  value: 'BAJA',
                                  child: Text('Baja'),
                                ),
                                DropdownMenuItem(
                                  value: 'SUSPENDIDO',
                                  child: Text('Suspendido'),
                                ),
                              ],
                              onChanged: guardando
                                  ? null
                                  : (value) {
                                      setDialogState(() {
                                        estadoSeleccionado = value ?? 'ACTIVO';
                                      });
                                    },
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 16),

                      const Text(
                        'Dependencia directa',
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const SizedBox(height: 5),

                      Text(
                        'Selecciona por nombre la persona de la que dependerá directamente.',
                        style: TextStyle(
                          color: Colors.grey.shade600,
                          fontSize: 13,
                        ),
                      ),

                      const SizedBox(height: 12),

                      DropdownButtonFormField<String>(
                        key: ValueKey(
                          '$rolSeleccionado-'
                          '$valorDependencia-'
                          '${responsables.length}',
                        ),
                        value: valorDependencia,
                        isExpanded: true,
                        itemHeight: 68,
                        menuMaxHeight: 430,
                        decoration: _decoracionGestionAgente(
                          'Responsable directo',
                          Icons.account_tree_outlined,
                        ),
                        items: [
                          DropdownMenuItem<String>(
                            value: '__SIN_DEPENDENCIA__',
                            child: SizedBox(
                              height: 58,
                              child: Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  'Sin dependencia',
                                  style: TextStyle(color: Colors.grey.shade600),
                                ),
                              ),
                            ),
                          ),
                          ...responsables.map((responsable) {
                            return DropdownMenuItem<String>(
                              value: responsable['id']?.toString(),
                              child: SizedBox(
                                height: 58,
                                child: Row(
                                  children: [
                                    CircleAvatar(
                                      radius: 16,
                                      backgroundColor: Colors.indigo.shade50,
                                      child: Icon(
                                        Icons.person_outline,
                                        size: 18,
                                        color: Colors.indigo.shade700,
                                      ),
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            nombreCompleto(responsable),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 14,
                                              height: 1.1,
                                            ),
                                          ),
                                          const SizedBox(height: 3),
                                          Text(
                                            rolTexto(
                                              responsable['rol_usuario'],
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              color: Colors.grey.shade600,
                                              fontSize: 11,
                                              height: 1,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          }),
                        ],
                        selectedItemBuilder: (context) {
                          return [
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                responsables.isEmpty
                                    ? 'Sin dependencia asignada'
                                    : 'Sin dependencia asignada',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: Colors.grey.shade700,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),

                            ...responsables.map((responsable) {
                              return Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  '${nombreCompleto(responsable)} · '
                                  '${rolTexto(responsable['rol_usuario'])}',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13,
                                  ),
                                ),
                              );
                            }),
                          ];
                        },

                        onChanged: guardando || responsables.isEmpty
                            ? null
                            : (value) {
                                setDialogState(() {
                                  if (value == '__SIN_DEPENDENCIA__') {
                                    parentIdSeleccionado = null;
                                  } else {
                                    parentIdSeleccionado = value;
                                  }
                                });
                              },
                      ),

                      const SizedBox(height: 8),

                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.indigo.shade50,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: Colors.indigo.shade100),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.info_outline,
                              color: Colors.indigo.shade700,
                              size: 21,
                            ),
                            const SizedBox(width: 9),
                            Expanded(
                              child: Text(
                                textoDependenciaActual(),
                                style: TextStyle(
                                  color: Colors.indigo.shade900,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 20),

                      const Text(
                        'Datos de dirección',
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const SizedBox(height: 12),

                      Row(
                        children: [
                          Expanded(
                            flex: 3,
                            child: _campoGestionAgente(
                              'Dirección',
                              Icons.home_outlined,
                              direccionController,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _campoGestionAgente(
                              'Número',
                              Icons.pin_outlined,
                              numeroController,
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 12),

                      Row(
                        children: [
                          Expanded(
                            child: _campoGestionAgente(
                              'Código postal',
                              Icons.markunread_mailbox_outlined,
                              cpController,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _campoGestionAgente(
                              'Localidad',
                              Icons.location_city_outlined,
                              localidadController,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _campoGestionAgente(
                              'Provincia',
                              Icons.map_outlined,
                              provinciaController,
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 22),

                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          color:
                              estadoSeleccionado == 'BAJA' ||
                                  estadoSeleccionado == 'INACTIVO'
                              ? Colors.red.shade50
                              : Colors.green.shade50,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color:
                                estadoSeleccionado == 'BAJA' ||
                                    estadoSeleccionado == 'INACTIVO'
                                ? Colors.red.shade100
                                : Colors.green.shade100,
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              estadoSeleccionado == 'BAJA' ||
                                      estadoSeleccionado == 'INACTIVO'
                                  ? Icons.warning_amber_rounded
                                  : Icons.check_circle_outline,
                              color:
                                  estadoSeleccionado == 'BAJA' ||
                                      estadoSeleccionado == 'INACTIVO'
                                  ? Colors.red.shade700
                                  : Colors.green.shade700,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                estadoSeleccionado == 'BAJA'
                                    ? 'El usuario quedará marcado como BAJA en el sistema.'
                                    : estadoSeleccionado == 'INACTIVO'
                                    ? 'El usuario quedará desactivado operativamente.'
                                    : estadoSeleccionado == 'SUSPENDIDO'
                                    ? 'El usuario quedará temporalmente suspendido.'
                                    : 'El usuario quedará activo y operativo.',
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 24),

                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: guardando
                                  ? null
                                  : () => Navigator.pop(context),
                              icon: const Icon(Icons.close),
                              label: const Text('Cancelar'),
                              style: OutlinedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 15,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                              ),
                            ),
                          ),

                          const SizedBox(width: 12),

                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: guardando
                                  ? null
                                  : () async {
                                      setDialogState(() {
                                        guardando = true;
                                      });

                                      try {
                                        await supabase
                                            .from('usuarios')
                                            .update({
                                              'nombre': nombreController.text
                                                  .trim(),
                                              'apellidos': apellidosController
                                                  .text
                                                  .trim(),
                                              'email': emailController.text
                                                  .trim(),

                                              /*
                                             * Guardamos roles en minúsculas,
                                             * igual que el resto de SafeBrok.
                                             */
                                              'rol_usuario': rolSeleccionado,

                                              'estado': estadoSeleccionado,

                                              /*
                                             * Aquí se guarda el ID interno
                                             * de la persona seleccionada.
                                             */
                                              'parent_id': parentIdSeleccionado,

                                              'direccion': direccionController
                                                  .text
                                                  .trim(),
                                              'numero_direccion':
                                                  numeroController.text.trim(),
                                              'codigo_postal': cpController.text
                                                  .trim(),
                                              'provincia': provinciaController
                                                  .text
                                                  .trim(),
                                              'localidad': localidadController
                                                  .text
                                                  .trim(),
                                            })
                                            .eq('id', usuarioActual['id']);

                                        if (!context.mounted) {
                                          return;
                                        }

                                        Navigator.pop(context);

                                        /*
                                       * Volvemos a calcular la estructura
                                       * después de cambiar el parent_id.
                                       */
                                        await cargarPermisosERP();
                                        await _recargarAgentesERP();

                                        if (!mounted) return;

                                        ScaffoldMessenger.of(
                                          this.context,
                                        ).showSnackBar(
                                          const SnackBar(
                                            content: Text(
                                              'Usuario y dependencia actualizados correctamente',
                                            ),
                                            backgroundColor: Colors.green,
                                          ),
                                        );
                                      } catch (e) {
                                        setDialogState(() {
                                          guardando = false;
                                        });

                                        if (!context.mounted) {
                                          return;
                                        }

                                        ScaffoldMessenger.of(
                                          context,
                                        ).showSnackBar(
                                          SnackBar(
                                            content: Text(
                                              'Error al actualizar usuario: $e',
                                            ),
                                            backgroundColor: Colors.red,
                                          ),
                                        );
                                      }
                                    },
                              icon: guardando
                                  ? const SizedBox(
                                      width: 18,
                                      height: 18,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: Colors.white,
                                      ),
                                    )
                                  : const Icon(Icons.save),
                              label: Text(
                                guardando ? 'Guardando...' : 'Guardar cambios',
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.blue.shade700,
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(
                                  vertical: 15,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );

    nombreController.dispose();
    apellidosController.dispose();
    emailController.dispose();
    direccionController.dispose();
    numeroController.dispose();
    cpController.dispose();
    provinciaController.dispose();
    localidadController.dispose();
  }

  Widget _campoGestionAgente(
    String label,
    IconData icon,
    TextEditingController controller,
  ) {
    return TextField(
      controller: controller,
      decoration: _decoracionGestionAgente(label, icon),
    );
  }

  InputDecoration _decoracionGestionAgente(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon),
      filled: true,
      fillColor: Colors.grey.shade50,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Colors.blue, width: 1.6),
      ),
    );
  }

  Widget _miniDatoAgenteERP(String titulo, dynamic valor) {
    return Container(
      width: 200,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            titulo,
            style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
          ),
          const SizedBox(height: 4),
          Text(
            valor?.toString().isEmpty ?? true ? "—" : valor.toString(),
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
          ),
        ],
      ),
    );
  }

  Future<void> mostrarEnviarNotificacionAgenteERP(
    Map<String, dynamic> a,
  ) async {
    final tituloController = TextEditingController(
      text: "Aviso de administración",
    );

    final mensajeController = TextEditingController();

    String tipoSeleccionado = "agente";
    String prioridadSeleccionada = "normal";
    bool enviando = false;

    await _showPanelDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return Dialog(
              insetPadding: const EdgeInsets.symmetric(
                horizontal: 18,
                vertical: 24,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              child: Container(
                constraints: const BoxConstraints(maxWidth: 760),
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          CircleAvatar(
                            radius: 28,
                            backgroundColor: Colors.blue.shade700,
                            child: Text(
                              (a['nombre_completo']?.toString().isNotEmpty ??
                                      false)
                                  ? a['nombre_completo']
                                        .toString()[0]
                                        .toUpperCase()
                                  : "A",
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 22,
                              ),
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  "Enviar notificación",
                                  style: TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  a['nombre_completo']?.toString() ?? 'Agente',
                                  style: TextStyle(color: Colors.grey.shade600),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            onPressed: enviando
                                ? null
                                : () => Navigator.pop(context),
                            icon: const Icon(Icons.close),
                          ),
                        ],
                      ),

                      const SizedBox(height: 22),

                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          color: Colors.blue.shade50,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: Colors.blue.shade100),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.notifications_active_outlined,
                              color: Colors.blue.shade700,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                "Esta notificación se enviará al centro de notificaciones del agente.",
                                style: TextStyle(
                                  color: Colors.blue.shade900,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 18),

                      TextField(
                        controller: tituloController,
                        decoration: _decoracionGestionAgente(
                          "Título de la notificación",
                          Icons.title_outlined,
                        ),
                      ),

                      const SizedBox(height: 12),

                      TextField(
                        controller: mensajeController,
                        maxLines: 5,
                        decoration: _decoracionGestionAgente(
                          "Mensaje para el agente",
                          Icons.message_outlined,
                        ),
                      ),

                      const SizedBox(height: 12),

                      Row(
                        children: [
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: tipoSeleccionado,
                              decoration: _decoracionGestionAgente(
                                "Tipo",
                                Icons.category_outlined,
                              ),
                              items: const [
                                DropdownMenuItem(
                                  value: "agente",
                                  child: Text("Aviso agente"),
                                ),
                                DropdownMenuItem(
                                  value: "produccion",
                                  child: Text("Producción"),
                                ),
                                DropdownMenuItem(
                                  value: "recibo",
                                  child: Text("Recibo"),
                                ),
                                DropdownMenuItem(
                                  value: "gestion",
                                  child: Text("Gestión"),
                                ),
                                DropdownMenuItem(
                                  value: "sistema",
                                  child: Text("Sistema"),
                                ),
                              ],

                              onChanged: (value) {
                                setDialogState(() {
                                  tipoSeleccionado = value ?? "agente";
                                });
                              },
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: prioridadSeleccionada,
                              decoration: _decoracionGestionAgente(
                                "Prioridad",
                                Icons.priority_high_outlined,
                              ),
                              items: const [
                                DropdownMenuItem(
                                  value: "normal",
                                  child: Text("Normal"),
                                ),
                                DropdownMenuItem(
                                  value: "alta",
                                  child: Text("Alta"),
                                ),
                                DropdownMenuItem(
                                  value: "urgente",
                                  child: Text("Urgente"),
                                ),
                              ],

                              onChanged: (value) {
                                setDialogState(() {
                                  prioridadSeleccionada = value ?? "normal";
                                });
                              },
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 24),

                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: enviando
                                  ? null
                                  : () => Navigator.pop(context),
                              icon: const Icon(Icons.close),
                              label: const Text("Cancelar"),
                              style: OutlinedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 15,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: enviando
                                  ? null
                                  : () async {
                                      if (mensajeController.text
                                          .trim()
                                          .isEmpty) {
                                        ScaffoldMessenger.of(
                                          context,
                                        ).showSnackBar(
                                          const SnackBar(
                                            content: Text(
                                              "Escribe un mensaje antes de enviar",
                                            ),
                                            backgroundColor: Colors.orange,
                                          ),
                                        );
                                        return;
                                      }

                                      setDialogState(() {
                                        enviando = true;
                                      });

                                      try {
                                        await Supabase.instance.client
                                            .from('notificaciones')
                                            .insert({
                                              'titulo': tituloController.text
                                                  .trim(),
                                              'mensaje': mensajeController.text
                                                  .trim(),
                                              'tipo': tipoSeleccionado,
                                              'leida': false,
                                              'usuario_email': a['email']
                                                  ?.toString(),
                                              'prioridad':
                                                  prioridadSeleccionada,
                                              'poliza': null,
                                              'venta_id': null,
                                              'recibo_id': null,
                                            });

                                        Navigator.pop(context);

                                        ScaffoldMessenger.of(
                                          context,
                                        ).showSnackBar(
                                          const SnackBar(
                                            content: Text(
                                              "Notificación enviada correctamente",
                                            ),
                                            backgroundColor: Colors.green,
                                          ),
                                        );

                                        setState(() {});
                                      } catch (e) {
                                        setDialogState(() {
                                          enviando = false;
                                        });

                                        ScaffoldMessenger.of(
                                          context,
                                        ).showSnackBar(
                                          SnackBar(
                                            content: Text(
                                              "Error al enviar notificación: $e",
                                            ),
                                            backgroundColor: Colors.red,
                                          ),
                                        );
                                      }
                                    },
                              icon: enviando
                                  ? const SizedBox(
                                      width: 18,
                                      height: 18,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: Colors.white,
                                      ),
                                    )
                                  : const Icon(Icons.send),
                              label: Text(
                                enviando
                                    ? "Enviando..."
                                    : "Enviar notificación",
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.blue.shade700,
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(
                                  vertical: 15,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );

    tituloController.dispose();
    mensajeController.dispose();
  }

  Widget buildRecibosPage(String tipo) {
    final titulo = switch (tipo) {
      "recibos_cobrados" => "Recibos Cobrados",
      "recibos_devueltos" => "Recibos Devueltos",
      "recibos_pendientes" => "Recibos Pendientes",
      _ => "Todos los Recibos",
    };

    final subtitulo = switch (tipo) {
      "recibos_cobrados" =>
        "Control de recibos cobrados y producción consolidada",
      "recibos_devueltos" =>
        "Seguimiento profesional de devoluciones e incidencias",
      "recibos_pendientes" =>
        "Recibos pendientes de cobro y próximas gestiones",
      _ => "Listado general de recibos",
    };

    final color = switch (tipo) {
      "recibos_cobrados" => Colors.green,
      "recibos_devueltos" => Colors.red,
      "recibos_pendientes" => Colors.orange,
      _ => Colors.blue,
    };

    final icono = switch (tipo) {
      "recibos_cobrados" => Icons.check_circle_rounded,
      "recibos_devueltos" => Icons.cancel_rounded,
      "recibos_pendientes" => Icons.schedule_rounded,
      _ => Icons.receipt_long_rounded,
    };

    return FutureBuilder<List<Map<String, dynamic>>>(
      future: getRecibos(tipo),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final data = snapshot.data!;
        final totalImporte = totalImporteRecibos(data);
        final cobrados = totalDineroRecibosPorEstado(data, "COBRADO");
        final devueltos = totalDineroRecibosPorEstado(data, "DEVUELTO");
        final pendientes = totalDineroRecibosPorEstado(data, "PENDIENTE");

        return SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: Colors.grey.shade300),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.04),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: color.shade50,
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Icon(icono, color: color.shade700, size: 34),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            titulo,
                            style: const TextStyle(
                              fontSize: 27,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            subtitulo,
                            style: TextStyle(
                              color: Colors.grey.shade600,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                    ElevatedButton.icon(
                      onPressed: () async {
                        final exportData = await getRecibos(selectedMenu);
                        await exportarExcel(exportData);
                        print("EXPORTAR -> ${exportData.length} RECIBOS");
                      },
                      icon: const Icon(Icons.file_download_outlined),
                      label: const Text("Exportar Excel"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green.shade700,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 18,
                          vertical: 15,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              Wrap(
                spacing: 14,
                runSpacing: 14,
                children: [
                  _kpiReciboERP(
                    "Total recibos",
                    data.length.toString(),
                    Icons.receipt_long_outlined,
                    Colors.blue,
                  ),
                  _kpiReciboERP(
                    "Importe total",
                    _formatoEuroKpi(totalImporte),
                    Icons.euro_outlined,
                    Colors.indigo,
                  ),
                  _kpiReciboERP(
                    "Cobrados",
                    _formatoEuroKpi(cobrados),
                    Icons.check_circle_outline,
                    Colors.green,
                  ),
                  _kpiReciboERP(
                    "Devueltos",
                    _formatoEuroKpi(devueltos),
                    Icons.cancel_outlined,
                    Colors.red,
                  ),
                  _kpiReciboERP(
                    "Pendientes",
                    _formatoEuroKpi(pendientes),
                    Icons.schedule_outlined,
                    Colors.orange,
                  ),
                ],
              ),

              const SizedBox(height: 16),

              buildRecibosFilters(),

              const SizedBox(height: 16),

              buildRecibosListFiltrado(tipo),

              const SizedBox(height: 40),
            ],
          ),
        );
      },
    );
  }

  Widget buildRecibosListFiltrado(String tipo) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: getRecibos(tipo),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Container(
            height: 350,
            alignment: Alignment.center,
            child: const CircularProgressIndicator(),
          );
        }

        if (snapshot.hasError) {
          return Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: _decoracionRecibosERP(),
            child: const Text("Error cargando recibos"),
          );
        }

        final recibos = snapshot.data ?? [];

        if (recibos.isEmpty) {
          return Container(
            width: double.infinity,
            padding: const EdgeInsets.all(30),
            decoration: _decoracionRecibosERP(),
            child: Column(
              children: [
                Icon(
                  Icons.receipt_long_outlined,
                  size: 54,
                  color: Colors.grey.shade400,
                ),
                const SizedBox(height: 12),
                const Text(
                  "No hay recibos",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                Text(
                  "No se han encontrado recibos con los filtros actuales.",
                  style: TextStyle(color: Colors.grey.shade600),
                ),
              ],
            ),
          );
        }

        return Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: _decoracionRecibosERP(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Text(
                    "Listado de recibos",
                    style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
                  ),
                  const Spacer(),
                  Text(
                    "${recibos.length} registros encontrados",
                    style: TextStyle(
                      color: Colors.grey.shade600,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 14),

              SizedBox(
                height: 560,
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: TablaConScrollHorizontalERP(
                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        minWidth: MediaQuery.of(context).size.width - 330,
                      ),
                      child: ProgressiveRecords(
                        count: recibos.length,
                        resetKey: progressiveRecordKey(recibos),
                        showFooter: true,
                        builder: (context, _visibleRows) => DataTable(
                          headingRowColor: WidgetStateProperty.all(
                            Colors.grey.shade100,
                          ),
                          dataRowMinHeight: 62,
                          dataRowMaxHeight: 76,
                          headingRowHeight: 58,
                          columnSpacing: 28,
                          horizontalMargin: 14,
                          border: TableBorder(
                            horizontalInside: BorderSide(
                              color: Colors.grey.shade200,
                            ),
                          ),
                          columns: const [
                            DataColumn(label: Text("Estado")),
                            DataColumn(label: Text("Fecha")),
                            DataColumn(label: Text("Compañía")),
                            DataColumn(label: Text("Póliza")),
                            DataColumn(label: Text("Cliente")),
                            DataColumn(label: Text("Agente")),
                            DataColumn(label: Text("Importe")),
                            DataColumn(label: Text("Motivo")),
                            DataColumn(label: Text("Acciones")),
                          ],
                          rows: recibos.take(_visibleRows).map((r) {
                            final estado = r['estado']?.toString() ?? '';

                            return DataRow(
                              color: WidgetStateProperty.resolveWith<Color?>((
                                states,
                              ) {
                                if (estado.toUpperCase() == "DEVUELTO") {
                                  return Colors.red.shade50;
                                }
                                if (estado.toUpperCase() == "PENDIENTE") {
                                  return Colors.orange.shade50;
                                }
                                return null;
                              }),
                              cells: [
                                DataCell(_chipEstadoReciboERP(estado)),
                                DataCell(_textoReciboTabla(r['fecha'])),
                                DataCell(_textoReciboTabla(r['compania'])),
                                DataCell(
                                  Text(
                                    r['poliza']?.toString() ?? '',
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                DataCell(_textoReciboTabla(r['cliente'])),
                                DataCell(_textoReciboTabla(r['agente'])),
                                DataCell(
                                  Text(
                                    _formatoEuroKpi(r['importe']),
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                DataCell(_textoReciboTabla(r['motivo'])),
                                DataCell(
                                  PopupMenuButton<String>(
                                    icon: const Icon(Icons.more_vert),
                                    tooltip: "Acciones del recibo",
                                    itemBuilder: (context) => const [
                                      PopupMenuItem(
                                        value: "ver",
                                        child: ListTile(
                                          leading: Icon(
                                            Icons.visibility_outlined,
                                          ),
                                          title: Text("Ver detalle"),
                                        ),
                                      ),
                                      PopupMenuItem(
                                        value: "editar",
                                        child: ListTile(
                                          leading: Icon(Icons.edit_outlined),
                                          title: Text("Editar"),
                                        ),
                                      ),
                                      PopupMenuItem(
                                        value: "gestionar",
                                        child: ListTile(
                                          leading: Icon(
                                            Icons.manage_accounts_outlined,
                                          ),
                                          title: Text("Gestionar"),
                                        ),
                                      ),
                                      PopupMenuItem(
                                        value: "comentario",
                                        child: ListTile(
                                          leading: Icon(Icons.comment_outlined),
                                          title: Text("Añadir comentario"),
                                        ),
                                      ),
                                      PopupMenuItem(
                                        value: "notificar",
                                        child: ListTile(
                                          leading: Icon(
                                            Icons.notifications_active_outlined,
                                          ),
                                          title: Text("Notificar"),
                                        ),
                                      ),
                                    ],
                                    onSelected: (value) {
                                      if (value == "ver") {
                                        mostrarDetalleRecibo(r);
                                      } else if (value == "editar") {
                                        mostrarEditarRecibo(r);
                                      } else if (value == "gestionar") {
                                        mostrarGestionRecibo(r);
                                      } else if (value == "comentario") {
                                        mostrarComentarioRecibo(r);
                                      } else if (value == "notificar") {
                                        abrirPantallaNotificacion(context, r);
                                      }
                                    },
                                  ),
                                ),
                              ],
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget buildRecibosFilters() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: _decoracionRecibosERP(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.filter_alt_outlined),
              SizedBox(width: 8),
              Text(
                "Filtros de recibos",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ],
          ),

          const SizedBox(height: 16),

          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              _dropdownFiltroReciboERP(
                label: "Compañía",
                value: filtroCompania ?? "Todas",
                items: ["Todas", ...listaCompanias],
                onChanged: (value) {
                  setState(() {
                    filtroCompania = value == "Todas" ? null : value;
                  });
                },
              ),

              _dropdownFiltroReciboERP(
                label: "Estado",
                value: filtroEstado ?? "Todos",
                items: const ["Todos", "COBRADO", "DEVUELTO", "PENDIENTE"],
                onChanged: (value) {
                  setState(() {
                    filtroEstado = value == "Todos" ? null : value;
                  });
                },
              ),

              _dropdownFiltroReciboERP(
                label: "Agente",
                value: filtroAgente ?? "Todos",
                items: ["Todos", ...listaAgentes],
                onChanged: (value) {
                  setState(() {
                    filtroAgente = value == "Todos" ? null : value;
                  });
                },
              ),

              _botonFechaReciboERP(
                texto: fechaDesde == null
                    ? "Fecha desde"
                    : fechaDesde.toString().split(" ")[0],
                icono: Icons.calendar_month_outlined,
                onPressed: () async {
                  final date = await showDatePicker(
                    context: context,
                    firstDate: DateTime(2020),
                    lastDate: DateTime(2035),
                    initialDate: DateTime.now(),
                  );

                  if (date != null) {
                    setState(() {
                      fechaDesde = date;
                    });
                  }
                },
              ),

              _botonFechaReciboERP(
                texto: fechaHasta == null
                    ? "Fecha hasta"
                    : fechaHasta.toString().split(" ")[0],
                icono: Icons.event_available_outlined,
                onPressed: () async {
                  final date = await showDatePicker(
                    context: context,
                    firstDate: DateTime(2020),
                    lastDate: DateTime(2035),
                    initialDate: DateTime.now(),
                  );

                  if (date != null) {
                    setState(() {
                      fechaHasta = date;
                    });
                  }
                },
              ),

              ElevatedButton.icon(
                onPressed: () {
                  setState(() {
                    filtroCompania = null;
                    filtroAgente = null;
                    filtroEstado = null;
                    filtroJefeEquipo = null;
                    fechaDesde = null;
                    fechaHasta = null;
                  });
                },
                icon: const Icon(Icons.clear),
                label: const Text("Limpiar filtros"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.grey.shade800,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 16,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFilterBox({required String title, required Widget child}) {
    return SizedBox(
      width: 200,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 5),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: Colors.grey.shade50,
              border: Border.all(color: Colors.grey.shade300),
              borderRadius: BorderRadius.circular(14),
            ),
            child: child,
          ),
        ],
      ),
    );
  }

  BoxDecoration _decoracionRecibosERP() {
    return BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22),
      border: Border.all(color: Colors.grey.shade300),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.03),
          blurRadius: 14,
          offset: const Offset(0, 6),
        ),
      ],
    );
  }

  Widget _kpiReciboERP(
    String titulo,
    String valor,
    IconData icono,
    MaterialColor color,
  ) {
    return Container(
      width: 210,
      padding: const EdgeInsets.all(17),
      decoration: _decoracionRecibosERP(),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(11),
            decoration: BoxDecoration(
              color: color.shade50,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icono, color: color.shade700, size: 27),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  titulo,
                  style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
                ),
                const SizedBox(height: 4),
                Text(
                  valor,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _chipEstadoReciboERP(String estado) {
    final estadoUpper = estado.toUpperCase();

    MaterialColor color = Colors.blue;
    IconData icono = Icons.receipt_long_outlined;
    String texto = estadoUpper.isEmpty ? "SIN ESTADO" : estadoUpper;

    if (estadoUpper == "COBRADO") {
      color = Colors.green;
      icono = Icons.check_circle_outline;
    } else if (estadoUpper == "DEVUELTO") {
      color = Colors.red;
      icono = Icons.cancel_outlined;
    } else if (estadoUpper == "PENDIENTE") {
      color = Colors.orange;
      icono = Icons.schedule_outlined;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: color.shade50,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: color.shade100),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icono, size: 16, color: color.shade700),
          const SizedBox(width: 6),
          Text(
            texto,
            style: TextStyle(
              color: color.shade800,
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _textoReciboTabla(dynamic valor) {
    final texto = valor?.toString() ?? "";

    return Text(
      texto.isEmpty ? "—" : texto,
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _dropdownFiltroReciboERP({
    required String label,
    required String value,
    required List<String> items,
    required Function(String?) onChanged,
  }) {
    final uniqueItems = items.toSet().toList();

    return SizedBox(
      width: 190,
      child: DropdownButtonFormField<String>(
        value: uniqueItems.contains(value) ? value : uniqueItems.first,
        isExpanded: true,
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: Colors.grey.shade50,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
        ),
        items: uniqueItems.map((item) {
          return DropdownMenuItem<String>(
            value: item,
            child: Text(item, overflow: TextOverflow.ellipsis),
          );
        }).toList(),
        onChanged: onChanged,
      ),
    );
  }

  Widget _botonFechaReciboERP({
    required String texto,
    required IconData icono,
    required VoidCallback onPressed,
  }) {
    return OutlinedButton.icon(
      onPressed: onPressed,
      icon: Icon(icono),
      label: Text(texto),
      style: OutlinedButton.styleFrom(
        backgroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 17),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }

  Widget buildRecibosList() {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _getRecibos(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return Container(
            height: 300,
            alignment: Alignment.center,
            child: const CircularProgressIndicator(),
          );
        }

        final data = snapshot.data!;

        if (data.isEmpty) {
          return Container(
            width: double.infinity,
            padding: const EdgeInsets.all(30),
            decoration: _decoracionRecibosERP(),
            child: Column(
              children: [
                Icon(
                  Icons.receipt_long_outlined,
                  size: 54,
                  color: Colors.grey.shade400,
                ),
                const SizedBox(height: 12),
                const Text(
                  "No hay recibos",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                Text(
                  "No se han encontrado recibos con los filtros actuales.",
                  style: TextStyle(color: Colors.grey.shade600),
                ),
              ],
            ),
          );
        }

        return Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: _decoracionRecibosERP(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Últimos recibos",
                style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
              ),

              const SizedBox(height: 14),

              ProgressiveListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: data.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, i) {
                  final item = data[i];
                  final estado = item['estado']?.toString() ?? '';

                  return Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade50,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.grey.shade200),
                    ),
                    child: Row(
                      children: [
                        _chipEstadoReciboERP(estado),

                        const SizedBox(width: 14),

                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item['cliente']?.toString().isEmpty ?? true
                                    ? "Cliente sin nombre"
                                    : item['cliente'].toString(),
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 15,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                "Póliza: ${item['poliza'] ?? 'Sin póliza'} · ${item['compania'] ?? 'Sin compañía'}",
                                style: TextStyle(
                                  color: Colors.grey.shade600,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(width: 14),

                        Text(
                          _formatoEuroKpi(item['importe']),
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                          ),
                        ),

                        PopupMenuButton<String>(
                          icon: const Icon(Icons.more_vert),
                          itemBuilder: (context) => const [
                            PopupMenuItem(
                              value: "ver",
                              child: Text("Ver detalle"),
                            ),
                            PopupMenuItem(
                              value: "editar",
                              child: Text("Editar"),
                            ),
                            PopupMenuItem(
                              value: "gestionar",
                              child: Text("Gestionar"),
                            ),
                            PopupMenuItem(
                              value: "comentario",
                              child: Text("Añadir comentario"),
                            ),
                            PopupMenuItem(
                              value: "notificar",
                              child: Text("Notificar"),
                            ),
                          ],
                          onSelected: (value) {
                            if (value == "ver") {
                              mostrarDetalleRecibo(item);
                            } else if (value == "editar") {
                              mostrarEditarRecibo(item);
                            } else if (value == "gestionar") {
                              mostrarGestionRecibo(item);
                            } else if (value == "comentario") {
                              mostrarComentarioRecibo(item);
                            } else if (value == "notificar") {
                              abrirPantallaNotificacion(context, item);
                            }
                          },
                        ),
                      ],
                    ),
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Widget buildCargarRecibos() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Cargar Recibos",
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          ),

          const SizedBox(height: 30),

          Row(
            children: [
              Expanded(
                child: _actionCard(
                  Icons.edit_note,
                  "Carga Manual",
                  "Introducir recibos uno a uno",
                ),
              ),

              const SizedBox(width: 20),

              Expanded(
                child: _actionCard(
                  Icons.file_upload,
                  "Importar Excel",
                  "Subir CSV o Excel",
                ),
              ),
            ],
          ),

          const SizedBox(height: 20),

          Row(
            children: [
              Expanded(
                child: _actionCard(
                  Icons.cloud_upload,
                  "Carga Masiva",
                  "Miles de recibos a la vez",
                ),
              ),

              const Spacer(),
            ],
          ),

          const SizedBox(height: 40),

          const Text(
            "Últimos archivos cargados",
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),

          const SizedBox(height: 20),

          if (modoCarga == "Importar Excel" || modoCarga == "Carga Masiva")
            buildImportadorExcel(),

          if (modoCarga == "Carga Manual")
            Container(
              margin: const EdgeInsets.only(top: 20),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade300),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  TextField(
                    controller: numeroReciboCtrl,
                    decoration: const InputDecoration(
                      labelText: "Número de recibo",
                    ),
                  ),

                  TextField(
                    controller: polizaCtrl,
                    decoration: const InputDecoration(labelText: "Póliza"),
                  ),

                  TextField(
                    controller: clienteCtrl,
                    decoration: const InputDecoration(labelText: "Cliente"),
                  ),

                  TextField(
                    controller: importeCtrl,
                    decoration: const InputDecoration(labelText: "Importe"),
                  ),

                  TextField(
                    controller: companiaCtrl,
                    decoration: const InputDecoration(labelText: "Compañía"),
                  ),

                  TextField(
                    controller: estadoCtrl,
                    decoration: const InputDecoration(labelText: "Estado"),
                  ),

                  TextField(
                    controller: fechaCtrl,
                    decoration: const InputDecoration(labelText: "Fecha"),
                  ),

                  const SizedBox(height: 20),

                  ElevatedButton(
                    onPressed: insertarManual,
                    child: const Text("GUARDAR RECIBO"),
                  ),
                ],
              ),
            ),

          if (headers.isNotEmpty) buildColumnMapper(),

          Container(
            height: 300,
            width: double.infinity,

            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.shade300),
              borderRadius: BorderRadius.circular(12),
            ),

            child: const Center(
              child: Text("Aquí aparecerán los archivos importados"),
            ),
          ),
        ],
      ),
    );
  }

  Widget _actionCard(IconData icon, String title, String subtitle) {
    return InkWell(
      onTap: () {
        setState(() {
          modoCarga = title;
        });
      },

      child: Container(
        height: 170,

        padding: const EdgeInsets.all(20),

        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.grey.shade300),
        ),

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 50, color: Colors.blue),

            const SizedBox(height: 15),

            Text(
              title,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),

            const SizedBox(height: 8),

            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildImportadorExcel() {
    return Container(
      margin: const EdgeInsets.only(top: 20),

      padding: const EdgeInsets.all(25),

      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.grey.shade300),
      ),

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Importación de Excel",
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),

          const SizedBox(height: 20),

          Container(
            height: 200,
            width: double.infinity,

            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(15),
              border: Border.all(color: Colors.grey.shade400, width: 2),
            ),

            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.upload_file, size: 70, color: Colors.blue.shade700),

                const SizedBox(height: 15),

                const Text(
                  "Arrastra aquí el Excel",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),

                const SizedBox(height: 10),

                ElevatedButton.icon(
                  onPressed: seleccionarExcel,
                  icon: const Icon(Icons.folder_open),
                  label: const Text("Seleccionar archivo"),
                ),
              ],
            ),
          ),

          const SizedBox(height: 25),

          const Text(
            "Previsualización",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
          ),

          const SizedBox(height: 10),

          Container(
            height: 250,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.shade300),
              borderRadius: BorderRadius.circular(12),
            ),
            child: excelPreview.isEmpty
                ? const Center(
                    child: Text("Aquí se mostrarán las filas del Excel"),
                  )
                : SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: ProgressiveRecords(
                      count: (excelPreview.length - 1).clamp(
                        0,
                        excelPreview.length,
                      ),
                      resetKey: progressiveRecordKey(excelPreview),
                      showFooter: true,
                      builder: (context, _visibleRows) => DataTable(
                        columns: excelPreview.first
                            .map((e) => DataColumn(label: Text(e.toString())))
                            .toList(),
                        rows: excelPreview
                            .skip(1)
                            .take(_visibleRows)
                            .map(
                              (row) => DataRow(
                                cells: List.generate(
                                  excelPreview.first.length,
                                  (index) => DataCell(
                                    Text(
                                      index < row.length
                                          ? row[index].toString()
                                          : '',
                                    ),
                                  ),
                                ),
                              ),
                            )
                            .toList(),
                      ),
                    ),
                  ),
          ),
          const SizedBox(height: 20),

          ElevatedButton(
            onPressed: isImporting ? null : importarMasivoASupabase,
            child: Text(isImporting ? "IMPORTANDO..." : "IMPORTACIÓN MASIVA"),
          ),

          const SizedBox(height: 10),

          if (isImporting)
            Text(
              "Progreso: $importProgress / $importTotal",
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
        ],
      ),
    );
  }

  Widget buildColumnMapper() {
    return Container(
      margin: const EdgeInsets.only(top: 20),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'MAPEO DE COLUMNAS',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ),
              OutlinedButton.icon(
                onPressed: autoDetectMapping,
                icon: const Icon(Icons.auto_fix_high_rounded),
                label: const Text('AUTO-MAPEAR'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Text(
            'Obligatorios: número de recibo, póliza, importe, estado y fecha. '
            'El agente puede indicarse por nombre, email o identificador; si '
            'falta, se obtiene automáticamente desde la póliza.',
            style: TextStyle(color: Colors.black54),
          ),
          const SizedBox(height: 15),

          ...headers.map((header) {
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: Text(
                      header,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),

                  Expanded(
                    flex: 3,
                    child: DropdownButton<String>(
                      value: columnMapping[header],
                      isExpanded: true,
                      hint: const Text("No mapear"),
                      items: camposCargaRecibos.map((field) {
                        return DropdownMenuItem(
                          value: field,
                          child: Text(field),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          if (value == null) {
                            columnMapping.remove(header);
                            return;
                          }

                          columnMapping.removeWhere(
                            (source, destination) =>
                                source != header && destination == value,
                          );
                          columnMapping[header] = value;
                        });
                      },
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
        ],
      ),
    );
  }

  void autoDetectMapping() {
    columnMapping.clear();

    for (final header in headers) {
      final normalized = _normalizarCabeceraRecibo(header);
      final mapped = _campoReciboParaCabecera(normalized);

      if (mapped != null && !columnMapping.containsValue(mapped)) {
        columnMapping[header] = mapped;
      }
    }

    setState(() {});
  }

  String _normalizarCabeceraRecibo(String value) {
    return value
        .toLowerCase()
        .replaceAll('á', 'a')
        .replaceAll('é', 'e')
        .replaceAll('í', 'i')
        .replaceAll('ó', 'o')
        .replaceAll('ú', 'u')
        .replaceAll('ü', 'u')
        .replaceAll('ñ', 'n')
        .replaceAll(RegExp(r'[^a-z0-9]+'), ' ')
        .trim()
        .replaceAll(RegExp(r'\s+'), ' ');
  }

  String? _campoReciboParaCabecera(String header) {
    const aliases = <String, String>{
      "numero recibo": "numero_recibo",
      "n recibo": "numero_recibo",
      "num recibo": "numero_recibo",
      "numero de recibo": "numero_recibo",
      "nro recibo": "numero_recibo",
      "referencia recibo": "numero_recibo",
      "id recibo": "numero_recibo",
      "recibo": "numero_recibo",
      "poliza": "poliza",
      "n poliza": "poliza",
      "numero poliza": "poliza",
      "numero de poliza": "poliza",
      "referencia poliza": "poliza",
      "cliente": "cliente",
      "tomador": "cliente",
      "asegurado": "cliente",
      "importe": "importe",
      "importe recibo": "importe",
      "importe total": "importe",
      "prima recibo": "importe",
      "prima": "importe",
      "total": "importe",
      "compania": "compania",
      "aseguradora": "compania",
      "estado": "estado",
      "fecha": "fecha",
      "fecha recibo": "fecha",
      "fecha emision": "fecha",
      "fecha de emision": "fecha",
      "fecha vencimiento": "fecha",
      "agente": "agente",
      "comercial": "agente",
      "mediador": "agente",
      "colaborador": "agente",
      "responsable": "agente",
      "agente email": "agente",
      "email agente": "agente",
      "motivo": "motivo",
      "estado recibo": "estado_recibo",
      "situacion recibo": "estado_recibo",
      "fecha anulacion": "fecha_anulacion",
      "motivo anulacion": "motivo_anulacion",
      "observaciones anulacion": "observaciones_anulacion",
      "anulacion id": "anulacion_id",
      "id anulacion": "anulacion_id",
      "anulado por": "anulado_por",
    };

    return aliases[header];
  }

  Widget buildDashboardKpis() {
    return FutureBuilder<Map<String, dynamic>>(
      future: _panelRequests.get('dashboard', obtenerKpisDashboard),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final k = snapshot.data!;

        return SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              _kpiDashboardERP(
                icono: Icons.bar_chart_rounded,
                titulo: "Producción Total",
                valor: _formatoEuroKpi(k['produccionActual']),
                porcentaje: _formatoPorcentajeKpi(k['produccionPorcentaje']),
                color: Colors.blue,
              ),
              const SizedBox(width: 14),

              _kpiDashboardERP(
                icono: Icons.shopping_cart_checkout_rounded,
                titulo: "Ventas Totales",
                valor: k['ventasActual'].toString(),
                porcentaje: _formatoPorcentajeKpi(k['ventasPorcentaje']),
                color: Colors.indigo,
              ),
              const SizedBox(width: 14),

              _kpiDashboardERP(
                icono: Icons.check_circle_rounded,
                titulo: "Recibos Cobrados",
                valor: _formatoEuroKpi(k['cobradosActual']),
                porcentaje: _formatoPorcentajeKpi(k['cobradosPorcentaje']),
                color: Colors.green,
              ),
              const SizedBox(width: 14),

              _kpiDashboardERP(
                icono: Icons.cancel_rounded,
                titulo: "Recibos Devueltos",
                valor: _formatoEuroKpi(k['devueltosActual']),
                porcentaje: _formatoPorcentajeKpi(k['devueltosPorcentaje']),
                color: Colors.red,
              ),
            ],
          ),
        );
      },
    );
  }

  Widget buildDashboardPageERP() {
    return FutureBuilder<Map<String, dynamic>>(
      future: _panelRequests.get('dashboard', obtenerKpisDashboard),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final k = snapshot.data!;

        final produccion = _toDoubleKpi(k['produccionActual']);
        final ventas = k['ventasActual'] ?? 0;
        final cobrados = _toDoubleKpi(k['cobradosActual']);
        final devueltos = _toDoubleKpi(k['devueltosActual']);
        final primaBrutaEmitida = _toDoubleKpi(k['primaBrutaEmitida']);

        final porcentajeDevolucion = primaBrutaEmitida == 0
            ? 0
            : (devueltos / primaBrutaEmitida) * 100;

        return SingleChildScrollView(
          padding: const EdgeInsets.only(bottom: 40),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.blue.shade800, Colors.indigo.shade700],
                  ),
                  borderRadius: BorderRadius.circular(26),
                ),
                child: Row(
                  children: [
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Dashboard Ejecutivo",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 28,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            "Centro de mando mensual de SafeBrok",
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 15,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Icon(
                      Icons.auto_graph_rounded,
                      color: Colors.white.withOpacity(0.9),
                      size: 50,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              buildDashboardKpis(),

              const SizedBox(height: 20),

              _panelDashboardERP(
                titulo: "Salud del negocio",
                icono: Icons.health_and_safety_outlined,
                color: porcentajeDevolucion >= 15
                    ? Colors.red
                    : porcentajeDevolucion >= 8
                    ? Colors.orange
                    : Colors.green,
                child: Column(
                  children: [
                    _lineaDashboardERP(
                      "Prima bruta emitida",
                      _formatoEuroKpi(primaBrutaEmitida),
                    ),
                    _lineaDashboardERP("Ventas emitidas", ventas.toString()),
                    _lineaDashboardERP(
                      "Recibos cobrados",
                      _formatoEuroKpi(cobrados),
                    ),
                    _lineaDashboardERP(
                      "Recibos devueltos",
                      _formatoEuroKpi(devueltos),
                    ),
                    const SizedBox(height: 10),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "Ratio devolución: ${porcentajeDevolucion.toStringAsFixed(1)}%",
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    const SizedBox(height: 8),
                    LinearProgressIndicator(
                      value: (porcentajeDevolucion / 30).clamp(0, 1),
                      minHeight: 10,
                      backgroundColor: Colors.grey.shade200,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 18),

              _panelDashboardERP(
                titulo: "Alertas inteligentes",
                icono: Icons.notifications_active_outlined,
                color: Colors.orange,
                child: Column(
                  children: [
                    if (devueltos > 0)
                      _alertaDashboardERP(
                        "Recibos devueltos detectados",
                        "Hay ${_formatoEuroKpi(devueltos)} en recibos devueltos este mes.",
                        Colors.red,
                        Icons.warning_amber_rounded,
                      )
                    else
                      _alertaDashboardERP(
                        "Todo bajo control",
                        "No hay recibos devueltos detectados este mes.",
                        Colors.green,
                        Icons.check_circle_outline,
                      ),

                    if (ventas == 0)
                      _alertaDashboardERP(
                        "Sin ventas este mes",
                        "Todavía no hay ventas registradas en el mes actual.",
                        Colors.blueGrey,
                        Icons.info_outline,
                      ),
                  ],
                ),
              ),

              const SizedBox(height: 18),

              _panelDashboardERP(
                titulo: "Acciones rápidas",
                icono: Icons.flash_on_outlined,
                color: Colors.blue,
                child: Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    _botonDashboardERP(
                      "Ventas",
                      Icons.euro_outlined,
                      Colors.blue,
                      () {
                        setState(() {
                          selectedMenu = "ventas";
                        });
                      },
                    ),
                    _botonDashboardERP(
                      "Cargar recibos",
                      Icons.upload_file,
                      Colors.indigo,
                      () {
                        setState(() {
                          selectedMenu = "cargar_recibos";
                        });
                      },
                    ),
                    _botonDashboardERP(
                      "Devueltos",
                      Icons.cancel_outlined,
                      Colors.red,
                      () {
                        setState(() {
                          selectedMenu = "recibos_devueltos";
                        });
                        cargarRecibos();
                      },
                    ),
                    _botonDashboardERP(
                      "Pendientes",
                      Icons.schedule_outlined,
                      Colors.orange,
                      () {
                        setState(() {
                          selectedMenu = "recibos_pendientes";
                        });
                        cargarRecibos();
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _panelDashboardERP({
    required String titulo,
    required IconData icono,
    required MaterialColor color,
    required Widget child,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icono, color: color.shade700),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  titulo,
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }

  Widget _lineaDashboardERP(String titulo, String valor) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              titulo,
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
          Text(valor, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _alertaDashboardERP(
    String titulo,
    String texto,
    MaterialColor color,
    IconData icono,
  ) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: color.shade50,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.shade100),
      ),
      child: Row(
        children: [
          Icon(icono, color: color.shade700),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  titulo,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 3),
                Text(
                  texto,
                  style: TextStyle(color: Colors.grey.shade700, fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _botonDashboardERP(
    String texto,
    IconData icono,
    MaterialColor color,
    VoidCallback onTap,
  ) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: 165,
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          color: color.shade50,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.shade100),
        ),
        child: Row(
          children: [
            Icon(icono, color: color.shade700, size: 22),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                texto,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: color.shade800,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _kpiDashboardERP({
    required IconData icono,
    required String titulo,
    required String valor,
    required String porcentaje,
    required MaterialColor color,
  }) {
    final esNegativo = porcentaje.startsWith('-');

    return Container(
      width: 250,
      height: 170,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.grey.shade300),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 12,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: color.shade50,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icono, color: color.shade700, size: 25),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                decoration: BoxDecoration(
                  color: esNegativo ? Colors.red.shade50 : Colors.green.shade50,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  porcentaje,
                  style: TextStyle(
                    color: esNegativo
                        ? Colors.red.shade700
                        : Colors.green.shade700,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          Text(
            titulo,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Colors.grey.shade600,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),

          const SizedBox(height: 6),

          Text(
            valor,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),

          const SizedBox(height: 4),

          Text(
            "vs mes anterior",
            style: TextStyle(color: Colors.grey.shade500, fontSize: 11),
          ),
        ],
      ),
    );
  }

  Widget _panelDashboardSimple({
    required String titulo,
    required IconData icono,
    required MaterialColor color,
    required List<Widget> children,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.grey.shade300),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 12,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: color.shade50,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icono, color: color.shade700),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  titulo,
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...children,
        ],
      ),
    );
  }

  Widget _lineaDashboardSimple(String titulo, String valor) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              titulo,
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
          Text(valor, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _alertaDashboardSimple(
    String titulo,
    String texto,
    MaterialColor color,
    IconData icono,
  ) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.shade50,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.shade100),
      ),
      child: Row(
        children: [
          Icon(icono, color: color.shade700),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  titulo,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 3),
                Text(
                  texto,
                  style: TextStyle(color: Colors.grey.shade700, fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _botonDashboardSimple(
    String texto,
    IconData icono,
    MaterialColor color,
    VoidCallback onTap,
  ) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: 170,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: color.shade50,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.shade100),
        ),
        child: Row(
          children: [
            Icon(icono, color: color.shade700),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                texto,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: color.shade800,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildKpiCard(
    IconData icon,
    String titulo,
    String valor,
    String porcentaje,
    MaterialColor color,
  ) {
    final esNegativo = porcentaje.startsWith('-');

    return Container(
      width: 270,
      constraints: const BoxConstraints(minHeight: 185),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: color.shade50,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(icon, size: 28, color: color.shade700),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: esNegativo ? Colors.red.shade50 : Colors.green.shade50,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(
                    color: esNegativo
                        ? Colors.red.shade100
                        : Colors.green.shade100,
                  ),
                ),
                child: Text(
                  porcentaje,
                  style: TextStyle(
                    color: esNegativo
                        ? Colors.red.shade700
                        : Colors.green.shade700,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 20),

          Text(
            titulo,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 13,
              color: Colors.grey.shade600,
              fontWeight: FontWeight.w600,
            ),
          ),

          const SizedBox(height: 8),

          Text(
            valor,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 27,
              fontWeight: FontWeight.bold,
              letterSpacing: -0.5,
            ),
          ),

          const SizedBox(height: 10),

          Text(
            "Mes actual vs mes anterior",
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
          ),
        ],
      ),
    );
  }

  Future<Map<String, dynamic>> obtenerKpisDashboard() async {
    try {
      final supabase = Supabase.instance.client;

      final ahora = DateTime.now();

      final inicioMesActual = DateTime(ahora.year, ahora.month, 1);
      final inicioMesSiguiente = DateTime(ahora.year, ahora.month + 1, 1);
      final inicioMesAnterior = DateTime(ahora.year, ahora.month - 1, 1);

      if (!veTodoERP && authIdsPermitidosERP.isEmpty) return _kpisDashboardVacios();
      final ventas = await PolicySalesQuery.load(supabase,
        authIds: veTodoERP ? null : authIdsPermitidosERP,
        start: inicioMesAnterior, endExclusive: inicioMesSiguiente,
        select: 'id,numero_poliza,fecha_efecto,producto,prima_anual_neta,prima_anual_bruta,prima_anual,precio',
      );

      final ventasMesActual = ventas.where((v) {
        final fecha = _leerFechaKpi(v['fecha_efecto']);

        return fecha != null &&
            !fecha.isBefore(inicioMesActual) &&
            fecha.isBefore(inicioMesSiguiente);
      }).toList();

      final ventasMesAnterior = ventas.where((v) {
        final fecha = _leerFechaKpi(v['fecha_efecto']);

        return fecha != null &&
            !fecha.isBefore(inicioMesAnterior) &&
            fecha.isBefore(inicioMesActual);
      }).toList();

      double calcularPrima(Map<String, dynamic> v) => PremiumWeighting.net(v);

      final produccionActual = ventasMesActual.fold<double>(
        0,
        (suma, v) => suma + calcularPrima(v),
      );

      final produccionAnterior = ventasMesAnterior.fold<double>(
        0,
        (suma, v) => suma + calcularPrima(v),
      );

      final ventasActual = ventasMesActual.length;
      final ventasAnterior = ventasMesAnterior.length;

      final polizasMesActual = ventasMesActual
          .map((v) => v['numero_poliza']?.toString() ?? '')
          .where((p) => p.isNotEmpty)
          .toSet()
          .toList();

      final polizasMesAnterior = ventasMesAnterior
          .map((v) => v['numero_poliza']?.toString() ?? '')
          .where((p) => p.isNotEmpty)
          .toSet()
          .toList();

      Future<List<Map<String, dynamic>>> cargarRecibosPorPolizas(
        List<String> polizas,
      ) async {
        if (polizas.isEmpty) return [];

        final rows = <Map<String, dynamic>>[];
        for (var start = 0; start < polizas.length; start += 80) {
          final block = polizas.sublist(start, (start + 80).clamp(0, polizas.length));
          for (var offset = 0; ; offset += 1000) {
            final page = await supabase.from('recibos').select()
                .inFilter('poliza', block).order('id').range(offset, offset + 999);
            rows.addAll(List<Map<String, dynamic>>.from(page));
            if (page.length < 1000) break;
          }
        }
        return rows;
      }

      final recibosPorMes = await Future.wait([
        cargarRecibosPorPolizas(polizasMesActual),
        cargarRecibosPorPolizas(polizasMesAnterior),
      ]);
      final recibosMesActual = recibosPorMes[0];
      final recibosMesAnterior = recibosPorMes[1];

      final cobradosActual = recibosMesActual
          .where((r) {
            final estado = '${r['estado'] ?? r['gestion'] ?? ''}'.toUpperCase();
            return estado.contains('COBRADO');
          })
          .fold<double>(0, (suma, r) => suma + _importeReciboKpi(r));

      final cobradosAnterior = recibosMesAnterior
          .where((r) {
            final estado = '${r['estado'] ?? r['gestion'] ?? ''}'.toUpperCase();
            return estado.contains('COBRADO');
          })
          .fold<double>(0, (suma, r) => suma + _importeReciboKpi(r));

      final devueltosActual = recibosMesActual
          .where((r) {
            final estado = '${r['estado'] ?? r['gestion'] ?? ''}'.toUpperCase();
            return estado.contains('DEVUELTO');
          })
          .fold<double>(0, (suma, r) => suma + _importeReciboKpi(r));

      final devueltosAnterior = recibosMesAnterior
          .where((r) {
            final estado = '${r['estado'] ?? r['gestion'] ?? ''}'.toUpperCase();
            return estado.contains('DEVUELTO');
          })
          .fold<double>(0, (suma, r) => suma + _importeReciboKpi(r));

      final primaBrutaEmitida = ventasMesActual.fold<double>(
        0,
        (suma, v) => suma + PremiumWeighting.gross(v),
      );

      print("KPIS ERP MES ACTUAL -> ventas: ${ventasMesActual.length}");
      print("KPIS ERP MES ACTUAL -> produccion: $produccionActual");
      print("KPIS ERP MES ACTUAL -> recibos: ${recibosMesActual.length}");

      return {
        'produccionActual': produccionActual,
        'produccionPorcentaje': _calcularPorcentajeKpi(
          produccionActual,
          produccionAnterior,
        ),
        'ventasActual': ventasActual,
        'ventasPorcentaje': _calcularPorcentajeKpi(
          ventasActual.toDouble(),
          ventasAnterior.toDouble(),
        ),
        'cobradosActual': cobradosActual,
        'cobradosPorcentaje': _calcularPorcentajeKpi(
          cobradosActual,
          cobradosAnterior,
        ),
        'devueltosActual': devueltosActual,
        'devueltosPorcentaje': _calcularPorcentajeKpi(
          devueltosActual,
          devueltosAnterior,
        ),
        'primaBrutaEmitida': primaBrutaEmitida,
      };
    } catch (e) {
      print("❌ ERROR obtenerKpisDashboard: $e");
      return _kpisDashboardVacios();
    }
  }

  Map<String, dynamic> _kpisDashboardVacios() {
    return {
      'produccionActual': 0,
      'produccionPorcentaje': 0,
      'ventasActual': 0,
      'ventasPorcentaje': 0,
      'cobradosActual': 0,
      'cobradosPorcentaje': 0,
      'devueltosActual': 0,
      'devueltosPorcentaje': 0,
      'primaBrutaEmitida': 0,
    };
  }

  DateTime? _leerFechaKpi(dynamic valor) {
    if (valor == null) return null;

    final texto = valor.toString();

    if (texto.contains('/')) {
      final partes = texto.split('/');
      if (partes.length == 3) {
        return DateTime.tryParse(
          '${partes[2]}-${partes[1].padLeft(2, '0')}-${partes[0].padLeft(2, '0')}',
        );
      }
    }

    return DateTime.tryParse(texto);
  }

  double _toDoubleKpi(dynamic valor) {
    if (valor == null) return 0;

    return double.tryParse(valor.toString().replaceAll(',', '.')) ?? 0;
  }

  double _importeReciboKpi(Map<String, dynamic> r) {
    return _toDoubleKpi(
      r['importe'] ?? r['precio'] ?? r['cantidad'] ?? r['prima'] ?? r['total'],
    );
  }

  double _calcularPorcentajeKpi(double actual, double anterior) {
    if (anterior == 0 && actual == 0) return 0;
    if (anterior == 0 && actual > 0) return 100;

    return ((actual - anterior) / anterior) * 100;
  }

  String _formatoPorcentajeKpi(dynamic valor) {
    final numero = _toDoubleKpi(valor);
    final signo = numero > 0 ? '+' : '';

    return '$signo${numero.toStringAsFixed(1)}%';
  }

  String _formatoEuroKpi(dynamic valor) {
    final numero = _toDoubleKpi(valor);
    return '${numero.toStringAsFixed(2)} €';
  }

  void mostrarDetalleRecibo(Map<String, dynamic> recibo) {
    _showPanelDialog(
      context: context,
      builder: (context) {
        return Dialog(
          insetPadding: const EdgeInsets.all(20),
          child: Container(
            width: 900,
            constraints: const BoxConstraints(maxHeight: 700),
            padding: const EdgeInsets.all(20),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // HEADER
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        "Detalle del Recibo",
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.close),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  // RECIBO
                  _buildSectionTitle("🧾 Recibo"),
                  _buildDetail("Póliza", recibo['poliza']),
                  _buildDetail("Estado", recibo['estado']),
                  _buildDetail("Importe", recibo['importe']),
                  _buildDetail("Fecha", recibo['fecha']),
                  _buildDetail("Motivo", recibo['motivo']),

                  const SizedBox(height: 20),

                  // CLIENTE (vinculado por póliza)
                  _buildSectionTitle("👤 Cliente"),
                  FutureBuilder<Map<String, dynamic>?>(
                    future: getClientePorPoliza(recibo['poliza']),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return const CircularProgressIndicator();
                      }

                      final cliente = snapshot.data;

                      if (cliente == null) {
                        return const Text("Cliente no encontrado");
                      }

                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildDetail("Nombre", cliente['nombre']),
                          _buildDetail("DNI", cliente['dni']),
                          _buildDetail("Teléfono", cliente['telefono']),
                          _buildDetail("Email", cliente['email']),
                          _buildDetail("Dirección", cliente['direccion']),
                        ],
                      );
                    },
                  ),

                  const SizedBox(height: 20),

                  // AGENTE
                  _buildSectionTitle("🏢 Agente"),
                  _buildDetail("Agente", recibo['agente']),
                  _buildDetail("Compañía", recibo['compania']),

                  const SizedBox(height: 20),

                  _buildSectionTitle("💬 Comentarios"),
                  FutureBuilder<List<Map<String, dynamic>>>(
                    future: getComentarios(recibo['poliza']),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return const CircularProgressIndicator();
                      }

                      final comentarios = snapshot.data!;

                      if (comentarios.isEmpty) {
                        return const Text("Sin comentarios");
                      }

                      return Column(
                        children: comentarios.map((c) {
                          return Container(
                            margin: const EdgeInsets.symmetric(vertical: 5),
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: Colors.grey[200],
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(c['comentario'] ?? ''),

                                const SizedBox(height: 5),
                                Text(
                                  c['created_at'] ?? '',
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: Colors.grey,
                                  ),
                                ),
                              ],
                            ),
                          );
                        }).toList(),
                      );
                    },
                  ),

                  const SizedBox(height: 20),

                  _buildSectionTitle("💳 Historial de pagos"),

                  FutureBuilder<List<Map<String, dynamic>>>(
                    future: getPagos(recibo['poliza']),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return const CircularProgressIndicator();
                      }

                      final pagos = snapshot.data!;

                      if (pagos.isEmpty) {
                        return const Text("Sin pagos registrados");
                      }

                      return Column(
                        children: pagos.map((p) {
                          return Container(
                            margin: const EdgeInsets.symmetric(vertical: 5),
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: Colors.green.shade50,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text("Método: ${p['metodo']}"),
                                    Text("Estado: ${p['estado']}"),
                                    Text(
                                      p['created_at'] != null
                                          ? "Fecha: ${DateTime.parse(p['created_at']).toLocal().toString().split('.')[0]}"
                                          : "Fecha: sin fecha",
                                      style: const TextStyle(
                                        fontSize: 12,
                                        color: Colors.grey,
                                      ),
                                    ),
                                  ],
                                ),
                                Text("${p['importe']} €"),
                              ],
                            ),
                          );
                        }).toList(),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Future<Map<String, dynamic>?> getClientePorPoliza(String poliza) async {
    final response = await Supabase.instance.client
        .from('clientes')
        .select()
        .eq('poliza', poliza)
        .maybeSingle();

    return response;
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(
        title,
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _buildDetail(String label, dynamic value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 120,
            child: Text(
              "$label:",
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
          Expanded(child: Text(value?.toString() ?? '')),
        ],
      ),
    );
  }

  void mostrarEditarRecibo(Map<String, dynamic> recibo) {
    final estadoController = TextEditingController(text: recibo['estado']);
    final importeController = TextEditingController(
      text: recibo['importe'].toString(),
    );
    final motivoController = TextEditingController(text: recibo['motivo']);

    _showPanelDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Editar Recibo"),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: estadoController,
                  decoration: const InputDecoration(labelText: "Estado"),
                ),

                TextField(
                  controller: importeController,
                  decoration: const InputDecoration(labelText: "Importe"),
                  keyboardType: TextInputType.number,
                ),

                TextField(
                  controller: motivoController,
                  decoration: const InputDecoration(labelText: "Motivo"),
                ),
              ],
            ),
          ),

          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancelar"),
            ),

            ElevatedButton(
              onPressed: () async {
                await Supabase.instance.client
                    .from('recibos')
                    .update({
                      'estado': estadoController.text,
                      'importe': double.tryParse(importeController.text) ?? 0,
                      'motivo': motivoController.text,
                    })
                    .eq('poliza', recibo['poliza']);

                Navigator.pop(context);

                setState(() {});

                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Recibo actualizado")),
                );
              },
              child: const Text("Guardar"),
            ),
          ],
        );
      },
    );
  }

  void mostrarComentarioRecibo(Map<String, dynamic> recibo) {
    final controller = TextEditingController();

    _showPanelDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Añadir comentario"),
          content: TextField(
            controller: controller,
            maxLines: 4,
            decoration: const InputDecoration(
              hintText: "Escribe el comentario...",
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancelar"),
            ),

            ElevatedButton(
              onPressed: () async {
                await Supabase.instance.client
                    .from('recibos_comentarios')
                    .insert({
                      'poliza': recibo['poliza'],
                      'comentario': controller.text,
                      'usuario': 'admin',
                    });

                Navigator.pop(context);

                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Comentario guardado")),
                );
              },
              child: const Text("Guardar"),
            ),
          ],
        );
      },
    );
  }

  Future<List<Map<String, dynamic>>> getComentarios(String poliza) async {
    final response = await Supabase.instance.client
        .from('recibos_comentarios')
        .select()
        .eq('poliza', poliza)
        .order('created_at', ascending: false);

    return List<Map<String, dynamic>>.from(response);
  }

  void mostrarGestionRecibo(Map<String, dynamic> recibo) {
    _showPanelDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Gestionar Recibo"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.credit_card),
                title: const Text("Pago TPV / Tarjeta"),
                onTap: () {
                  Navigator.pop(context);
                  abrirPasarelaTPV(recibo);
                },
              ),

              ListTile(
                leading: const Icon(Icons.cancel, color: Colors.red),
                title: const Text("Dar de baja"),
                onTap: () async {
                  await actualizarEstadoRecibo(recibo, "baja");
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> actualizarEstadoRecibo(
    Map<String, dynamic> recibo,
    String estado,
  ) async {
    await Supabase.instance.client
        .from('recibos')
        .update({'estado': estado})
        .eq('poliza', recibo['poliza']);

    setState(() {});
  }

  void abrirPasarelaTPV(Map<String, dynamic> recibo) {
    _showPanelDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Pago TPV"),
          content: Text("Total a pagar: ${recibo['importe']} €"),
          actions: [
            ElevatedButton(
              onPressed: () async {
                Navigator.pop(context);

                // 🔥 simulamos pago exitoso
                await Future.delayed(const Duration(seconds: 2));

                await Supabase.instance.client.from('recibos_pagos').insert({
                  'poliza': recibo['poliza'],
                  'importe': recibo['importe'],
                  'metodo': 'tpv',
                  'estado': 'ok',
                  'created_at': DateTime.now().toIso8601String(),
                });

                await actualizarEstadoRecibo(recibo, "COBRADO");

                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Pago realizado correctamente")),
                );
              },
              child: const Text("Pagar ahora"),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancelar"),
            ),
          ],
        );
      },
    );
  }

  Future<List<Map<String, dynamic>>> getPagos(String poliza) async {
    final response = await Supabase.instance.client
        .from('recibos_pagos')
        .select()
        .eq('poliza', poliza)
        .order('created_at', ascending: false);

    return List<Map<String, dynamic>>.from(response);
  }

  void abrirPantallaNotificacion(
    BuildContext context,
    Map<String, dynamic> recibo,
  ) {
    final TextEditingController comentarioController = TextEditingController();

    _showPanelDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Notificar póliza"),

          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // 👇 AGENTE AUTOMÁTICO
              FutureBuilder(
                future: Supabase.instance.client
                    .from('agentes')
                    .select()
                    .eq('poliza', recibo['poliza'])
                    .single(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return const CircularProgressIndicator();
                  }

                  final agente = snapshot.data as Map<String, dynamic>;

                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Agente: ${agente['nombre']}"),
                      Text("Email: ${agente['email']}"),

                      const SizedBox(height: 10),

                      Text(
                        "Jefe equipo: ${agente['parent_id']}",
                        style: const TextStyle(color: Colors.grey),
                      ),
                    ],
                  );
                },
              ),

              const SizedBox(height: 15),

              TextField(
                controller: comentarioController,
                decoration: const InputDecoration(
                  labelText: "Comentario (opcional)",
                ),
                maxLines: 3,
              ),
            ],
          ),

          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancelar"),
            ),

            ElevatedButton(
              onPressed: () async {
                final comentario = comentarioController.text;

                // 🔥 INSERT NOTIFICACIÓN
                await Supabase.instance.client.from('notificaciones').insert({
                  'poliza': recibo['poliza'],
                  'agente_id': recibo['agente'],
                  'comentario': comentario,
                  'leido_agente': false,
                  'leido_jefe': false,
                  'created_at': DateTime.now().toIso8601String(),
                });

                Navigator.pop(context);
              },
              child: const Text("Enviar"),
            ),
          ],
        );
      },
    );
  }

  Widget buildClientesPage() {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _panelRequests.get('clientes', getClientes),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return Center(
            child: Text(
              "Error cargando clientes: ${snapshot.error}",
              style: const TextStyle(color: Colors.red),
            ),
          );
        }

        final clientes = filtrarClientes(snapshot.data ?? []);

        final totalClientes = clientes.length;

        final conTelefono = clientes.where((c) {
          return (c['telefono']?.toString().trim() ?? '').isNotEmpty;
        }).length;

        final conEmail = clientes.where((c) {
          return (c['email']?.toString().trim() ?? '').isNotEmpty;
        }).length;

        final conPoliza = clientes.where((c) {
          return (c['compania']?.toString().trim() ?? '').isNotEmpty;
        }).length;

        final provincias = clientes
            .map((c) => c['provincia']?.toString().trim() ?? '')
            .where((p) => p.isNotEmpty)
            .toSet()
            .length;

        return SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: Colors.grey.shade300),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.04),
                      blurRadius: 18,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        color: Colors.blue.shade50,
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Icon(
                        Icons.people_alt_outlined,
                        color: Colors.blue.shade700,
                        size: 36,
                      ),
                    ),

                    const SizedBox(width: 16),

                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Clientes",
                            style: TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 5),
                          Text(
                            "Panel profesional de clientes, pólizas, recibos y gestiones",
                            style: TextStyle(color: Colors.grey),
                          ),
                        ],
                      ),
                    ),

                    ElevatedButton.icon(
                      onPressed: () async {
                        await exportClientes(clientes);
                      },
                      icon: const Icon(Icons.file_download_outlined),
                      label: const Text("Exportar Excel"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green.shade700,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 18,
                          vertical: 15,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              Wrap(
                spacing: 14,
                runSpacing: 14,
                children: [
                  _kpiAgenteERP(
                    "Clientes",
                    totalClientes.toString(),
                    Icons.people_alt_outlined,
                    Colors.blue,
                  ),
                  _kpiAgenteERP(
                    "Con teléfono",
                    conTelefono.toString(),
                    Icons.phone_android_outlined,
                    Colors.green,
                  ),
                  _kpiAgenteERP(
                    "Con email",
                    conEmail.toString(),
                    Icons.email_outlined,
                    Colors.indigo,
                  ),
                  _kpiAgenteERP(
                    "Con póliza",
                    conPoliza.toString(),
                    Icons.description_outlined,
                    Colors.orange,
                  ),
                  _kpiAgenteERP(
                    "Provincias",
                    provincias.toString(),
                    Icons.map_outlined,
                    Colors.deepPurple,
                  ),
                ],
              ),

              const SizedBox(height: 16),

              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: Colors.grey.shade300),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.035),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Filtros de clientes",
                      style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 14),

                    Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      children: [
                        _buildFilterBox(
                          title: "Agente",
                          child: SizedBox(
                            width: 190,
                            child: DropdownButton<String>(
                              value: filtroAgente,
                              isExpanded: true,
                              hint: const Text("Todos"),
                              items: listaAgentes.map((agente) {
                                return DropdownMenuItem(
                                  value: agente,
                                  child: Text(
                                    agente,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                );
                              }).toList(),
                              onChanged: (value) {
                                setState(() {
                                  filtroAgente = value;
                                });
                              },
                            ),
                          ),
                        ),

                        _buildFilterBox(
                          title: "Jefe Equipo",
                          child: SizedBox(
                            width: 190,
                            child: DropdownButton<String>(
                              value: filtroJefeEquipo,
                              isExpanded: true,
                              hint: const Text("Todos"),
                              items: listaJefes.map((jefe) {
                                return DropdownMenuItem(
                                  value: jefe,
                                  child: Text(
                                    jefe,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                );
                              }).toList(),
                              onChanged: (value) {
                                setState(() {
                                  filtroJefeEquipo = value;
                                });
                              },
                            ),
                          ),
                        ),

                        _buildFilterBox(
                          title: "Compañía",
                          child: SizedBox(
                            width: 190,
                            child: DropdownButton<String>(
                              value: filtroCompania,
                              isExpanded: true,
                              hint: const Text("Todas"),
                              items: listaCompanias.map((compania) {
                                return DropdownMenuItem(
                                  value: compania,
                                  child: Text(
                                    compania,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                );
                              }).toList(),
                              onChanged: (value) {
                                setState(() {
                                  filtroCompania = value;
                                });
                              },
                            ),
                          ),
                        ),

                        _buildFilterBox(
                          title: "Fecha desde",
                          child: TextButton.icon(
                            onPressed: () async {
                              final date = await showDatePicker(
                                context: context,
                                firstDate: DateTime(2020),
                                lastDate: DateTime(2035),
                                initialDate: DateTime.now(),
                              );

                              if (date != null) {
                                setState(() {
                                  fechaDesde = date;
                                });
                              }
                            },
                            icon: const Icon(Icons.calendar_month_outlined),
                            label: Text(
                              fechaDesde == null
                                  ? "Seleccionar"
                                  : fechaDesde.toString().split(" ")[0],
                            ),
                          ),
                        ),

                        _buildFilterBox(
                          title: "Fecha hasta",
                          child: TextButton.icon(
                            onPressed: () async {
                              final date = await showDatePicker(
                                context: context,
                                firstDate: DateTime(2020),
                                lastDate: DateTime(2035),
                                initialDate: DateTime.now(),
                              );

                              if (date != null) {
                                setState(() {
                                  fechaHasta = date;
                                });
                              }
                            },
                            icon: const Icon(Icons.event_available_outlined),
                            label: Text(
                              fechaHasta == null
                                  ? "Seleccionar"
                                  : fechaHasta.toString().split(" ")[0],
                            ),
                          ),
                        ),

                        SizedBox(
                          height: 62,
                          child: ElevatedButton.icon(
                            onPressed: () {
                              setState(() {
                                filtroAgente = null;
                                filtroJefeEquipo = null;
                                filtroCompania = null;
                                fechaDesde = null;
                                fechaHasta = null;
                              });
                            },
                            icon: const Icon(Icons.clear),
                            label: const Text("Limpiar filtros"),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blueGrey.shade700,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: Colors.grey.shade300),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.035),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Expanded(
                          child: Text(
                            "Listado profesional de clientes",
                            style: TextStyle(
                              fontSize: 19,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        Text(
                          "${clientes.length} registros",
                          style: TextStyle(
                            color: Colors.grey.shade600,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 14),

                    if (clientes.isEmpty)
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(30),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade50,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: Colors.grey.shade200),
                        ),
                        child: Column(
                          children: [
                            Icon(
                              Icons.people_outline,
                              size: 54,
                              color: Colors.grey.shade400,
                            ),
                            const SizedBox(height: 10),
                            const Text(
                              "No hay clientes para mostrar",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "Revisa los filtros o la estructura de permisos del usuario.",
                              style: TextStyle(color: Colors.grey.shade600),
                            ),
                          ],
                        ),
                      )
                    else
                      TablaConScrollHorizontalERP(
                        child: ProgressiveRecords(
                          count: clientes.length,
                          resetKey: progressiveRecordKey(clientes),
                          showFooter: true,
                          builder: (context, _visibleRows) => DataTable(
                            columnSpacing: 22,
                            horizontalMargin: 12,
                            dataRowMinHeight: 64,
                            dataRowMaxHeight: 72,
                            headingRowHeight: 58,
                            headingRowColor: WidgetStateProperty.all(
                              Colors.grey.shade100,
                            ),
                            columns: const [
                              DataColumn(label: Text("Cliente")),
                              DataColumn(label: Text("Contacto")),
                              DataColumn(label: Text("Ubicación")),
                              DataColumn(label: Text("Agente")),
                              DataColumn(label: Text("Jefe")),
                              DataColumn(label: Text("Compañía")),
                              DataColumn(label: Text("Fecha")),
                              DataColumn(label: Text("Acciones")),
                            ],
                            rows: clientes.take(_visibleRows).map((c) {
                              final nombreCompleto =
                                  "${c['nombre'] ?? ''} ${c['apellidos'] ?? ''}"
                                      .trim();

                              return DataRow(
                                cells: [
                                  DataCell(
                                    Row(
                                      children: [
                                        CircleAvatar(
                                          radius: 18,
                                          backgroundColor: Colors.blue.shade50,
                                          child: Icon(
                                            Icons.person_outline,
                                            color: Colors.blue.shade700,
                                            size: 20,
                                          ),
                                        ),
                                        const SizedBox(width: 10),
                                        SizedBox(
                                          width: 210,
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                nombreCompleto.isEmpty
                                                    ? "Cliente sin nombre"
                                                    : nombreCompleto,
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: const TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              Text(
                                                c['dni']?.toString() ?? '',
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(
                                                  color: Colors.grey.shade600,
                                                  fontSize: 12,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),

                                  DataCell(
                                    SizedBox(
                                      width: 190,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            c['telefono']?.toString() ?? '—',
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          Text(
                                            c['email']?.toString() ?? '—',
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              color: Colors.grey.shade600,
                                              fontSize: 12,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),

                                  DataCell(
                                    SizedBox(
                                      width: 220,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            c['poblacion']?.toString() ?? '—',
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          Text(
                                            "${c['provincia'] ?? ''} ${c['codigo_postal'] ?? ''}"
                                                .trim(),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              color: Colors.grey.shade600,
                                              fontSize: 12,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),

                                  DataCell(
                                    SizedBox(
                                      width: 180,
                                      child: Text(
                                        c['agente_nombre']?.toString() ?? '—',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),

                                  DataCell(
                                    SizedBox(
                                      width: 180,
                                      child: Text(
                                        c['jefe_nombre']?.toString() ?? '—',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),

                                  DataCell(
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 10,
                                        vertical: 6,
                                      ),
                                      decoration: BoxDecoration(
                                        color: Colors.indigo.shade50,
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Text(
                                        c['compania']?.toString() ?? '—',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: Colors.indigo.shade700,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                  ),

                                  DataCell(
                                    SizedBox(
                                      width: 130,
                                      child: Text(
                                        c['created_at']
                                                ?.toString()
                                                .split('T')
                                                .first ??
                                            '—',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),

                                  DataCell(
                                    PopupMenuButton<String>(
                                      icon: const Icon(Icons.more_vert),
                                      onSelected: (value) {
                                        if (value == 'detalle') {
                                          mostrarDetalleCliente(c);
                                        }

                                        if (value == 'editar') {
                                          editarCliente(c);
                                        }

                                        if (value == 'polizas') {
                                          verPolizasCliente(c);
                                        }

                                        if (value == 'recibos') {
                                          mostrarRecibosCliente(c);
                                        }

                                        if (value == 'gestion') {
                                          registrarGestionCliente(c);
                                        }

                                        if (value == 'anular') {
                                          anularCliente(c);
                                        }
                                      },
                                      itemBuilder: (context) => const [
                                        PopupMenuItem(
                                          value: 'detalle',
                                          child: Text('👁 Ver detalle'),
                                        ),
                                        PopupMenuItem(
                                          value: 'editar',
                                          child: Text('✏️ Editar cliente'),
                                        ),
                                        PopupMenuItem(
                                          value: 'polizas',
                                          child: Text('📄 Ver pólizas'),
                                        ),
                                        PopupMenuItem(
                                          value: 'recibos',
                                          child: Text('💰 Ver recibos'),
                                        ),
                                        PopupMenuItem(
                                          value: 'gestion',
                                          child: Text('📞 Registrar gestión'),
                                        ),
                                        PopupMenuItem(
                                          value: 'anular',
                                          child: Text('🚫 Anular cliente'),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> mostrarDetalleCliente(Map<String, dynamic> cliente) async {
    final ventas = await Supabase.instance.client
        .from('ventas')
        .select()
        .eq('cliente_id', cliente['id']);

    double primaTotal = 0;
    double comisionTotal = 0;

    for (final venta in ventas) {
      primaTotal += PremiumWeighting.amount(venta, venta['prima_anual']);

      comisionTotal += (venta['comision'] ?? 0).toDouble();
    }

    if (!mounted) return;

    _showPanelDialog(
      context: context,
      builder: (_) {
        return Dialog(
          child: Container(
            width: 1000,
            padding: const EdgeInsets.all(25),

            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                Text(
                  "${cliente['nombre']} ${cliente['apellidos']}",
                  style: const TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 20),

                Wrap(
                  spacing: 30,
                  runSpacing: 20,
                  children: [
                    Text("📧 ${cliente['email'] ?? ''}"),

                    Text("📱 ${cliente['telefono'] ?? ''}"),

                    Text("📍 ${cliente['direccion'] ?? ''}"),

                    Text("${cliente['codigo_postal'] ?? ''}"),

                    Text("${cliente['provincia'] ?? ''}"),

                    Text("${cliente['poblacion'] ?? ''}"),
                  ],
                ),

                const SizedBox(height: 30),

                Row(
                  children: [
                    _detalleKpi("Pólizas", ventas.length.toString()),

                    const SizedBox(width: 20),

                    _detalleKpi(
                      "Prima Total",
                      "${primaTotal.toStringAsFixed(2)}€",
                    ),

                    const SizedBox(width: 20),

                    _detalleKpi(
                      "Comisiones",
                      "${comisionTotal.toStringAsFixed(2)}€",
                    ),
                  ],
                ),

                const SizedBox(height: 30),

                const Text(
                  "Pólizas del cliente",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),

                const SizedBox(height: 15),

                SizedBox(
                  height: 300,

                  child: SingleChildScrollView(
                    child: ProgressiveRecords(
                      count: ventas.length,
                      resetKey: progressiveRecordKey(ventas),
                      showFooter: true,
                      builder: (context, _visibleRows) => DataTable(
                        columns: const [
                          DataColumn(label: Text("Producto")),

                          DataColumn(label: Text("Compañía")),

                          DataColumn(label: Text("Prima")),

                          DataColumn(label: Text("Comisión")),

                          DataColumn(label: Text("Póliza")),
                        ],

                        rows: ventas.take(_visibleRows).map((v) {
                          return DataRow(
                            cells: [
                              DataCell(Text(v['producto']?.toString() ?? '')),

                              DataCell(Text(v['compania']?.toString() ?? '')),

                              DataCell(Text("${v['prima_anual'] ?? 0}€")),

                              DataCell(Text("${v['comision'] ?? 0}€")),

                              DataCell(
                                InkWell(
                                  onTap: () {
                                    mostrarDetallePoliza(v);
                                  },
                                  child: Text(
                                    v['numero_poliza']?.toString() ?? '',
                                    style: const TextStyle(
                                      color: Colors.blue,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                Align(
                  alignment: Alignment.centerRight,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text("Cerrar"),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _detalleKpi(String titulo, String valor) {
    return Container(
      width: 180,
      padding: const EdgeInsets.all(15),

      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(12),
      ),

      child: Column(
        children: [
          Text(
            valor,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),

          const SizedBox(height: 5),

          Text(titulo),
        ],
      ),
    );
  }

  Widget _detalleKpiColor(
    String titulo,
    String valor,
    Color fondo,
    Color texto,
  ) {
    return Container(
      width: 170,
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: fondo,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: texto.withOpacity(0.25)),
      ),
      child: Column(
        children: [
          Text(
            valor,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 21,
              fontWeight: FontWeight.bold,
              color: texto,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            titulo,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 13,
              color: texto,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _filaDetalle(String titulo, dynamic valor) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          SizedBox(
            width: 220,
            child: Text(
              titulo,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),

          Expanded(child: Text(valor?.toString() ?? '')),
        ],
      ),
    );
  }

  Future<void> editarCliente(Map<String, dynamic> cliente) async {
    final nombreController = TextEditingController(
      text: cliente['nombre'] ?? '',
    );

    final apellidosController = TextEditingController(
      text: cliente['apellidos'] ?? '',
    );

    final emailController = TextEditingController(text: cliente['email'] ?? '');

    final telefonoController = TextEditingController(
      text: cliente['telefono'] ?? '',
    );

    final direccionController = TextEditingController(
      text: cliente['direccion'] ?? '',
    );

    final numeroController = TextEditingController(
      text: cliente['numero']?.toString() ?? '',
    );

    final cpController = TextEditingController(
      text: cliente['codigo_postal'] ?? '',
    );

    final provinciaController = TextEditingController(
      text: cliente['provincia'] ?? '',
    );

    final poblacionController = TextEditingController(
      text: cliente['poblacion'] ?? '',
    );

    _showPanelDialog(
      context: context,
      builder: (_) {
        return Dialog(
          child: Container(
            width: 800,
            padding: const EdgeInsets.all(25),

            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,

                children: [
                  const Text(
                    "Editar cliente",
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),

                  const SizedBox(height: 25),

                  TextField(
                    controller: nombreController,
                    decoration: const InputDecoration(labelText: "Nombre"),
                  ),

                  const SizedBox(height: 15),

                  TextField(
                    controller: apellidosController,
                    decoration: const InputDecoration(labelText: "Apellidos"),
                  ),

                  const SizedBox(height: 15),

                  TextField(
                    controller: emailController,
                    decoration: const InputDecoration(labelText: "Email"),
                  ),

                  const SizedBox(height: 15),

                  TextField(
                    controller: telefonoController,
                    decoration: const InputDecoration(labelText: "Teléfono"),
                  ),

                  const SizedBox(height: 15),

                  TextField(
                    controller: direccionController,
                    decoration: const InputDecoration(labelText: "Dirección"),
                  ),

                  const SizedBox(height: 15),

                  TextField(
                    controller: numeroController,
                    decoration: const InputDecoration(labelText: "Número"),
                  ),

                  const SizedBox(height: 15),

                  TextField(
                    controller: cpController,
                    decoration: const InputDecoration(
                      labelText: "Código Postal",
                    ),
                  ),

                  const SizedBox(height: 15),

                  TextField(
                    controller: provinciaController,
                    decoration: const InputDecoration(labelText: "Provincia"),
                  ),

                  const SizedBox(height: 15),

                  TextField(
                    controller: poblacionController,
                    decoration: const InputDecoration(labelText: "Población"),
                  ),

                  const SizedBox(height: 30),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: const Text("Cancelar"),
                      ),

                      const SizedBox(width: 10),

                      ElevatedButton(
                        onPressed: () async {
                          await Supabase.instance.client
                              .from('clientes')
                              .update({
                                'nombre': nombreController.text,

                                'apellidos': apellidosController.text,

                                'email': emailController.text,

                                'telefono': telefonoController.text,

                                'direccion': direccionController.text,

                                'numero': numeroController.text,

                                'codigo_postal': cpController.text,

                                'provincia': provinciaController.text,

                                'poblacion': poblacionController.text,
                              })
                              .eq('id', cliente['id']);

                          Navigator.pop(context);

                          setState(() {});

                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text(
                                "Cliente actualizado correctamente",
                              ),
                            ),
                          );
                        },
                        child: const Text("Guardar"),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> verPolizasCliente(Map<String, dynamic> cliente) async {
    final ventas = await Supabase.instance.client
        .from('ventas')
        .select()
        .eq('cliente_id', cliente['id']);

    if (!mounted) return;

    _showPanelDialog(
      context: context,
      builder: (_) {
        return Dialog(
          child: Container(
            width: 1200,
            height: 700,
            padding: const EdgeInsets.all(25),

            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                Text(
                  "Pólizas de ${cliente['nombre']} ${cliente['apellidos']}",
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 20),

                Expanded(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,

                    child: ProgressiveRecords(
                      count: ventas.length,
                      resetKey: progressiveRecordKey(ventas),
                      showFooter: true,
                      builder: (context, _visibleRows) => DataTable(
                        columns: const [
                          DataColumn(label: Text("Póliza")),

                          DataColumn(label: Text("Producto")),

                          DataColumn(label: Text("Compañía")),

                          DataColumn(label: Text("Prima")),

                          DataColumn(label: Text("Comisión")),

                          DataColumn(label: Text("Asegurados")),

                          DataColumn(label: Text("Fecha efecto")),
                        ],

                        rows: ventas.take(_visibleRows).map((v) {
                          return DataRow(
                            cells: [
                              DataCell(
                                Text(v['numero_poliza']?.toString() ?? ''),
                              ),

                              DataCell(Text(v['producto']?.toString() ?? '')),

                              DataCell(Text(v['compania']?.toString() ?? '')),

                              DataCell(Text("${v['prima_anual'] ?? 0}€")),

                              DataCell(Text("${v['comision'] ?? 0}€")),

                              DataCell(Text("${v['numero_asegurados'] ?? 0}")),

                              DataCell(
                                Text(v['fecha_efecto']?.toString() ?? ''),
                              ),
                            ],
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                Align(
                  alignment: Alignment.centerRight,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text("Cerrar"),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> mostrarDetallePoliza(Map<String, dynamic> venta) async {
    final agente = await Supabase.instance.client
        .from('usuarios')
        .select()
        .eq('auth_id', venta['agente_auth_id'])
        .maybeSingle();

    Map<String, dynamic>? jefe;

    if (agente != null && agente['parent_id'] != null) {
      jefe = await Supabase.instance.client
          .from('usuarios')
          .select()
          .eq('id', agente['parent_id'])
          .maybeSingle();
    }
    final recibos = await Supabase.instance.client
        .from('recibos')
        .select()
        .eq('numero_poliza', venta['numero_poliza']);
    final cobrados = recibos.where((r) => r['estado'] == 'COBRADO').length;

    final devueltos = recibos.where((r) => r['estado'] == 'DEVUELTO').length;

    final pendientes = recibos.where((r) => r['estado'] == 'PENDIENTE').length;

    _showPanelDialog(
      context: context,
      builder: (_) {
        return Dialog(
          child: Container(
            width: 1000,
            padding: const EdgeInsets.all(25),

            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,

                children: [
                  Text(
                    "Póliza ${venta['numero_poliza']}",
                    style: const TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 25),

                  Wrap(
                    spacing: 25,
                    runSpacing: 20,
                    children: [
                      _detalleKpi(
                        "Agente",
                        agente == null
                            ? "-"
                            : "${agente['nombre']} ${agente['apellidos']}",
                      ),

                      _detalleKpi(
                        "Jefe Equipo",
                        jefe == null
                            ? "-"
                            : "${jefe['nombre']} ${jefe['apellidos']}",
                      ),

                      _detalleKpi("Compañía", venta['compania'] ?? "-"),

                      _detalleKpi("Prima", "${venta['prima_anual'] ?? 0}€"),

                      _detalleKpi("Comisión", "${venta['comision'] ?? 0}€"),

                      _detalleKpi(
                        "Asegurados",
                        "${venta['numero_asegurados'] ?? 0}",
                      ),
                    ],
                  ),
                  const SizedBox(height: 25),

                  Wrap(
                    spacing: 25,
                    runSpacing: 20,
                    children: [
                      _detalleKpi("Cobrados", "$cobrados"),

                      _detalleKpi("Devueltos", "$devueltos"),

                      _detalleKpi("Pendientes", "$pendientes"),
                    ],
                  ),

                  const SizedBox(height: 30),

                  const SizedBox(height: 30),

                  _filaDetalle("Producto", venta['producto']),

                  _filaDetalle("Compañía", venta['compania']),

                  _filaDetalle("Forma pago", venta['forma_pago']),

                  _filaDetalle("Fecha efecto", venta['fecha_efecto']),

                  _filaDetalle("Precio", venta['precio']),

                  _filaDetalle("Prima anual", venta['prima_anual']),

                  _filaDetalle("Prima bruta", venta['prima_anual_bruta']),

                  _filaDetalle("Prima neta", venta['prima_anual_neta']),

                  _filaDetalle("Comisión", venta['comision']),

                  _filaDetalle("Categoría", venta['categoria_producto']),

                  const SizedBox(height: 30),

                  const SizedBox(height: 40),

                  const Text(
                    "Historial de recibos",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),

                  const SizedBox(height: 15),

                  SizedBox(
                    height: 250,
                    child: SingleChildScrollView(
                      child: ProgressiveRecords(
                        count: recibos.length,
                        resetKey: progressiveRecordKey(recibos),
                        showFooter: true,
                        builder: (context, _visibleRows) => DataTable(
                          columns: const [
                            DataColumn(label: Text("Estado")),

                            DataColumn(label: Text("Importe")),

                            DataColumn(label: Text("Fecha")),
                          ],

                          rows: recibos.take(_visibleRows).map<DataRow>((r) {
                            return DataRow(
                              cells: [
                                DataCell(
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      color: r['estado'] == 'COBRADO'
                                          ? Colors.green.shade100
                                          : r['estado'] == 'DEVUELTO'
                                          ? Colors.red.shade100
                                          : Colors.orange.shade100,
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: Text(
                                      r['estado'] ?? '',
                                      style: TextStyle(
                                        color: r['estado'] == 'COBRADO'
                                            ? Colors.green
                                            : r['estado'] == 'DEVUELTO'
                                            ? Colors.red
                                            : Colors.orange,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),

                                DataCell(Text(r['importe']?.toString() ?? '')),

                                DataCell(Text(r['fecha']?.toString() ?? '')),
                              ],
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                  ),

                  Align(
                    alignment: Alignment.centerRight,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: const Text("Cerrar"),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> mostrarRecibosCliente(Map<String, dynamic> cliente) async {
    final ventas = await Supabase.instance.client
        .from('ventas')
        .select()
        .eq('cliente_id', cliente['id']);

    final numerosPoliza = ventas.map((v) => v['numero_poliza']).toList();

    List<Map<String, dynamic>> recibos = [];

    if (numerosPoliza.isNotEmpty) {
      final response = await Supabase.instance.client
          .from('recibos')
          .select()
          .inFilter('numero_poliza', numerosPoliza);

      recibos = List<Map<String, dynamic>>.from(response);
    }

    _showPanelDialog(
      context: context,
      builder: (_) {
        return Dialog(
          child: Container(
            width: 1200,
            height: 700,
            padding: const EdgeInsets.all(20),

            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Recibos de ${cliente['nombre']} ${cliente['apellidos']}",
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 20),

                Expanded(
                  child: SingleChildScrollView(
                    child: ProgressiveRecords(
                      count: recibos.length,
                      resetKey: progressiveRecordKey(recibos),
                      showFooter: true,
                      builder: (context, _visibleRows) => DataTable(
                        columns: const [
                          DataColumn(label: Text("Póliza")),

                          DataColumn(label: Text("Estado")),

                          DataColumn(label: Text("Importe")),

                          DataColumn(label: Text("Fecha")),
                        ],

                        rows: recibos.take(_visibleRows).map((r) {
                          return DataRow(
                            cells: [
                              DataCell(
                                Text(r['numero_poliza']?.toString() ?? ''),
                              ),

                              DataCell(Text(r['estado']?.toString() ?? '')),

                              DataCell(Text(r['importe']?.toString() ?? '')),

                              DataCell(Text(r['fecha']?.toString() ?? '')),
                            ],
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void registrarGestionCliente(Map<String, dynamic> cliente) {
    print(cliente);
  }

  void anularCliente(Map<String, dynamic> cliente) {
    print(cliente);
  }

  Future<List<Map<String, dynamic>>> getClientes() async {
    try {
      final supabase = Supabase.instance.client;

      dynamic clientesQuery = supabase.from('clientes').select();

      if (!veTodoERP) {
        if (authIdsPermitidosERP.isEmpty) return [];

        clientesQuery = clientesQuery.inFilter('auth_id', authIdsPermitidosERP);
      }

      final clientesResponse = await clientesQuery;

      final usuariosResponse = await supabase
          .from('usuarios')
          .select('id, auth_id, parent_id, nombre, apellidos');

      dynamic ventasQuery = supabase
          .from('ventas')
          .select('cliente_id, agente_auth_id, compania');

      if (!veTodoERP) {
        ventasQuery = ventasQuery.inFilter(
          'agente_auth_id',
          authIdsPermitidosERP,
        );
      }

      final ventasResponse = await ventasQuery;

      final clientes = List<Map<String, dynamic>>.from(clientesResponse);
      final usuarios = List<Map<String, dynamic>>.from(usuariosResponse);
      final ventas = List<Map<String, dynamic>>.from(ventasResponse);

      for (final cliente in clientes) {
        final ventaCliente = ventas.firstWhere(
          (v) => v['cliente_id']?.toString() == cliente['id']?.toString(),
          orElse: () => <String, dynamic>{},
        );

        if (ventaCliente.isNotEmpty) {
          cliente['compania'] = ventaCliente['compania'];

          final authId = ventaCliente['agente_auth_id']?.toString();

          final agente = usuarios.firstWhere(
            (u) => u['auth_id']?.toString() == authId,
            orElse: () => <String, dynamic>{},
          );

          if (agente.isNotEmpty) {
            cliente['agente_nombre'] =
                "${agente['nombre'] ?? ''} ${agente['apellidos'] ?? ''}".trim();

            final jefe = usuarios.firstWhere(
              (u) => u['id']?.toString() == agente['parent_id']?.toString(),
              orElse: () => <String, dynamic>{},
            );

            cliente['jefe_nombre'] = jefe.isEmpty
                ? ''
                : "${jefe['nombre'] ?? ''} ${jefe['apellidos'] ?? ''}".trim();
          }
        }
      }

      clientes.sort((a, b) {
        final fa =
            DateTime.tryParse(a['created_at']?.toString() ?? '') ??
            DateTime(1900);
        final fb =
            DateTime.tryParse(b['created_at']?.toString() ?? '') ??
            DateTime(1900);
        return fb.compareTo(fa);
      });

      List<String> values(String key) => clientes.map((c) => c[key]?.toString() ?? '')
          .where((v) => v.isNotEmpty).toSet().toList()..sort();
      listaCompanias = values('compania');
      listaAgentes = values('agente_nombre');
      listaJefes = values('jefe_nombre');
      print("CLIENTES CARGADOS ERP: ${clientes.length}");
      return clientes;
    } catch (e) {
      print("❌ ERROR getClientes: $e");
      return [];
    }
  }

  Future<void> exportClientes(List<Map<String, dynamic>> clientes) async {
    final excelFile = excel.Excel.createExcel();
    final sheet = excelFile['Clientes'];

    sheet.appendRow([
      excel.TextCellValue('Nombre'),
      excel.TextCellValue('Apellidos'),
      excel.TextCellValue('Email'),
      excel.TextCellValue('Teléfono'),
      excel.TextCellValue('CP'),
      excel.TextCellValue('Provincia'),
      excel.TextCellValue('Población'),
      excel.TextCellValue('Dirección'),
      excel.TextCellValue('Número'),
    ]);

    for (final c in clientes) {
      sheet.appendRow([
        excel.TextCellValue(c['nombre']?.toString() ?? ''),
        excel.TextCellValue(c['apellidos']?.toString() ?? ''),
        excel.TextCellValue(c['email']?.toString() ?? ''),
        excel.TextCellValue(c['telefono']?.toString() ?? ''),
        excel.TextCellValue(c['codigo_postal']?.toString() ?? ''),
        excel.TextCellValue(c['provincia']?.toString() ?? ''),
        excel.TextCellValue(c['poblacion']?.toString() ?? ''),
        excel.TextCellValue(c['direccion']?.toString() ?? ''),
        excel.TextCellValue(c['numero']?.toString() ?? ''),
      ]);
    }

    final bytes = excelFile.encode();

    if (bytes == null) return;

    final dir = await getApplicationDocumentsDirectory();

    final file = File('${dir.path}/clientes.xlsx');

    await file.writeAsBytes(bytes, flush: true);

    await OpenFilex.open(file.path);
  }

  Future<void> exportVentas(List<Map<String, dynamic>> ventas) async {
    if (ventas.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No hay ventas con los filtros seleccionados.')),
      );
      return;
    }
    try {
      // Es la misma lista filtrada que alimenta la tabla y sus indicadores.
      final bytes = SalesExcelExport.encode(ventas);
      final dir = await getApplicationDocumentsDirectory();
      final file = File('${dir.path}/ventas_${DateTime.now().microsecondsSinceEpoch}.xlsx');
      await file.writeAsBytes(bytes, flush: true);
      final result = await OpenFilex.open(file.path);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(
        result.type == ResultType.done
            ? 'Excel generado con ${ventas.length} ventas.'
            : 'Excel guardado en ${file.path}. No se pudo abrir automáticamente.',
      )));
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('No se pudo exportar el Excel: $error')),
      );
    }
  }

  Widget buildVentasPage() {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _panelRequests.get('ventas', getVentas),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final ventas = filtrarVentas(snapshot.data!);

        final totalVentas = ventas.length;
        final anuladas = ventas
            .where(
              (v) =>
                  (v['estado_poliza']?.toString().toUpperCase() ?? '') ==
                  'ANULADA',
            )
            .length;

        final activas = totalVentas - anuladas;

        final primaTotal = ventas.fold<double>(0, (suma, v) {
          return suma + PremiumWeighting.amount(v, v['prima_anual']);
        });

        final comisionTotal = ventas.fold<double>(0, (suma, v) {
          return suma +
              (double.tryParse(
                    v['comision']?.toString() ??
                        v['comison']?.toString() ??
                        '0',
                  ) ??
                  0);
        });

        return SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // CABECERA ERP
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: Colors.grey.shade300),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.04),
                      blurRadius: 18,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        color: Colors.blue.shade50,
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Icon(
                        Icons.analytics_outlined,
                        color: Colors.blue.shade700,
                        size: 36,
                      ),
                    ),
                    const SizedBox(width: 16),

                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Ventas",
                            style: TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 5),
                          Text(
                            "Panel profesional de control, seguimiento y gestión de pólizas",
                            style: TextStyle(color: Colors.grey),
                          ),
                        ],
                      ),
                    ),

                    ElevatedButton.icon(
                      onPressed: () async {
                        await exportVentas(ventas);
                      },
                      icon: const Icon(Icons.file_download_outlined),
                      label: const Text("Exportar Excel"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green.shade700,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 18,
                          vertical: 15,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 18),

              // TARJETAS KPI
              Wrap(
                spacing: 14,
                runSpacing: 14,
                children: [
                  _kpiVentaERP(
                    titulo: "Total pólizas",
                    valor: totalVentas.toString(),
                    icono: Icons.description_outlined,
                    color: Colors.blue,
                  ),
                  _kpiVentaERP(
                    titulo: "Activas",
                    valor: activas.toString(),
                    icono: Icons.check_circle_outline,
                    color: Colors.green,
                  ),
                  _kpiVentaERP(
                    titulo: "Anuladas",
                    valor: anuladas.toString(),
                    icono: Icons.cancel_outlined,
                    color: Colors.red,
                  ),
                  _kpiVentaERP(
                    titulo: "Prima anual",
                    valor: _formatoEuro(primaTotal),
                    icono: Icons.euro_outlined,
                    color: Colors.indigo,
                  ),
                  _kpiVentaERP(
                    titulo: "Comisión",
                    valor: _formatoEuro(comisionTotal),
                    icono: Icons.payments_outlined,
                    color: Colors.orange,
                  ),
                ],
              ),

              const SizedBox(height: 18),

              // FILTROS ERP
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.filter_alt_outlined),
                        SizedBox(width: 8),
                        Text(
                          "Filtros de búsqueda",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 16),

                    Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      children: [
                        _dropdownFiltroVentaERP(
                          label: "Compañía",
                          value: filtroVentaCompania,
                          items: listaVentaCompanias,
                          onChanged: (value) {
                            setState(() {
                              filtroVentaCompania = value;
                            });
                          },
                        ),

                        _dropdownFiltroVentaERP(
                          label: "Agente",
                          value: filtroVentaAgente,
                          items: listaVentaAgentes,
                          onChanged: (value) {
                            setState(() {
                              filtroVentaAgente = value;
                            });
                          },
                        ),

                        _dropdownFiltroVentaERP(
                          label: "Jefe equipo",
                          value: filtroVentaJefe,
                          items: listaVentaJefes,
                          onChanged: (value) {
                            setState(() {
                              filtroVentaJefe = value;
                            });
                          },
                        ),

                        _dropdownFiltroVentaERP(
                          label: "Categoría",
                          value: filtroVentaCategoria,
                          items: listaVentaCategorias,
                          onChanged: (value) {
                            setState(() {
                              filtroVentaCategoria = value;
                            });
                          },
                        ),

                        _botonFechaVentaERP(
                          texto: ventaFechaDesde == null
                              ? "Fecha desde"
                              : ventaFechaDesde.toString().split(" ")[0],
                          icono: Icons.calendar_month_outlined,
                          onPressed: () async {
                            final fecha = await showDatePicker(
                              context: context,
                              firstDate: DateTime(2020),
                              lastDate: DateTime(2035),
                              initialDate: DateTime.now(),
                            );

                            if (fecha != null) {
                              setState(() {
                                ventaFechaDesde = fecha;
                              });
                            }
                          },
                        ),

                        _botonFechaVentaERP(
                          texto: ventaFechaHasta == null
                              ? "Fecha hasta"
                              : ventaFechaHasta.toString().split(" ")[0],
                          icono: Icons.event_available_outlined,
                          onPressed: () async {
                            final fecha = await showDatePicker(
                              context: context,
                              firstDate: DateTime(2020),
                              lastDate: DateTime(2035),
                              initialDate: DateTime.now(),
                            );

                            if (fecha != null) {
                              setState(() {
                                ventaFechaHasta = fecha;
                              });
                            }
                          },
                        ),

                        ElevatedButton.icon(
                          onPressed: () {
                            setState(() {
                              filtroVentaCompania = null;
                              filtroVentaCategoria = null;
                              ventaFechaDesde = null;
                              ventaFechaHasta = null;
                              filtroVentaAgente = null;
                              filtroVentaJefe = null;
                            });
                          },
                          icon: const Icon(Icons.clear),
                          label: const Text("Limpiar filtros"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.grey.shade800,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 16,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 18),

              // TABLA PROFESIONAL
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: Colors.grey.shade300),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.03),
                      blurRadius: 14,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          "Listado de pólizas",
                          style: TextStyle(
                            fontSize: 19,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          "$totalVentas registros encontrados",
                          style: TextStyle(
                            color: Colors.grey.shade600,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 14),

                    SizedBox(
                      height: 620,
                      child: SingleChildScrollView(
                        scrollDirection: Axis.vertical,
                        child: TablaConScrollHorizontalERP(
                          child: ProgressiveRecords(
                            count: ventas.length,
                            resetKey: progressiveRecordKey(ventas),
                            showFooter: true,
                            builder: (context, _visibleRows) => DataTable(
                              headingRowColor: WidgetStateProperty.all(
                                Colors.grey.shade100,
                              ),
                              dataRowMinHeight: 62,
                              dataRowMaxHeight: 76,
                              columnSpacing: 28,
                              border: TableBorder(
                                horizontalInside: BorderSide(
                                  color: Colors.grey.shade200,
                                ),
                              ),
                              columns: const [
                                DataColumn(label: Text("Estado")),
                                DataColumn(label: Text("Póliza")),
                                DataColumn(label: Text("Producto")),
                                DataColumn(label: Text("Compañía")),
                                DataColumn(label: Text("Forma pago")),
                                DataColumn(label: Text("Precio")),
                                DataColumn(label: Text("Prima anual")),
                                DataColumn(label: Text("Comisión")),
                                DataColumn(label: Text("Fecha efecto")),
                                DataColumn(label: Text("Agente")),
                                DataColumn(label: Text("Acciones")),
                              ],

                              rows: ventas.take(_visibleRows).map((v) {
                                final estado =
                                    v['estado_poliza']?.toString() ?? 'ACTIVA';

                                return DataRow(
                                  color:
                                      WidgetStateProperty.resolveWith<Color?>((
                                        states,
                                      ) {
                                        if (estado.toUpperCase() == 'ANULADA') {
                                          return Colors.red.shade50;
                                        }
                                        return null;
                                      }),
                                  cells: [
                                    DataCell(_chipEstadoPolizaERP(estado)),

                                    DataCell(
                                      Text(
                                        v['numero_poliza']
                                                    ?.toString()
                                                    .isEmpty ??
                                                true
                                            ? 'Sin póliza'
                                            : v['numero_poliza'].toString(),
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),

                                    DataCell(_textoTablaVenta(v['producto'])),
                                    DataCell(
                                      _textoTablaVenta(
                                        v['compañia'] ?? v['compania'],
                                      ),
                                    ),
                                    DataCell(_textoTablaVenta(v['forma_pago'])),

                                    DataCell(
                                      Text(
                                        _formatoEuroDesdeDynamic(v['precio']),
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),

                                    DataCell(
                                      Text(
                                        _formatoEuroDesdeDynamic(
                                          v['prima_anual'],
                                        ),
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),

                                    DataCell(
                                      Text(
                                        _formatoEuroDesdeDynamic(
                                          v['comision'] ?? v['comison'],
                                        ),
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),

                                    DataCell(
                                      _textoTablaVenta(v['fecha_efecto']),
                                    ),
                                    DataCell(
                                      _textoTablaVenta(v['agente_nombre']),
                                    ),

                                    DataCell(
                                      PopupMenuButton<String>(
                                        icon: const Icon(Icons.more_vert),
                                        tooltip: "Acciones de póliza",
                                        onSelected: (value) async {
                                          print(
                                            "ACCION VENTAS PULSADA: $value",
                                          );
                                          print(
                                            "POLIZA: ${v['numero_poliza']}",
                                          );
                                          print("VENTA COMPLETA:");
                                          print(v);

                                          if (value == 'detalle') {
                                            await mostrarDetalleVentaERP(v);
                                          }

                                          if (value == 'editar') {
                                            await editarPolizaDialog(v);
                                          }

                                          if (value == 'recibos') {
                                            await consultarRecibosDialog(v);
                                          }

                                          if (value == 'gestionar') {
                                            await gestionarPolizaDialog(v);
                                          }

                                          if (value == 'anular') {
                                            await anularPolizaDialog(v);
                                          }
                                        },
                                        itemBuilder: (context) => [
                                          const PopupMenuItem(
                                            value: 'detalle',
                                            child: ListTile(
                                              leading: Icon(
                                                Icons.visibility_outlined,
                                              ),
                                              title: Text('Ver detalle'),
                                            ),
                                          ),
                                          const PopupMenuItem(
                                            value: 'editar',
                                            child: ListTile(
                                              leading: Icon(
                                                Icons.edit_outlined,
                                              ),
                                              title: Text('Editar póliza'),
                                            ),
                                          ),
                                          const PopupMenuItem(
                                            value: 'recibos',
                                            child: ListTile(
                                              leading: Icon(
                                                Icons.receipt_long_outlined,
                                              ),
                                              title: Text('Consultar recibos'),
                                            ),
                                          ),
                                          const PopupMenuItem(
                                            value: 'gestionar',
                                            child: ListTile(
                                              leading: Icon(
                                                Icons.manage_accounts_outlined,
                                              ),
                                              title: Text('Gestionar'),
                                            ),
                                          ),
                                          PopupMenuItem(
                                            value: 'anular',
                                            enabled:
                                                estado.toUpperCase() !=
                                                'ANULADA',
                                            child: const ListTile(
                                              leading: Icon(
                                                Icons.cancel_outlined,
                                                color: Colors.red,
                                              ),
                                              title: Text(
                                                'Anular póliza',
                                                style: TextStyle(
                                                  color: Colors.red,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                );
                              }).toList(),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _kpiVentaERP({
    required String titulo,
    required String valor,
    required IconData icono,
    required MaterialColor color,
  }) {
    return Container(
      width: 210,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.grey.shade300),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 12,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(11),
            decoration: BoxDecoration(
              color: color.shade50,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icono, color: color.shade700, size: 28),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  titulo,
                  style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
                ),
                const SizedBox(height: 4),
                Text(
                  valor,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _dropdownFiltroVentaERP({
    required String label,
    required String? value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    final opciones =
        items.map((e) => e.trim()).where((e) => e.isNotEmpty).toSet().toList()
          ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));

    final valorActual = value != null && opciones.contains(value)
        ? value
        : null;

    return SizedBox(
      width: 210,
      child: DropdownButtonFormField<String>(
        key: ValueKey('$label-${opciones.length}-$valorActual'),
        value: valorActual,
        isExpanded: true,
        menuMaxHeight: 420,
        icon: const Icon(Icons.keyboard_arrow_down_rounded),
        decoration: InputDecoration(
          labelText: label,
          hintText: opciones.isEmpty ? 'Sin opciones' : 'Todos',
          filled: true,
          fillColor: Colors.grey.shade50,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 15,
          ),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: Colors.blue.shade600, width: 2),
          ),
        ),
        items: [
          const DropdownMenuItem<String>(
            value: '__TODOS__',
            child: Text('Todos', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
          ...opciones.map(
            (item) => DropdownMenuItem<String>(
              value: item,
              child: Text(item, maxLines: 1, overflow: TextOverflow.ellipsis),
            ),
          ),
        ],
        onChanged: opciones.isEmpty
            ? null
            : (nuevoValor) {
                if (nuevoValor == '__TODOS__') {
                  onChanged(null);
                } else {
                  onChanged(nuevoValor);
                }
              },
      ),
    );
  }

  Widget _botonFechaVentaERP({
    required String texto,
    required IconData icono,
    required VoidCallback onPressed,
  }) {
    return OutlinedButton.icon(
      onPressed: onPressed,
      icon: Icon(icono),
      label: Text(texto),
      style: OutlinedButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 17),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }

  Widget _chipEstadoPolizaERP(String estado) {
    final estadoUpper = estado.toUpperCase();

    Color color = Colors.green;
    IconData icono = Icons.check_circle_outline;
    String texto = estadoUpper.isEmpty ? "ACTIVA" : estadoUpper;

    if (estadoUpper == 'ANULADA') {
      color = Colors.red;
      icono = Icons.cancel_outlined;
      texto = "ANULADA";
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: color.withOpacity(0.10),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icono, size: 16, color: color),
          const SizedBox(width: 6),
          Text(
            texto,
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _textoTablaVenta(dynamic valor) {
    final texto = valor?.toString() ?? '';

    return Text(
      texto.isEmpty ? '—' : texto,
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
    );
  }

  String _formatoEuroDesdeDynamic(dynamic valor) {
    final numero = double.tryParse(
      valor?.toString().replaceAll(',', '.') ?? '',
    );

    if (numero == null) {
      return '—';
    }

    return '${numero.toStringAsFixed(2)} €';
  }

  String _formatoEuro(double valor) {
    return '${valor.toStringAsFixed(2)} €';
  }

  Future<void> cargarCompanias() async {
    final response = await Supabase.instance.client
        .from('ventas')
        .select('compania');

    final companias = response
        .map((e) => e['compania']?.toString() ?? '')
        .where((e) => e.isNotEmpty)
        .toSet()
        .toList();

    setState(() {
      listaCompanias = companias;
    });
  }

  Future<void> cargarJefesFiltro() async {
    final response = await Supabase.instance.client.from('usuarios').select();

    final jefes = response
        .where((u) => u['rol_usuario'] == 'JEFE_EQUIPO')
        .map((u) => "${u['nombre']} ${u['apellidos']}")
        .toList();

    if (!mounted) return;
    setState(() {
      listaJefes = jefes;
    });
  }

  Future<void> cargarAgentesFiltro() async {
    final ventas = await Supabase.instance.client
        .from('ventas')
        .select('compania');

    final companias = ventas
        .map((e) => e['compania']?.toString() ?? '')
        .where((e) => e.isNotEmpty)
        .toSet()
        .toList();

    setState(() {
      listaCompanias = companias;
    });

    print("COMPANIAS CARGADAS: ${listaCompanias.length}");
  }

  List<Map<String, dynamic>> filtrarClientes(
    List<Map<String, dynamic>> clientes,
  ) {
    return clientes.where((c) {
      if (filtroAgente != null && filtroAgente!.isNotEmpty) {
        if ((c['agente_nombre'] ?? '') != filtroAgente) return false;
      }

      if (filtroJefeEquipo != null && filtroJefeEquipo!.isNotEmpty) {
        if ((c['jefe_nombre'] ?? '') != filtroJefeEquipo) return false;
      }

      if (filtroCompania != null && filtroCompania!.isNotEmpty) {
        if ((c['compania'] ?? '') != filtroCompania) return false;
      }

      if (fechaDesde != null) {
        final fecha = DateTime.tryParse(c['created_at']?.toString() ?? '');
        if (fecha != null && fecha.isBefore(fechaDesde!)) return false;
      }

      if (fechaHasta != null) {
        final finDia = DateTime(
          fechaHasta!.year,
          fechaHasta!.month,
          fechaHasta!.day,
          23,
          59,
          59,
        );

        final fecha = DateTime.tryParse(c['created_at']?.toString() ?? '');
        if (fecha != null && fecha.isAfter(finDia)) return false;
      }

      return true;
    }).toList();
  }

  Future<void> cargarFiltrosClientes() async {
    final supabase = Supabase.instance.client;

    dynamic ventasQuery = supabase
        .from('ventas')
        .select('compania, agente_auth_id');

    if (!veTodoERP) {
      if (authIdsPermitidosERP.isEmpty) return;

      ventasQuery = ventasQuery.inFilter(
        'agente_auth_id',
        authIdsPermitidosERP,
      );
    }

    final ventas = List<Map<String, dynamic>>.from(await ventasQuery);

    dynamic usuariosQuery = supabase
        .from('usuarios')
        .select('id, auth_id, nombre, apellidos, parent_id');

    if (!veTodoERP) {
      usuariosQuery = usuariosQuery.inFilter('auth_id', authIdsPermitidosERP);
    }

    final usuarios = List<Map<String, dynamic>>.from(await usuariosQuery);

    final companias = ventas
        .map((e) => e['compania']?.toString() ?? '')
        .where((e) => e.isNotEmpty)
        .toSet()
        .toList();

    final agentes = <String>{};
    final jefes = <String>{};

    for (final venta in ventas) {
      final authId = venta['agente_auth_id']?.toString();

      final agente = usuarios.firstWhere(
        (u) => u['auth_id']?.toString() == authId,
        orElse: () => <String, dynamic>{},
      );

      if (agente.isNotEmpty) {
        agentes.add(
          "${agente['nombre'] ?? ''} ${agente['apellidos'] ?? ''}".trim(),
        );

        final jefe = usuarios.firstWhere(
          (u) => u['id']?.toString() == agente['parent_id']?.toString(),
          orElse: () => <String, dynamic>{},
        );

        if (jefe.isNotEmpty) {
          jefes.add(
            "${jefe['nombre'] ?? ''} ${jefe['apellidos'] ?? ''}".trim(),
          );
        }
      }
    }

    if (!mounted) return;
    setState(() {
      listaCompanias = companias;
      listaAgentes = agentes.toList();
      listaJefes = jefes.toList();
    });
  }

  void _setSalesFilters(List<Map<String, dynamic>> ventas) {
    List<String> values(String key) => ventas.map((v) => v[key]?.toString().trim() ?? '')
        .where((v) => v.isNotEmpty).toSet().toList()..sort();
    listaVentaCompanias = values('compania');
    listaVentaCategorias = values('categoria_producto');
    listaVentaAgentes = values('agente_nombre');
    listaVentaJefes = values('jefe_nombre');
  }

  Future<void> cargarFiltrosVentas() async {
    _panelRequests.clear();
    await _panelRequests.get('ventas', getVentas);
  }

  Future<List<Map<String, dynamic>>> getVentas() async {
    try {
      final supabase = Supabase.instance.client;

      if (!veTodoERP && authIdsPermitidosERP.isEmpty) return [];
      final ventasResponse = await PolicySalesQuery.load(
        supabase,
        authIds: veTodoERP ? null : authIdsPermitidosERP,
      );

      dynamic usuariosQuery = supabase
          .from('usuarios')
          .select('id, auth_id, parent_id, nombre, apellidos, rol_usuario');

      final usuariosResponse = await usuariosQuery;

      final usuarios = List<Map<String, dynamic>>.from(usuariosResponse);
      final ventas = List<Map<String, dynamic>>.from(ventasResponse);

      final byAuth = {for (final u in usuarios) u['auth_id']?.toString(): u};
      final byId = {for (final u in usuarios) u['id']?.toString(): u};
      for (final venta in ventas) {
        final authId = venta['agente_auth_id']?.toString();

        final agente = byAuth[authId] ?? <String, dynamic>{};

        if (agente.isNotEmpty) {
          venta['agente_nombre'] =
              "${agente['nombre'] ?? ''} ${agente['apellidos'] ?? ''}".trim();

          final jefe = byId[agente['parent_id']?.toString()] ?? <String, dynamic>{};

          venta['jefe_nombre'] = jefe.isEmpty
              ? ''
              : "${jefe['nombre'] ?? ''} ${jefe['apellidos'] ?? ''}".trim();
        }
      }

      ventas.sort((a, b) {
        final fa =
            DateTime.tryParse(a['fecha_efecto']?.toString() ?? '') ??
            DateTime(1900);

        final fb =
            DateTime.tryParse(b['fecha_efecto']?.toString() ?? '') ??
            DateTime(1900);

        return fb.compareTo(fa);
      });

      _setSalesFilters(ventas);
      print("VENTAS CARGADAS ERP: ${ventas.length}");
      return ventas;
    } catch (e) {
      print("❌ ERROR getVentas: $e");
      return [];
    }
  }

  List<Map<String, dynamic>> filtrarVentas(List<Map<String, dynamic>> ventas) {
    return SalesExcelExport.filter(
      ventas,
      company: filtroVentaCompania,
      category: filtroVentaCategoria,
      agent: filtroVentaAgente,
      manager: filtroVentaJefe,
      from: ventaFechaDesde,
      until: ventaFechaHasta,
    );
  }

  Future<void> mostrarDetalleVentaERP(Map<String, dynamic> venta) async {
    final agente = await Supabase.instance.client
        .from('usuarios')
        .select()
        .eq('auth_id', venta['agente_auth_id'])
        .maybeSingle();

    Map<String, dynamic>? jefe;

    if (agente != null && agente['parent_id'] != null) {
      jefe = await Supabase.instance.client
          .from('usuarios')
          .select()
          .eq('id', agente['parent_id'])
          .maybeSingle();
    }

    final cliente = await Supabase.instance.client
        .from('clientes')
        .select()
        .eq('id', venta['cliente_id'])
        .maybeSingle();

    final numeroPoliza = venta['numero_poliza']?.toString() ?? '';

    final recibos = numeroPoliza.isEmpty
        ? []
        : await Supabase.instance.client
              .from('recibos')
              .select()
              .ilike('numero_poliza', numeroPoliza);

    final cobrados = recibos.where((r) => r['estado'] == 'COBRADO').length;
    final devueltos = recibos.where((r) => r['estado'] == 'DEVUELTO').length;
    final pendientes = recibos.where((r) => r['estado'] == 'PENDIENTE').length;

    if (!mounted) return;

    _showPanelDialog(
      context: context,
      builder: (_) {
        return Dialog(
          child: Container(
            width: 1150,
            height: 750,
            padding: const EdgeInsets.all(25),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Ficha de venta / póliza ${numeroPoliza.isEmpty ? 'Sin póliza' : numeroPoliza}",
                        style: const TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.close),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  Wrap(
                    spacing: 20,
                    runSpacing: 20,
                    children: [
                      _detalleKpiColor(
                        "Prima anual",
                        "${((venta['prima_anual'] ?? 0) as num).toStringAsFixed(2)} €",
                        Colors.blue.shade50,
                        Colors.blue.shade700,
                      ),

                      _detalleKpiColor(
                        "Prima bruta",
                        "${((venta['prima_anual_bruta'] ?? 0) as num).toStringAsFixed(2)} €",
                        Colors.purple.shade50,
                        Colors.purple.shade700,
                      ),

                      _detalleKpiColor(
                        "Prima neta",
                        "${((venta['prima_anual_neta'] ?? 0) as num).toStringAsFixed(2)} €",
                        Colors.green.shade50,
                        Colors.green.shade700,
                      ),

                      _detalleKpiColor(
                        "Comisión",
                        "${((venta['comision'] ?? 0) as num).toStringAsFixed(2)} €",
                        Colors.orange.shade50,
                        Colors.orange.shade700,
                      ),

                      _detalleKpiColor(
                        "Cobrados",
                        "$cobrados",
                        Colors.green.shade50,
                        Colors.green.shade700,
                      ),

                      _detalleKpiColor(
                        "Devueltos",
                        "$devueltos",
                        Colors.red.shade50,
                        Colors.red.shade700,
                      ),

                      _detalleKpiColor(
                        "Pendientes",
                        "$pendientes",
                        Colors.amber.shade50,
                        Colors.amber.shade800,
                      ),
                    ],
                  ),

                  const SizedBox(height: 30),

                  const Text(
                    "Datos del cliente",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),

                  const SizedBox(height: 10),

                  _filaDetalle(
                    "Cliente",
                    cliente == null
                        ? "-"
                        : "${cliente['nombre']} ${cliente['apellidos']}",
                  ),
                  _filaDetalle("Email", cliente?['email']),
                  _filaDetalle("Teléfono", cliente?['telefono']),
                  _filaDetalle("Provincia", cliente?['provincia']),
                  _filaDetalle("Población", cliente?['poblacion']),

                  const SizedBox(height: 25),

                  const Text(
                    "Datos comerciales",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),

                  const SizedBox(height: 10),

                  _filaDetalle(
                    "Agente",
                    agente == null
                        ? "-"
                        : "${agente['nombre']} ${agente['apellidos']}",
                  ),
                  _filaDetalle(
                    "Jefe equipo",
                    jefe == null
                        ? "-"
                        : "${jefe['nombre']} ${jefe['apellidos']}",
                  ),
                  _filaDetalle("Compañía", venta['compania']),
                  _filaDetalle("Producto", venta['producto']),
                  _filaDetalle("Categoría", venta['categoria_producto']),
                  _filaDetalle("Forma de pago", venta['forma_pago']),
                  _filaDetalle("Fecha efecto", venta['fecha_efecto']),
                  _filaDetalle("Número asegurados", venta['numero_asegurados']),
                  _filaDetalle("Precio", venta['precio']),

                  const SizedBox(height: 25),

                  const Text(
                    "Historial de recibos",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),

                  const SizedBox(height: 10),

                  SizedBox(
                    height: 250,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: ProgressiveRecords(
                          count: recibos.length,
                          resetKey: progressiveRecordKey(recibos),
                          showFooter: true,
                          builder: (context, _visibleRows) => DataTable(
                            columns: const [
                              DataColumn(label: Text("Fecha")),
                              DataColumn(label: Text("Importe")),
                              DataColumn(label: Text("Estado")),
                              DataColumn(label: Text("Motivo")),
                            ],
                            rows: recibos.take(_visibleRows).map<DataRow>((r) {
                              return DataRow(
                                cells: [
                                  DataCell(Text(r['fecha']?.toString() ?? '')),
                                  DataCell(
                                    Text(r['importe']?.toString() ?? ''),
                                  ),
                                  DataCell(Text(r['estado']?.toString() ?? '')),
                                  DataCell(Text(r['motivo']?.toString() ?? '')),
                                ],
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 25),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      OutlinedButton(
                        onPressed: () {
                          Navigator.pop(context);
                          editarPolizaDialog(venta);
                        },
                        child: const Text("Editar póliza"),
                      ),
                      const SizedBox(width: 10),
                      ElevatedButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text("Cerrar"),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> editarPolizaDialog(Map<String, dynamic> v) async {
    final rol = _normalizarRolERP(usuarioActualERP?['rol_usuario']);
    final changed = await _showPanelDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => PolicyEditDialog(
        policy: v,
        allowedAuthIds: veTodoERP || rol == 'director_nacional'
            ? null
            : authIdsPermitidosERP.toSet(),
      ),
    );
    if (changed != true || !mounted) return;
    await cargarFiltrosVentas();
    if (!mounted) return;
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Póliza actualizada correctamente'),
        backgroundColor: Colors.green,
      ),
    );
  }


  Future<void> consultarRecibosDialog(Map<String, dynamic> v) async {
    print("CONSULTAR RECIBOS PULSADO");
    print("POLIZA: ${v['numero_poliza']}");
    print("FECHA EFECTO: ${v['fecha_efecto']}");

    final numeroPoliza = v['numero_poliza']?.toString() ?? '';
    final formaPago = v['forma_pago']?.toString() ?? '';
    final fechaEfectoTexto = v['fecha_efecto']?.toString() ?? '';

    DateTime? fechaEfecto;

    if (fechaEfectoTexto.contains('/')) {
      final partes = fechaEfectoTexto.split('/');

      if (partes.length == 3) {
        fechaEfecto = DateTime(
          int.parse(partes[2]),
          int.parse(partes[1]),
          int.parse(partes[0]),
        );
      }
    } else {
      fechaEfecto = DateTime.tryParse(fechaEfectoTexto);
    }

    if (fechaEfecto == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("La póliza no tiene una fecha de efecto válida"),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final recibosDevueltos = await Supabase.instance.client
        .from('recibos')
        .select()
        .eq('poliza', numeroPoliza);

    final List<Map<String, dynamic>> historial = [];

    int mesesSalto = 1;

    final fp = formaPago.toLowerCase();

    if (fp.contains('trimes')) {
      mesesSalto = 3;
    } else if (fp.contains('semes')) {
      mesesSalto = 6;
    } else if (fp.contains('anual') || fp.trim() == 'no informada') {
      mesesSalto = 12;
    } else {
      mesesSalto = 1;
    }

    DateTime fechaRecibo = DateTime(
      fechaEfecto.year,
      fechaEfecto.month,
      fechaEfecto.day,
    );

    final hoy = DateTime.now();

    while (!fechaRecibo.isAfter(hoy)) {
      final devuelto = recibosDevueltos.where((r) {
        final fechaReciboTabla = r['fecha']?.toString() ?? '';
        final estado = r['estado']?.toString().toLowerCase() ?? '';
        final gestion = r['gestion']?.toString().toLowerCase() ?? '';

        final coincideMes = fechaReciboTabla.contains(
          "${fechaRecibo.year}-${fechaRecibo.month.toString().padLeft(2, '0')}",
        );

        return coincideMes &&
            (estado.contains('devuelto') || gestion.contains('devuelto'));
      }).toList();

      historial.add({
        'fecha': fechaRecibo,
        'estado': devuelto.isEmpty ? 'COBRADO' : 'DEVUELTO',
        'detalle': devuelto.isEmpty ? null : devuelto.first,
      });

      fechaRecibo = DateTime(
        fechaRecibo.year,
        fechaRecibo.month + mesesSalto,
        fechaRecibo.day,
      );
    }

    await _showPanelDialog(
      context: context,
      builder: (_) {
        return Dialog(
          insetPadding: const EdgeInsets.symmetric(
            horizontal: 18,
            vertical: 24,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 780),
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(13),
                        decoration: BoxDecoration(
                          color: Colors.indigo.shade50,
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Icon(
                          Icons.receipt_long,
                          color: Colors.indigo.shade700,
                          size: 32,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Historial de recibos",
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "Póliza $numeroPoliza",
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey.shade600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.close),
                      ),
                    ],
                  ),

                  const SizedBox(height: 22),

                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Colors.grey.shade300),
                    ),
                    child: Wrap(
                      spacing: 18,
                      runSpacing: 10,
                      children: [
                        _miniDatoRecibo("Fecha efecto", fechaEfectoTexto),
                        _miniDatoRecibo("Forma de pago", formaPago),
                        _miniDatoRecibo(
                          "Recibos generados",
                          historial.length.toString(),
                        ),
                        _miniDatoRecibo(
                          "Devueltos",
                          historial
                              .where((e) => e['estado'] == 'DEVUELTO')
                              .length
                              .toString(),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  const Text(
                    "Evolución de recibos",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),

                  const SizedBox(height: 12),

                  ...historial.map((r) {
                    final fecha = r['fecha'] as DateTime;
                    final estado = r['estado'] as String;
                    final esDevuelto = estado == 'DEVUELTO';

                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        color: esDevuelto
                            ? Colors.red.shade50
                            : Colors.green.shade50,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: esDevuelto
                              ? Colors.red.shade200
                              : Colors.green.shade200,
                        ),
                      ),
                      child: Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: esDevuelto
                                ? Colors.red.shade100
                                : Colors.green.shade100,
                            child: Icon(
                              esDevuelto
                                  ? Icons.warning_amber_rounded
                                  : Icons.check_circle_outline,
                              color: esDevuelto
                                  ? Colors.red.shade700
                                  : Colors.green.shade700,
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "${fecha.day.toString().padLeft(2, '0')}/${fecha.month.toString().padLeft(2, '0')}/${fecha.year}",
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  esDevuelto
                                      ? "Recibo devuelto encontrado en tabla recibos"
                                      : "Recibo cobrado automáticamente",
                                  style: TextStyle(color: Colors.grey.shade700),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 13,
                              vertical: 7,
                            ),
                            decoration: BoxDecoration(
                              color: esDevuelto
                                  ? Colors.red.shade600
                                  : Colors.green.shade600,
                              borderRadius: BorderRadius.circular(30),
                            ),
                            child: Text(
                              estado,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _miniDatoRecibo(String titulo, String valor) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            titulo,
            style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
          ),
          const SizedBox(height: 3),
          Text(
            valor.isEmpty ? "Sin dato" : valor,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Future<void> gestionarPolizaDialog(Map<String, dynamic> v) async {
    final comentarioController = TextEditingController();
    final proximaAccionController = TextEditingController();
    final fechaProximaController = TextEditingController();

    String tipoGestion = "Seguimiento";
    String estadoGestion = "Pendiente";

    final poliza = v['numero_poliza']?.toString() ?? '';
    final ventaId = v['id'];

    final gestiones = await Supabase.instance.client
        .from('gestiones_poliza')
        .select()
        .eq('venta_id', ventaId)
        .order('created_at', ascending: false);

    await _showPanelDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return Dialog(
              insetPadding: const EdgeInsets.symmetric(
                horizontal: 18,
                vertical: 24,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              child: Container(
                constraints: const BoxConstraints(maxWidth: 850),
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: Colors.deepPurple.shade50,
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: Icon(
                              Icons.manage_accounts,
                              color: Colors.deepPurple.shade700,
                              size: 34,
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  "Centro de gestión de póliza",
                                  style: TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  poliza.isEmpty
                                      ? "Póliza pendiente de asignar"
                                      : "Póliza $poliza",
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.grey.shade600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            onPressed: () => Navigator.pop(context),
                            icon: const Icon(Icons.close),
                          ),
                        ],
                      ),

                      const SizedBox(height: 24),

                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: Colors.grey.shade300),
                        ),
                        child: Wrap(
                          spacing: 12,
                          runSpacing: 12,
                          children: [
                            _chipGestion("Producto", v['producto']),
                            _chipGestion("Compañía", v['compañia']),
                            _chipGestion("Forma pago", v['forma_pago']),
                            _chipGestion("Fecha efecto", v['fecha_efecto']),
                            _chipGestion("Prima anual", v['prima_anual']),
                          ],
                        ),
                      ),

                      const SizedBox(height: 24),

                      const Text(
                        "Nueva gestión",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const SizedBox(height: 14),

                      DropdownButtonFormField<String>(
                        value: tipoGestion,
                        decoration: _decoracionGestion(
                          "Tipo de gestión",
                          Icons.task_alt,
                        ),
                        items: const [
                          DropdownMenuItem(
                            value: "Seguimiento",
                            child: Text("Seguimiento"),
                          ),
                          DropdownMenuItem(
                            value: "Recibo devuelto",
                            child: Text("Recibo devuelto"),
                          ),
                          DropdownMenuItem(
                            value: "Cambio de datos",
                            child: Text("Cambio de datos"),
                          ),
                          DropdownMenuItem(
                            value: "Consulta cliente",
                            child: Text("Consulta cliente"),
                          ),
                          DropdownMenuItem(
                            value: "Incidencia",
                            child: Text("Incidencia"),
                          ),
                          DropdownMenuItem(
                            value: "Baja posible",
                            child: Text("Baja posible"),
                          ),
                          DropdownMenuItem(
                            value: "Retención",
                            child: Text("Retención"),
                          ),
                          DropdownMenuItem(
                            value: "Venta cruzada",
                            child: Text("Venta cruzada"),
                          ),
                        ],
                        onChanged: (value) {
                          setDialogState(() {
                            tipoGestion = value ?? "Seguimiento";
                          });
                        },
                      ),

                      const SizedBox(height: 14),

                      DropdownButtonFormField<String>(
                        value: estadoGestion,
                        decoration: _decoracionGestion(
                          "Estado",
                          Icons.flag_outlined,
                        ),
                        items: const [
                          DropdownMenuItem(
                            value: "Pendiente",
                            child: Text("Pendiente"),
                          ),
                          DropdownMenuItem(
                            value: "En gestión",
                            child: Text("En gestión"),
                          ),
                          DropdownMenuItem(
                            value: "Solucionado",
                            child: Text("Solucionado"),
                          ),
                          DropdownMenuItem(
                            value: "No localizado",
                            child: Text("No localizado"),
                          ),
                          DropdownMenuItem(
                            value: "Revisar urgente",
                            child: Text("Revisar urgente"),
                          ),
                        ],
                        onChanged: (value) {
                          setDialogState(() {
                            estadoGestion = value ?? "Pendiente";
                          });
                        },
                      ),

                      const SizedBox(height: 14),

                      TextField(
                        controller: comentarioController,
                        maxLines: 4,
                        decoration: _decoracionGestion(
                          "Comentario de la gestión",
                          Icons.notes,
                        ),
                      ),

                      const SizedBox(height: 14),

                      TextField(
                        controller: proximaAccionController,
                        decoration: _decoracionGestion(
                          "Próxima acción",
                          Icons.next_plan_outlined,
                        ),
                      ),

                      const SizedBox(height: 14),

                      TextField(
                        controller: fechaProximaController,
                        decoration: _decoracionGestion(
                          "Fecha próxima acción, ejemplo 2026-06-30",
                          Icons.calendar_month,
                        ),
                      ),

                      const SizedBox(height: 22),

                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          icon: const Icon(Icons.save),
                          label: const Text("Guardar gestión"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.deepPurple.shade700,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                          ),
                          onPressed: () async {
                            await Supabase.instance.client
                                .from('gestiones_poliza')
                                .insert({
                                  'venta_id': ventaId,
                                  'poliza': poliza,
                                  'tipo_gestion': tipoGestion,
                                  'estado': estadoGestion,
                                  'comentario': comentarioController.text
                                      .trim(),
                                  'proxima_accion': proximaAccionController.text
                                      .trim(),
                                  'fecha_proxima_accion':
                                      fechaProximaController.text.trim().isEmpty
                                      ? null
                                      : fechaProximaController.text.trim(),
                                });

                            Navigator.pop(context);

                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text("Gestión guardada correctamente"),
                                backgroundColor: Colors.green,
                              ),
                            );

                            setState(() {});
                          },
                        ),
                      ),

                      const SizedBox(height: 28),

                      const Text(
                        "Historial de gestiones",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const SizedBox(height: 12),

                      if (gestiones.isEmpty)
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            color: Colors.grey.shade100,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: Colors.grey.shade300),
                          ),
                          child: const Text(
                            "Todavía no hay gestiones registradas para esta póliza.",
                          ),
                        )
                      else
                        ...gestiones.map((g) {
                          return Container(
                            margin: const EdgeInsets.only(bottom: 12),
                            padding: const EdgeInsets.all(15),
                            decoration: BoxDecoration(
                              color: Colors.blueGrey.shade50,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: Colors.blueGrey.shade100,
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(
                                      Icons.history,
                                      color: Colors.blueGrey.shade700,
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        "${g['tipo_gestion'] ?? ''} · ${g['estado'] ?? ''}",
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Text(g['comentario']?.toString() ?? ''),
                                const SizedBox(height: 8),
                                if ((g['proxima_accion']?.toString() ?? '')
                                    .isNotEmpty)
                                  Text(
                                    "Próxima acción: ${g['proxima_accion']}",
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                if ((g['fecha_proxima_accion']?.toString() ??
                                        '')
                                    .isNotEmpty)
                                  Text(
                                    "Fecha: ${g['fecha_proxima_accion']}",
                                    style: TextStyle(
                                      color: Colors.grey.shade700,
                                    ),
                                  ),
                              ],
                            ),
                          );
                        }).toList(),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );

    comentarioController.dispose();
    proximaAccionController.dispose();
    fechaProximaController.dispose();
  }

  Widget _chipGestion(String titulo, dynamic valor) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            titulo,
            style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
          ),
          const SizedBox(height: 3),
          Text(
            valor?.toString().isEmpty ?? true ? "Sin dato" : valor.toString(),
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  InputDecoration _decoracionGestion(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon),
      filled: true,
      fillColor: Colors.grey.shade50,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Colors.deepPurple, width: 1.6),
      ),
    );
  }

  Future<void> anularPolizaDialog(Map<String, dynamic> v) async {
    final detalleController = TextEditingController();
    final fechaController = TextEditingController(
      text: DateTime.now().toIso8601String().substring(0, 10),
    );

    String motivoSeleccionado = "Impago";
    bool confirmacion = false;
    bool guardando = false;

    final poliza = v['numero_poliza']?.toString() ?? '';
    final ventaId = v['id'];

    await _showPanelDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return Dialog(
              insetPadding: const EdgeInsets.symmetric(
                horizontal: 18,
                vertical: 24,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              child: Container(
                constraints: const BoxConstraints(maxWidth: 760),
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: Colors.red.shade50,
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: Icon(
                              Icons.cancel_outlined,
                              color: Colors.red.shade700,
                              size: 34,
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  "Anular póliza",
                                  style: TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  poliza.isEmpty
                                      ? "Póliza pendiente de número"
                                      : "Póliza $poliza",
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.grey.shade600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            onPressed: guardando
                                ? null
                                : () => Navigator.pop(context),
                            icon: const Icon(Icons.close),
                          ),
                        ],
                      ),

                      const SizedBox(height: 22),

                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.red.shade50,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: Colors.red.shade200),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.warning_amber_rounded,
                              color: Colors.red.shade700,
                            ),
                            const SizedBox(width: 12),
                            const Expanded(
                              child: Text(
                                "Esta acción marcará la póliza como ANULADA y guardará un expediente de anulación. No se eliminará la venta.",
                                style: TextStyle(fontWeight: FontWeight.w600),
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 24),

                      DropdownButtonFormField<String>(
                        value: motivoSeleccionado,
                        decoration: _decoracionAnulacion(
                          "Motivo de anulación",
                          Icons.report_problem_outlined,
                        ),
                        items: const [
                          DropdownMenuItem(
                            value: "Impago",
                            child: Text("Impago"),
                          ),
                          DropdownMenuItem(
                            value: "Baja voluntaria",
                            child: Text("Baja voluntaria"),
                          ),
                          DropdownMenuItem(
                            value: "Cambio de compañía",
                            child: Text("Cambio de compañía"),
                          ),
                          DropdownMenuItem(
                            value: "Error en emisión",
                            child: Text("Error en emisión"),
                          ),
                          DropdownMenuItem(
                            value: "Duplicada",
                            child: Text("Póliza duplicada"),
                          ),
                          DropdownMenuItem(
                            value: "No conforme cliente",
                            child: Text("Cliente no conforme"),
                          ),
                          DropdownMenuItem(
                            value: "Fallecimiento",
                            child: Text("Fallecimiento"),
                          ),
                          DropdownMenuItem(
                            value: "Otro",
                            child: Text("Otro motivo"),
                          ),
                        ],
                        onChanged: (value) {
                          setDialogState(() {
                            motivoSeleccionado = value ?? "Impago";
                          });
                        },
                      ),

                      const SizedBox(height: 14),

                      TextField(
                        controller: fechaController,
                        decoration: _decoracionAnulacion(
                          "Fecha de anulación, ejemplo 2026-06-26",
                          Icons.calendar_month_outlined,
                        ),
                      ),

                      const SizedBox(height: 14),

                      TextField(
                        controller: detalleController,
                        maxLines: 5,
                        decoration: _decoracionAnulacion(
                          "Detalle de la anulación",
                          Icons.notes_outlined,
                        ),
                      ),

                      const SizedBox(height: 16),

                      CheckboxListTile(
                        value: confirmacion,
                        contentPadding: EdgeInsets.zero,
                        title: const Text(
                          "Confirmo que quiero anular esta póliza",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: const Text(
                          "La póliza quedará marcada como ANULADA en el sistema.",
                        ),
                        onChanged: guardando
                            ? null
                            : (value) {
                                setDialogState(() {
                                  confirmacion = value ?? false;
                                });
                              },
                      ),

                      const SizedBox(height: 24),

                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: guardando
                                  ? null
                                  : () => Navigator.pop(context),
                              icon: const Icon(Icons.close),
                              label: const Text("Cancelar"),
                              style: OutlinedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 15,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton.icon(
                              icon: guardando
                                  ? const SizedBox(
                                      width: 18,
                                      height: 18,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: Colors.white,
                                      ),
                                    )
                                  : const Icon(Icons.cancel),
                              label: Text(
                                guardando ? "Anulando..." : "Anular póliza",
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red.shade700,
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(
                                  vertical: 15,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                              ),
                              onPressed: !confirmacion || guardando
                                  ? null
                                  : () async {
                                      setDialogState(() {
                                        guardando = true;
                                      });

                                      try {
                                        await Supabase.instance.client
                                            .from('anulaciones_poliza')
                                            .insert({
                                              'venta_id': ventaId,
                                              'poliza': poliza,
                                              'motivo': motivoSeleccionado,
                                              'detalle': detalleController.text
                                                  .trim(),
                                              'fecha_anulacion': fechaController
                                                  .text
                                                  .trim(),
                                              'estado': 'ANULADA',
                                              'usuario': Supabase
                                                  .instance
                                                  .client
                                                  .auth
                                                  .currentUser
                                                  ?.email,
                                            });

                                        await Supabase.instance.client
                                            .from('ventas')
                                            .update({
                                              'estado_poliza': 'ANULADA',
                                            })
                                            .eq('id', ventaId);

                                        Navigator.pop(context);

                                        ScaffoldMessenger.of(
                                          context,
                                        ).showSnackBar(
                                          const SnackBar(
                                            content: Text(
                                              "Póliza anulada correctamente",
                                            ),
                                            backgroundColor: Colors.green,
                                          ),
                                        );

                                        setState(() {});
                                      } catch (e) {
                                        setDialogState(() {
                                          guardando = false;
                                        });

                                        ScaffoldMessenger.of(
                                          context,
                                        ).showSnackBar(
                                          SnackBar(
                                            content: Text(
                                              "Error al anular la póliza: $e",
                                            ),
                                            backgroundColor: Colors.red,
                                          ),
                                        );
                                      }
                                    },
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );

    detalleController.dispose();
    fechaController.dispose();
  }

  InputDecoration _decoracionAnulacion(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon),
      filled: true,
      fillColor: Colors.grey.shade50,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Colors.red, width: 1.6),
      ),
    );
  }
}

class TablaConScrollHorizontalERP extends StatefulWidget {
  final Widget child;

  const TablaConScrollHorizontalERP({super.key, required this.child});

  @override
  State<TablaConScrollHorizontalERP> createState() =>
      _TablaConScrollHorizontalERPState();
}

class _TablaConScrollHorizontalERPState
    extends State<TablaConScrollHorizontalERP> {
  final ScrollController horizontalController = ScrollController();

  @override
  void dispose() {
    horizontalController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scrollbar(
      controller: horizontalController,
      thumbVisibility: true,
      trackVisibility: true,
      interactive: true,
      thickness: 12,
      radius: const Radius.circular(20),
      child: SingleChildScrollView(
        controller: horizontalController,
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.only(bottom: 16),
        child: widget.child,
      ),
    );
  }
}
