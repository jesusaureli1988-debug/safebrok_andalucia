import 'package:excel/excel.dart';
import 'dart:convert';
import 'package:archive/archive.dart';

class SalesExcelExport {
  static List<Map<String, dynamic>> filter(
    List<Map<String, dynamic>> sales, {
    String? company,
    String? category,
    String? agent,
    String? manager,
    DateTime? from,
    DateTime? until,
  }) {
    DateTime day(DateTime d) => DateTime(d.year, d.month, d.day);
    return sales.where((sale) {
      for (final entry in {
        'compania': company,
        'categoria_producto': category,
        'agente_nombre': agent,
        'jefe_nombre': manager,
      }.entries) {
        if (entry.value != null &&
            entry.value!.isNotEmpty &&
            sale[entry.key] != entry.value)
          return false;
      }
      if (from != null || until != null) {
        final date = DateTime.tryParse(sale['fecha_efecto']?.toString() ?? '');
        if (date == null) return false;
        if (from != null && day(date).isBefore(day(from))) return false;
        if (until != null && day(date).isAfter(day(until))) return false;
      }
      return true;
    }).toList();
  }

  static List<int> encode(List<Map<String, dynamic>> sales) {
    final book = Excel.createExcel();
    final sheet = book['Ventas'];
    for (final name in book.tables.keys.toList()) {
      if (name != 'Ventas') book.delete(name);
    }
    book.setDefaultSheet('Ventas');
    const columns = {
      'numero_poliza': 'Póliza',
      'producto': 'Producto',
      'compania': 'Compañía',
      'precio': 'Precio',
      'prima_anual': 'Prima anual',
      'prima_anual_neta': 'Prima anual neta',
      'comision': 'Comisión',
      'fecha_efecto': 'Fecha de efecto',
      'agente_nombre': 'Agente',
      'jefe_nombre': 'Jefe de equipo',
      'categoria_producto': 'Categoría',
      'estado_poliza': 'Estado',
    };
    sheet.appendRow(columns.values.map(TextCellValue.new).toList());
    const numeric = {'precio', 'prima_anual', 'prima_anual_neta', 'comision'};
    for (final sale in sales) {
      sheet.appendRow(
        columns.keys.map((key) {
          final value =
              sale[key] ?? (key == 'comision' ? sale['comison'] : null);
          final number = value is num
              ? value.toDouble()
              : double.tryParse(value?.toString().replaceAll(',', '.') ?? '');
          if (numeric.contains(key) && number != null && number.isFinite) {
            return DoubleCellValue(number);
          }
          return TextCellValue(value?.toString() ?? '');
        }).toList(),
      );
    }
    final bytes = book.encode();
    if (bytes == null)
      throw StateError('No se pudo generar el Excel de ventas');
    // excel 4 does not expose AutoFilter. Add the standard XLSX element after
    // serializing so Excel opens with filter arrows on the full exported range.
    final archive = ZipDecoder().decodeBytes(bytes);
    final worksheet = archive.files.singleWhere(
      (file) => RegExp(r'^xl/worksheets/sheet\d+\.xml$').hasMatch(file.name),
    );
    final xml = utf8.decode(worksheet.content as List<int>);
    final filtered = utf8.encode(
      xml.replaceFirst(
        '</sheetData>',
        '</sheetData><autoFilter ref="A1:L${sales.length + 1}"/>',
      ),
    );
    archive.addFile(ArchiveFile(worksheet.name, filtered.length, filtered));
    final result = ZipEncoder().encode(archive);
    if (result == null) throw StateError('No se pudieron añadir los filtros');
    return result;
  }
}
