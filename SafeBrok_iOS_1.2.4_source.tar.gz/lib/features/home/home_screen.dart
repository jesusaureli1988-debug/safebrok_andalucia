import 'package:safebrok_andalucia/core/auth/app_role.dart';
import 'dart:ui';
import '../cotizaciones/cotizaciones_screen.dart';
import '../cotizaciones/avant2_access.dart';
import 'package:safebrok_andalucia/features/incorporaciones/incorporaciones_screen.dart';
import 'package:safebrok_andalucia/features/incorporaciones/incorporacion_repository.dart';
import 'package:flutter/foundation.dart'
    show kIsWeb, defaultTargetPlatform, TargetPlatform;
import 'package:safebrok_andalucia/core/production/premium_weighting.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../sales/create_sale_wizard.dart';
import '../sales/my_sales_screen.dart';
import '../clients/my_clients_screen.dart';
import 'package:safebrok_andalucia/features/team/team_dashboard_screen.dart';
import 'package:safebrok_andalucia/utils/team_tracking_screen.dart';
import 'package:safebrok_andalucia/features/tareas/mis_tareas_screen.dart';
import 'package:safebrok_andalucia/core/update_service.dart';
import 'package:safebrok_andalucia/core/production/production_period_service.dart';
import 'package:safebrok_andalucia/core/production/home_ranking_service.dart';
import 'package:safebrok_andalucia/features/tareas/jefe_equipo_tareas_screen.dart';
import 'package:safebrok_andalucia/features/agenda/agenda_screen.dart';
import 'package:safebrok_andalucia/features/team/mis_equipos_jefe_ventas_screen.dart';
import 'package:safebrok_andalucia/features/jefe_ventas/control_equipos_jefe_ventas_screen.dart';
import 'package:safebrok_andalucia/features/jefe_ventas/seguimiento_jefe_ventas_screen.dart';
import 'package:safebrok_andalucia/features/jefe_ventas/agenda_jefe_ventas_screen.dart';
import 'package:safebrok_andalucia/features/team/agenda_jefe_equipo_screen.dart';
import 'dart:async';
import 'package:safebrok_andalucia/features/chat/internal_chat_screen.dart';
import 'package:safebrok_andalucia/features/recibos/recibos_agente_screen.dart';
import 'package:safebrok_andalucia/features/ia/safebrok_ai_screen.dart';
import 'package:safebrok_andalucia/features/previsiones/previsiones_screen.dart';
import 'package:safebrok_andalucia/features/director_nacional/director_nacional_kpis_screen.dart';
import 'package:safebrok_andalucia/features/director_nacional/director_nacional_usuarios_screen.dart';
import 'package:safebrok_andalucia/features/business/ranking_comercial_screen.dart';
import 'package:safebrok_andalucia/features/business/cuadro_mandos_screen.dart';
import 'package:safebrok_andalucia/features/business/plan_comercial_anual_screen.dart';
import 'package:safebrok_andalucia/features/business/cargar_gestiones_screen.dart';
import 'package:safebrok_andalucia/features/business/mis_gestiones_screen.dart';
import 'package:safebrok_andalucia/features/jefe_equipo/desarrollo_crecimiento_equipo_screen.dart';
import 'package:url_launcher/url_launcher.dart';

class DashboardItem {
  final String title;
  final IconData icon;
  final VoidCallback onTap;
  final String subtitle;
  final Color color;

  DashboardItem({
    required this.title,
    required this.icon,
    required this.onTap,
    this.subtitle = "Abrir módulo",
    this.color = const Color(0xFF22D3EE),
  });
}

class ProductionCountdown extends StatefulWidget {
  const ProductionCountdown({super.key});

  @override
  State<ProductionCountdown> createState() => _ProductionCountdownState();
}

class _ProductionCountdownState extends State<ProductionCountdown> {
  DateTime? targetDate;
  Duration remaining = Duration.zero;
  Timer? _timer;
  bool _loadingPeriod = true;

  @override
  void initState() {
    super.initState();
    _loadProductionPeriod();
  }

  Future<void> _loadProductionPeriod() async {
    final period = await ProductionPeriodService.instance.current(
      forceRefresh: true,
    );
    if (!mounted) return;

    setState(() {
      targetDate = period.endInclusive;
      _loadingPeriod = false;
    });
    _updateRemaining();

    _timer?.cancel();
    _timer = Timer.periodic(
      const Duration(seconds: 1),
      (_) => _updateRemaining(),
    );
  }

  void _updateRemaining() {
    final target = targetDate;
    if (!mounted || target == null) return;
    setState(() {
      remaining = target.difference(DateTime.now());
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String format(Duration d) {
    if (d.isNegative) return "Cerrado";

    final days = d.inDays;
    final hours = d.inHours % 24;
    final minutes = d.inMinutes % 60;
    final seconds = d.inSeconds % 60;

    return "${days}d ${hours}h ${minutes}m ${seconds}s";
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.94),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF8EDFE0)),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0AAEAE).withOpacity(0.12),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.timer_rounded, color: Color(0xFF0AAEAE), size: 20),
          const SizedBox(width: 7),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Producción cierra en",
                style: TextStyle(
                  color: Color(0xFF53627A),
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                _loadingPeriod ? "Consultando cierre…" : format(remaining),
                style: const TextStyle(
                  color: Color(0xFF087F86),
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  final String role;

  const HomeScreen({super.key, required this.role});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final supabase = Supabase.instance.client;

  int totalVentas = 0;
  int totalTareas = 0;

  double primasMes = 0.0;
  double primasMixMes = 0.0;
  double objetivoMes = 4000.0;
  int rachaMeses = 0;

  int rankingPosicion = 0;
  int rankingTotal = 0;
  int rankingPrimero = 0;
  int misPolizasTotales = 0;

  String rolUsuarioLogueado = '';

  bool loadingKpis = true;
  bool _kpiLoadFailed = false;
  String _cargoDescription = 'por fecha de efecto del cargo';
  bool _checkingUpdate = false;
  bool _updateDialogShown = false;

  int chatUnreadCount = 0;
  int systemUnreadCount = 0;
  Timer? chatTimer;

  final List<List<String>> frasesMotivadoras = [
    ["Hoy es un gran día", "para cerrar ventas."],

    ["Cada puerta", "es una oportunidad."],

    ["No vendes seguros,", "proteges familias."],

    ["El éxito empieza", "con una visita más."],

    ["Cada conversación", "puede cambiar tu mes."],

    ["Hoy puede ser", "tu mejor día del año."],

    ["La disciplina", "vence al talento."],

    ["Nunca sabes", "dónde está la siguiente venta."],

    ["La confianza", "es tu mejor argumento."],

    ["Cada cliente", "merece la mejor protección."],

    ["El mejor comercial", "nunca deja de aprender."],

    ["Hoy toca", "crear oportunidades."],

    ["No esperes", "haz que ocurra."],

    ["Cada visita", "te acerca al objetivo."],

    ["Construye relaciones,", "las ventas llegarán."],

    ["El esfuerzo de hoy", "es la comisión de mañana."],

    ["Haz una llamada más.", "Puede cambiar tu semana."],

    ["La constancia", "siempre gana."],

    ["Cada sí", "empieza con muchos no."],

    ["Hoy es un buen día", "para crecer."],
  ];
  late List<String> fraseDelDia;

  @override
  void initState() {
    super.initState();

    final hoy = DateTime.now();

    final indice =
        (hoy.year * 1000 + hoy.month * 100 + hoy.day) %
        frasesMotivadoras.length;

    fraseDelDia = frasesMotivadoras[indice];

    WidgetsBinding.instance.addPostFrameCallback((_) {
      loadKpis();
      checkForUpdate();
      loadChatUnreadCount();

      comprobarAlertasSeguimientoJefe().then((_) {
        loadSystemUnreadCount();
      });

      chatTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
        await loadChatUnreadCount();
        await comprobarAlertasSeguimientoJefe();
        await loadSystemUnreadCount();
      });
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
  }

  @override
  void dispose() {
    chatTimer?.cancel();
    super.dispose();
  }

  Future<void> loadChatUnreadCount() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final res = await supabase
          .from('chat_mensajes')
          .select('id')
          .eq('receiver_auth_id', user.id)
          .eq('leido', false);

      if (!mounted) return;

      setState(() {
        chatUnreadCount = res.length;
      });
    } catch (e) {
      debugPrint('ERROR CHAT UNREAD HOME: $e');
    }
  }

  Future<void> loadSystemUnreadCount() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final alertas = await supabase
          .from('alertas')
          .select('id')
          .eq('auth_id_destino', user.id)
          .eq('leida', false);

      final notificaciones = await supabase
          .from('notificaciones')
          .select('id')
          .eq('usuario_auth_id', user.id)
          .eq('leida', false);

      if (!mounted) return;

      setState(() {
        systemUnreadCount = alertas.length + notificaciones.length;
      });
    } catch (e) {
      debugPrint('ERROR SYSTEM UNREAD HOME: $e');
    }
  }

  Future<void> comprobarAlertasSeguimientoJefe() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final miUsuario = await supabase
          .from('usuarios')
          .select('id, auth_id, rol_usuario')
          .or(
            'estado.is.null,estado.not.in.(inactivo,Inactivo,INACTIVO,baja,Baja,BAJA,desactivado,Desactivado,DESACTIVADO,bloqueado,Bloqueado,BLOQUEADO,suspendido,Suspendido,SUSPENDIDO)',
          )
          .eq('auth_id', user.id)
          .maybeSingle();

      if (miUsuario == null) return;

      if (miUsuario['rol_usuario'] != 'jefe_equipo') return;

      final miUserId = miUsuario['id'];

      final agentes = await supabase
          .from('usuarios')
          .select('id, auth_id, nombre, apellidos, parent_id, rol_usuario')
          .or(
            'estado.is.null,estado.not.in.(inactivo,Inactivo,INACTIVO,baja,Baja,BAJA,desactivado,Desactivado,DESACTIVADO,bloqueado,Bloqueado,BLOQUEADO,suspendido,Suspendido,SUSPENDIDO)',
          )
          .eq('parent_id', miUserId)
          .eq('rol_usuario', 'agente');

      final hoy = DateTime.now();

      final limite = DateTime(
        hoy.year,
        hoy.month,
        hoy.day,
      ).subtract(const Duration(days: 3));

      final limiteString =
          "${limite.year.toString().padLeft(4, '0')}-"
          "${limite.month.toString().padLeft(2, '0')}-"
          "${limite.day.toString().padLeft(2, '0')}";

      for (final agente in agentes) {
        final authIdAgente = agente['auth_id'];

        if (authIdAgente == null) continue;

        final seguimientosAtrasados = await supabase
            .from('seguimiento_clientes')
            .select('id')
            .eq('auth_id', authIdAgente)
            .eq('estado', 'Pendiente')
            .lte('proxima_llamada', limiteString);

        if (seguimientosAtrasados.isEmpty) continue;

        final inicioDia = DateTime(hoy.year, hoy.month, hoy.day);

        final inicioDiaString = inicioDia.toIso8601String();

        final alertaExistenteHoy = await supabase
            .from('alertas')
            .select('id')
            .eq('auth_id_destino', user.id)
            .eq('auth_id_origen', authIdAgente)
            .eq('tipo', 'seguimiento_atrasado')
            .gte('created_at', inicioDiaString)
            .maybeSingle();

        if (alertaExistenteHoy != null) continue;

        final nombreAgente =
            "${agente['nombre'] ?? ''} ${agente['apellidos'] ?? ''}".trim();

        await supabase.from('alertas').insert({
          'auth_id_destino': user.id,
          'auth_id_origen': authIdAgente,
          'tipo': 'seguimiento_atrasado',
          'titulo': 'Seguimiento atrasado',
          'mensaje':
              '${nombreAgente.isEmpty ? 'Un agente de tu equipo' : nombreAgente} tiene ${seguimientosAtrasados.length} seguimiento(s) pendiente(s) atrasado(s) más de 3 días. Revisa con él que gestione esas llamadas cuanto antes.',
        });
      }
    } catch (e) {
      debugPrint("ERROR ALERTA SEGUIMIENTO JEFE: $e");
    }
  }

  Future<List<Map<String, dynamic>>> cargarAlertasSistema() async {
    final user = supabase.auth.currentUser;

    if (user == null) {
      return [];
    }

    try {
      final alertas = await supabase
          .from('alertas')
          .select()
          .eq('auth_id_destino', user.id)
          .eq('leida', false)
          .order('created_at', ascending: false);

      final notificaciones = await supabase
          .from('notificaciones')
          .select()
          .eq('usuario_auth_id', user.id)
          .eq('leida', false)
          .order('creado_en', ascending: false);

      final lista = <Map<String, dynamic>>[];

      for (final elemento in alertas) {
        final alerta = Map<String, dynamic>.from(elemento);

        lista.add({
          ...alerta,
          '_tabla': 'alertas',
          '_fecha_orden': alerta['created_at']?.toString(),
          '_mensaje_visible': alerta['mensaje']?.toString() ?? '',
        });
      }

      for (final elemento in notificaciones) {
        final notificacion = Map<String, dynamic>.from(elemento);

        lista.add({
          ...notificacion,
          '_tabla': 'notificaciones',
          '_fecha_orden': notificacion['creado_en']?.toString(),
          '_mensaje_visible': notificacion['mensaje']?.toString() ?? '',
        });
      }

      lista.sort((a, b) {
        final fechaA =
            DateTime.tryParse(a['_fecha_orden']?.toString() ?? '') ??
            DateTime(2000);

        final fechaB =
            DateTime.tryParse(b['_fecha_orden']?.toString() ?? '') ??
            DateTime(2000);

        return fechaB.compareTo(fechaA);
      });

      return lista;
    } catch (error) {
      debugPrint('ERROR CARGAR ALERTAS SISTEMA: $error');

      return [];
    }
  }

  Future<void> _abrirArchivoNotificacion(String? url) async {
    if (url == null || url.trim().isEmpty) return;

    final uri = Uri.tryParse(url.trim());
    if (uri == null) return;

    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Future<void> _openNotificationsPanel() async {
    final alertasSistema = await cargarAlertasSistema();

    if (!mounted) return;

    setState(() {
      systemUnreadCount = alertasSistema.length;
    });

    await showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: const Color(0xFF071A3A).withOpacity(0.28),
      isScrollControlled: true,
      builder: (modalContext) {
        return DraggableScrollableSheet(
          initialChildSize: 0.72,
          minChildSize: 0.38,
          maxChildSize: 0.92,
          expand: false,
          builder: (context, scrollController) {
            return ClipRRect(
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(30),
              ),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.98),
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(30),
                    ),
                    border: Border.all(color: const Color(0xFF9FE3E2)),
                  ),
                  child: SafeArea(
                    top: false,
                    child: ListView(
                      controller: scrollController,
                      padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
                      children: [
                        Center(
                          child: Container(
                            width: 46,
                            height: 5,
                            decoration: BoxDecoration(
                              color: Color(0xFFB7D7DA),
                              borderRadius: BorderRadius.circular(99),
                            ),
                          ),
                        ),

                        const SizedBox(height: 18),

                        const Row(
                          children: [
                            Icon(
                              Icons.notifications_active_rounded,
                              color: Color(0xFF0AAEAE),
                            ),
                            SizedBox(width: 10),
                            Text(
                              "Notificaciones",
                              style: TextStyle(
                                color: Color(0xFF071A3A),
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 18),

                        if (chatUnreadCount > 0)
                          _notificationItem(
                            icon: Icons.chat_bubble_rounded,
                            color: const Color(0xFF22D3EE),
                            title: "Chats pendientes",
                            subtitle:
                                "Tienes $chatUnreadCount mensaje${chatUnreadCount == 1 ? '' : 's'} sin leer",
                            onTap: () async {
                              Navigator.pop(modalContext);

                              await Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const InternalChatScreen(),
                                ),
                              );

                              await loadChatUnreadCount();
                            },
                          ),

                        if (chatUnreadCount > 0 && alertasSistema.isNotEmpty)
                          const SizedBox(height: 12),

                        for (final alerta in alertasSistema) ...[
                          _notificationItem(
                            icon: Icons.warning_amber_rounded,
                            color: const Color(0xFF0A7F91),
                            title: alerta['titulo'] ?? 'Alerta',
                            subtitle:
                                alerta['_mensaje_visible']?.toString() ?? '',
                            onTap: () async {
                              try {
                                final tabla =
                                    alerta['_tabla']?.toString() ?? 'alertas';

                                await supabase
                                    .from(tabla)
                                    .update({'leida': true})
                                    .eq('id', alerta['id']);

                                await loadSystemUnreadCount();

                                if (!mounted) return;

                                Navigator.pop(modalContext);

                                if (alerta['_tabla'] == 'notificaciones') {
                                  final archivoUrl = alerta['archivo_url']
                                      ?.toString();

                                  if (alerta['entidad_tipo'] ==
                                          'incorporacion' &&
                                      alerta['entidad_id'] != null) {
                                    final repo = IncorporacionRepository();
                                    final expediente = await repo.byId(
                                      alerta['entidad_id'].toString(),
                                    );
                                    final profile = await repo.myProfile();
                                    if (!mounted) return;
                                    final role = repo.normalRole(
                                      profile['rol_usuario'],
                                    );
                                    await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => IncorporacionDetail(
                                          expediente: expediente,
                                          admin:
                                              role == 'administracion' ||
                                              role == 'director_nacional',
                                        ),
                                      ),
                                    );
                                  } else if (archivoUrl != null &&
                                      archivoUrl.isNotEmpty) {
                                    await _abrirArchivoNotificacion(archivoUrl);
                                  } else if (alerta['pantalla_destino'] ==
                                          'mis_gestiones' ||
                                      alerta['pantalla_destino'] ==
                                          'gestiones_asignadas') {
                                    await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) =>
                                            const MisGestionesScreen(),
                                      ),
                                    );
                                  }
                                }
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: const Text(
                                      "Aviso marcado como leído",
                                      style: TextStyle(
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                    backgroundColor: const Color(0xFF16A34A),
                                    behavior: SnackBarBehavior.floating,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(14),
                                    ),
                                    duration: const Duration(seconds: 2),
                                  ),
                                );
                              } catch (e) {
                                debugPrint("ERROR MARCANDO ALERTA LEÍDA: $e");
                              }
                            },
                          ),
                          const SizedBox(height: 12),
                        ],

                        if (chatUnreadCount == 0 && alertasSistema.isEmpty)
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(18),
                            decoration: BoxDecoration(
                              color: const Color(0xFFEAF8F8),
                              borderRadius: BorderRadius.circular(22),
                              border: Border.all(
                                color: const Color(0xFFC7ECEC),
                              ),
                            ),
                            child: const Column(
                              children: [
                                Icon(
                                  Icons.mark_chat_read_rounded,
                                  color: Color(0xFF6B8790),
                                  size: 42,
                                ),
                                SizedBox(height: 10),
                                Text(
                                  "No tienes notificaciones pendientes",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Color(0xFF34495E),
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _notificationItem({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: onTap,
        child: Ink(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFFF3FCFC),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: color.withOpacity(0.28)),
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.14),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(icon, color: color),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Color(0xFF071A3A),
                        fontSize: 15.5,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: Color(0xFF53627A),
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded, color: Color(0xFF6B8790)),
            ],
          ),
        ),
      ),
    );
  }

  Future<Map<String, Set<String>>> _obtenerEstructuraCompleta(
    String myAuthId,
  ) async {
    String limpiar(dynamic value) {
      final texto = (value ?? '').toString().trim();
      if (texto.isEmpty || texto.toLowerCase() == 'null') return '';
      return texto;
    }

    final miUsuario = await supabase
        .from('usuarios')
        .select('id, auth_id, parent_id, rol_usuario, nombre, apellidos')
        .or(
          'estado.is.null,estado.not.in.(inactivo,Inactivo,INACTIVO,baja,Baja,BAJA,desactivado,Desactivado,DESACTIVADO,bloqueado,Bloqueado,BLOQUEADO,suspendido,Suspendido,SUSPENDIDO)',
        )
        .eq('auth_id', myAuthId)
        .maybeSingle();

    if (miUsuario == null) {
      debugPrint(
        'HOME ESTRUCTURA: no se encontró el usuario conectado por auth_id.',
      );

      return <String, Set<String>>{
        'ids': <String>{},
        'auth_ids': <String>{myAuthId},
      };
    }

    final rol = limpiar(
      miUsuario['rol_usuario'],
    ).toLowerCase().replaceAll('-', '_').replaceAll(' ', '_');

    if (rol == 'administracion' || rol == 'administrador' || rol == 'admin') {
      final data = await supabase
          .from('usuarios')
          .select('id, auth_id')
          .or(
            'estado.is.null,estado.not.in.(inactivo,Inactivo,INACTIVO,baja,Baja,BAJA,desactivado,Desactivado,DESACTIVADO,bloqueado,Bloqueado,BLOQUEADO,suspendido,Suspendido,SUSPENDIDO)',
          );

      final ids = <String>{};
      final authIds = <String>{myAuthId};

      for (final fila in List<Map<String, dynamic>>.from(data)) {
        final id = limpiar(fila['id']);
        final authId = limpiar(fila['auth_id']);

        if (id.isNotEmpty) ids.add(id);
        if (authId.isNotEmpty) authIds.add(authId);
      }

      return <String, Set<String>>{'ids': ids, 'auth_ids': authIds};
    }

    /*
    RELACIÓN CORRECTA DE LA ESTRUCTURA:

    usuarios.parent_id = usuarios.id del jefe directo.

    Primero recorremos todos los usuarios descendientes utilizando
    exclusivamente los ID internos de la tabla usuarios.

    Después convertimos esos usuarios a auth_id para consultar ventas,
    porque ventas.agente_auth_id = usuarios.auth_id.
  */
    final miId = limpiar(miUsuario['id']);

    final idsEstructura = <String>{miId};
    final authIdsEstructura = <String>{myAuthId};
    final usuariosEstructura = <String, Map<String, dynamic>>{
      miId: Map<String, dynamic>.from(miUsuario),
    };

    var idsPendientes = <String>[miId];

    while (idsPendientes.isNotEmpty) {
      final nuevosPendientes = <String>[];

      const tamanoBloque = 80;

      for (int i = 0; i < idsPendientes.length; i += tamanoBloque) {
        final fin = (i + tamanoBloque < idsPendientes.length)
            ? i + tamanoBloque
            : idsPendientes.length;

        final bloqueIdsJefes = idsPendientes.sublist(i, fin);

        final hijosData = await supabase
            .from('usuarios')
            .select('id, auth_id, parent_id, rol_usuario, nombre, apellidos')
            .or(
              'estado.is.null,estado.not.in.(inactivo,Inactivo,INACTIVO,baja,Baja,BAJA,desactivado,Desactivado,DESACTIVADO,bloqueado,Bloqueado,BLOQUEADO,suspendido,Suspendido,SUSPENDIDO)',
            )
            .inFilter('parent_id', bloqueIdsJefes);

        for (final fila in List<Map<String, dynamic>>.from(hijosData)) {
          final idHijo = limpiar(fila['id']);
          final authIdHijo = limpiar(fila['auth_id']);

          if (idHijo.isEmpty || !idsEstructura.add(idHijo)) {
            continue;
          }

          usuariosEstructura[idHijo] = fila;
          nuevosPendientes.add(idHijo);

          if (authIdHijo.isNotEmpty) {
            authIdsEstructura.add(authIdHijo);
          }
        }
      }

      idsPendientes = nuevosPendientes;
    }

    debugPrint('======= HOME ESTRUCTURA CORRECTA =======');
    debugPrint(
      'USUARIO LOGUEADO: ${miUsuario['nombre']} ${miUsuario['apellidos']}',
    );
    debugPrint('ROL REAL: $rol');
    debugPrint('MI usuarios.id: $miId');
    debugPrint('MI auth_id: $myAuthId');
    debugPrint('IDS INTERNOS ESTRUCTURA: ${idsEstructura.length}');
    debugPrint('AUTH IDS ESTRUCTURA: ${authIdsEstructura.length}');

    for (final usuario in usuariosEstructura.values) {
      debugPrint(
        '- ${usuario['nombre']} ${usuario['apellidos']} '
        '| id=${usuario['id']} '
        '| auth_id=${usuario['auth_id']} '
        '| parent_id=${usuario['parent_id']}',
      );
    }

    debugPrint('========================================');

    return <String, Set<String>>{
      'ids': idsEstructura,
      'auth_ids': authIdsEstructura,
    };
  }

  Future<List<String>> getTeamAuthIds(String myAuthId) async {
    final estructura = await _obtenerEstructuraCompleta(myAuthId);
    return (estructura['auth_ids'] ?? <String>{myAuthId}).toList();
  }

  bool _filaPerteneceAEstructura(
    Map<String, dynamic> fila,
    Set<String> authIds, {
    required List<String> columnas,
  }) {
    for (final columna in columnas) {
      final valor = fila[columna]?.toString().trim() ?? '';
      if (valor.isNotEmpty && authIds.contains(valor)) return true;
    }
    return false;
  }

  bool _filaPerteneceAEstructuraCompleta(
    Map<String, dynamic> fila, {
    required Set<String> authIds,
    required Set<String> idsInternos,
  }) {
    const columnasAuth = <String>[
      'agente_auth_id',
      'auth_id',
      'usuario_auth_id',
      'creado_por_auth_id',
      'created_by_auth_id',
    ];

    const columnasIdInterno = <String>[
      'agente_id',
      'usuario_id',
      'creado_por_id',
      'created_by',
    ];

    for (final columna in columnasAuth) {
      final valor = fila[columna]?.toString().trim() ?? '';
      if (valor.isNotEmpty && authIds.contains(valor)) {
        return true;
      }
    }

    for (final columna in columnasIdInterno) {
      final valor = fila[columna]?.toString().trim() ?? '';
      if (valor.isNotEmpty && idsInternos.contains(valor)) {
        return true;
      }
    }

    return false;
  }

  double _money(dynamic value) {
    if (value == null) return 0.0;
    if (value is num) return value.toDouble();

    final texto = value.toString().trim();
    if (texto.isEmpty) return 0.0;

    final normalizado = texto.contains(',')
        ? texto.replaceAll('.', '').replaceAll(',', '.')
        : texto;

    return double.tryParse(normalizado) ?? 0.0;
  }

  double _primaNetaVenta(Map<String, dynamic> venta) {
    return PremiumWeighting.net(venta);
  }

  bool _esDecesosOVida(Map<String, dynamic> venta) {
    final producto =
        (venta['producto'] ??
                venta['ramo'] ??
                venta['tipo_seguro'] ??
                venta['PRODUCTO'] ??
                venta['RAMO'] ??
                '')
            .toString()
            .trim()
            .toLowerCase()
            .replaceAll('á', 'a')
            .replaceAll('é', 'e')
            .replaceAll('í', 'i')
            .replaceAll('ó', 'o')
            .replaceAll('ú', 'u');

    return producto.contains('deceso') || producto.contains('vida');
  }

  double _objetivoPrimasMensualPorRol(String role) {
    switch (role.trim().toLowerCase()) {
      case 'agente':
        return 4000.0;
      case 'jefe_equipo':
        return 10000.0;
      case 'jefe_ventas':
        return 15000.0;
      case 'director_zona':
        return 25000.0;
      case 'director_nacional':
        return 50000.0;
      case 'administracion':
        return 50000.0;
      default:
        return 4000.0;
    }
  }

  String _formatearEuros(double value, {bool decimales = false}) {
    final absoluto = value.abs();
    final textoBase = decimales
        ? absoluto.toStringAsFixed(2)
        : absoluto.round().toString();

    final partes = textoBase.split('.');
    final entero = partes.first;
    final buffer = StringBuffer();

    for (int i = 0; i < entero.length; i++) {
      if (i > 0 && (entero.length - i) % 3 == 0) {
        buffer.write('.');
      }
      buffer.write(entero[i]);
    }

    final signo = value < 0 ? '-' : '';
    if (decimales) {
      return '$signo${buffer.toString()},${partes.length > 1 ? partes[1] : '00'} €';
    }

    return '$signo${buffer.toString()} €';
  }

  Future<List<Map<String, dynamic>>> _cargarVentasPeriodoPorEstructura({
    required String tabla,
    required String columnaAuthId,
    required List<String> authIds,
    required DateTime inicio,
    required DateTime finExclusivo,
  }) async {
    if (authIds.isEmpty) {
      return <Map<String, dynamic>>[];
    }

    const tamanoBloque = 80;
    const tamanoPagina = 1000;

    final resultadoPorClave = <String, Map<String, dynamic>>{};

    for (int i = 0; i < authIds.length; i += tamanoBloque) {
      final fin = (i + tamanoBloque < authIds.length)
          ? i + tamanoBloque
          : authIds.length;

      final bloque = authIds.sublist(i, fin);
      int desde = 0;

      while (true) {
        final data = await supabase
            .from(tabla)
            .select()
            .inFilter(columnaAuthId, bloque)
            .gte('fecha_efecto', inicio.toIso8601String())
            .lt('fecha_efecto', finExclusivo.toIso8601String())
            .order('fecha_efecto', ascending: true)
            .order('id', ascending: true)
            .range(desde, desde + tamanoPagina - 1);

        final pagina = List<Map<String, dynamic>>.from(data);

        for (final fila in pagina) {
          final clave =
              (fila['id'] ??
                      '${fila[columnaAuthId]}_${fila['fecha_efecto']}_${resultadoPorClave.length}')
                  .toString();

          resultadoPorClave[clave] = fila;
        }

        if (pagina.length < tamanoPagina) {
          break;
        }

        desde += tamanoPagina;
      }
    }

    return resultadoPorClave.values.toList();
  }

  Future<void> loadKpis() async {
    final user = supabase.auth.currentUser;

    if (user == null) return;

    var productionLoaded = false;

    try {
      if (mounted) {
        setState(() => loadingKpis = true);
      }

      /*
        El rol se obtiene directamente del usuario autenticado.
        No dependemos únicamente del valor recibido por el widget.
      */
      final perfilLogueado = await supabase
          .from('usuarios')
          .select('rol_usuario')
          .or(
            'estado.is.null,estado.not.in.(inactivo,Inactivo,INACTIVO,baja,Baja,BAJA,desactivado,Desactivado,DESACTIVADO,bloqueado,Bloqueado,BLOQUEADO,suspendido,Suspendido,SUSPENDIDO)',
          )
          .eq('auth_id', user.id)
          .maybeSingle();

      final rolReal = (perfilLogueado?['rol_usuario'] ?? widget.role)
          .toString()
          .trim()
          .toLowerCase()
          .replaceAll('-', '_')
          .replaceAll(' ', '_');

      /*
        La estructura se calcula siempre desde el usuario conectado,
        recorriendo únicamente sus descendientes mediante parent_id.
      */
      final estructura = await _obtenerEstructuraCompleta(user.id);
      final authIdsSet = estructura['auth_ids'] ?? <String>{user.id};
      final idsInternosSet = estructura['ids'] ?? <String>{};
      final authIds = authIdsSet.toList();

      /*
        CARGO MENSUAL CONFIGURADO:
        se respetan fecha_desde y fecha_hasta de cierres_produccion.
        La producción se asigna exclusivamente por fecha_efecto.
      */
      final periodoProduccion = await ProductionPeriodService.instance.current(
        forceRefresh: true,
      );
      final inicioMes = periodoProduccion.start;
      final finMesExclusivo = periodoProduccion.endExclusive;

      /*
        VENTAS:
        ventas.agente_auth_id = usuarios.auth_id.

        Se consulta directamente por todos los auth_id de la estructura.
        No se descargan ventas ajenas para filtrarlas después.
      */
      final ventasMesData = await _cargarVentasPeriodoPorEstructura(
        tabla: 'ventas',
        columnaAuthId: 'agente_auth_id',
        authIds: authIds,
        inicio: inicioMes,
        finExclusivo: finMesExclusivo,
      );

      final ventasProductivasMes = ventasMesData
          .where(_esVentaProductiva)
          .toList();

      final primasNetasMes = ventasProductivasMes.fold<double>(
        0.0,
        (total, venta) => total + _primaNetaVenta(venta),
      );

      final primasDecesosVidaMes = ventasProductivasMes
          .where(_esDecesosOVida)
          .fold<double>(0.0, (total, venta) => total + _primaNetaVenta(venta));

      final objetivoPrimasMes = _objetivoPrimasMensualPorRol(rolReal);

      // Mostrar la producción sin esperar al ranking ni a la racha histórica.
      if (!mounted) return;
      setState(() {
        totalVentas = ventasProductivasMes.length;
        rolUsuarioLogueado = rolReal;
        objetivoMes = objetivoPrimasMes;
        primasMes = primasNetasMes;
        primasMixMes = primasDecesosVidaMes;
        _kpiLoadFailed = false;
        _cargoDescription =
            'Efecto: ${inicioMes.day}/${inicioMes.month}/${inicioMes.year}'
            ' – ${periodoProduccion.to.day}/${periodoProduccion.to.month}/${periodoProduccion.to.year}';
        loadingKpis = false;
      });
      productionLoaded = true;
      debugPrint(
        'HOME CARGO ${periodoProduccion.key}: $inicioMes hasta $finMesExclusivo (exclusivo), '
        'configurado=${periodoProduccion.configured}, polizas=${ventasMesData.length}, '
        'productivas=${ventasProductivasMes.length}, primas=$primasNetasMes',
      );

      /*
        Las tareas se mantienen con el filtrado por estructura porque
        no forman parte del cálculo mensual de primas.
      */
      List<Map<String, dynamic>> tareas = [];

      try {
        final tareasData = await supabase.from('tareas').select();
        tareas = List<Map<String, dynamic>>.from(tareasData)
            .where(
              (tarea) => _filaPerteneceAEstructura(
                tarea,
                authIdsSet,
                columnas: const [
                  'auth_id',
                  'agente_auth_id',
                  'usuario_auth_id',
                  'asignado_auth_id',
                ],
              ),
            )
            .toList();
      } catch (e) {
        debugPrint("AVISO TAREAS HOME: $e");
        tareas = [];
      }

      final tareasPendientes = tareas
          .map((t) => Map<String, dynamic>.from(t))
          .where(_tareaPendiente)
          .toList();

      final ranking = await HomeRankingService.load(
        supabase,
        user.id,
        onError: (error) =>
            debugPrint('AVISO RANKING HOME (primas conservadas): $error'),
      );

      final racha = await calcularRachaMensual(authIds, objetivoPrimasMes);

      debugPrint("========== HOME KPI FECHA_EFECTO ==========");
      debugPrint("ROL REAL: $rolReal");
      debugPrint("IDS INTERNOS ESTRUCTURA: ${idsInternosSet.length}");
      debugPrint("AUTH IDS ESTRUCTURA: ${authIds.length}");
      debugPrint(
        "VENTAS MES CONSULTADAS POR agente_auth_id: ${ventasMesData.length}",
      );
      debugPrint("VENTAS MES ESTRUCTURA: ${ventasMesData.length}");
      debugPrint(
        "VENTAS PRODUCTIVAS MES POR FECHA EFECTO: "
        "${ventasProductivasMes.length}",
      );
      debugPrint("PRIMAS MES FECHA EFECTO: $primasNetasMes");
      debugPrint("=========================================");

      if (!mounted) return;

      setState(() {
        totalVentas = ventasProductivasMes.length;
        totalTareas = tareasPendientes.length;

        rolUsuarioLogueado = rolReal;
        objetivoMes = objetivoPrimasMes;
        primasMes = primasNetasMes;
        primasMixMes = primasDecesosVidaMes;

        rankingPosicion = ranking.position;
        rankingTotal = ranking.total;
        rankingPrimero = ranking.first;
        misPolizasTotales = ranking.ownPolicies;

        rachaMeses = racha;
        loadingKpis = false;
      });
    } catch (e, stackTrace) {
      debugPrint("ERROR KPI HOME: $e");
      debugPrint("$stackTrace");

      if (!mounted) return;

      setState(() {
        if (productionLoaded) {
          loadingKpis = false;
          return;
        }
        _kpiLoadFailed = true;
        totalVentas = 0;
        totalTareas = 0;

        primasMes = 0.0;
        primasMixMes = 0.0;
        rachaMeses = 0;
        objetivoMes = _objetivoPrimasMensualPorRol(
          rolUsuarioLogueado.isNotEmpty ? rolUsuarioLogueado : widget.role,
        );

        rankingPosicion = 0;
        rankingTotal = 0;
        rankingPrimero = 0;
        misPolizasTotales = 0;

        loadingKpis = false;
      });
    }
  }

  Future<int> calcularRachaMensual(
    List<String> authIds,
    double objetivoPrimas,
  ) async {
    try {
      final ventasData = await supabase
          .from('ventas')
          .select()
          .inFilter('agente_auth_id', authIds);

      final ventas = ventasData
          .map((v) => Map<String, dynamic>.from(v))
          .where(_esVentaProductiva)
          .toList();

      int racha = 0;
      var periodo = await ProductionPeriodService.instance.current();

      while (true) {
        double primasMesCheck = 0.0;

        for (final venta in ventas) {
          final fecha = _fechaEfecto(venta);

          if (fecha == null) continue;

          final limpia = DateTime(fecha.year, fecha.month, fecha.day);

          final perteneceMes =
              !limpia.isBefore(periodo.start) &&
              limpia.isBefore(periodo.endExclusive);

          if (perteneceMes) {
            primasMesCheck += _primaNetaVenta(venta);
          }
        }

        if (primasMesCheck >= objetivoPrimas) {
          racha++;
          final mesAnterior = DateTime(periodo.year, periodo.month - 1, 1);
          periodo = await ProductionPeriodService.instance.forMonth(
            year: mesAnterior.year,
            month: mesAnterior.month,
          );
        } else {
          break;
        }
      }

      return racha;
    } catch (e) {
      debugPrint('ERROR RACHA MENSUAL POR FECHA_EFECTO: $e');
      return 0;
    }
  }

  Future<void> checkForUpdate() async {
    if (_checkingUpdate) return;

    _checkingUpdate = true;

    try {
      final update = await UpdateService.checkUpdate();

      if (update == null) return;

      final remoteVersion = UpdateService.getPlatformUpdateVersion(update);

      final url = UpdateService.getPlatformUpdateUrl(update);

      if (remoteVersion.isEmpty) {
        debugPrint('UPDATE: el registro activo no tiene versión.');
        return;
      }

      // Las actualizaciones automáticas mediante app_versions solo se
      // gestionan en Android y Windows. En iOS se distribuyen por TestFlight
      // o App Store, por lo que nunca mostramos un diálogo sin acción.
      if (url == null || url.trim().isEmpty) {
        return;
      }

      final hasUpdate = await UpdateService.isUpdateAvailable(remoteVersion);

      if (!mounted) return;

      if (!hasUpdate || _updateDialogShown) return;

      _updateDialogShown = true;
      final isWindows =
          !kIsWeb && defaultTargetPlatform == TargetPlatform.windows;

      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) {
          var downloading = false;
          var openingInstaller = false;
          double? progress;
          String? downloadError;

          return StatefulBuilder(
            builder: (context, setDialogState) {
              final progressPercent = progress == null
                  ? null
                  : (progress! * 100).clamp(0, 100).round();

              return AlertDialog(
                backgroundColor: Colors.white,
                surfaceTintColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(26),
                ),
                title: const Row(
                  children: [
                    DecoratedBox(
                      decoration: BoxDecoration(
                        color: Color(0xFFEAF0FF),
                        shape: BoxShape.circle,
                      ),
                      child: Padding(
                        padding: EdgeInsets.all(10),
                        child: Icon(
                          Icons.system_update_rounded,
                          color: Color(0xFF2454D3),
                        ),
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Actualización disponible',
                        style: TextStyle(
                          color: Color(0xFF071A3A),
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ],
                ),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      openingInstaller
                          ? isWindows
                                ? 'Descarga completada. Aplicando la actualización de Windows…'
                                : 'Descarga completada. Abriendo el instalador de Android…'
                          : downloading
                          ? isWindows && progressPercent == 100
                                ? 'Preparando la actualización. Acepta el permiso de Windows si aparece.'
                                : progressPercent == null
                                ? 'Preparando la descarga segura…'
                                : 'Descargando SafeBrok… ' +
                                      progressPercent.toString() +
                                      '%'
                          : 'Hay una nueva versión de SafeBrok. '
                                'Pulsa actualizar para descargarla e instalarla.',
                      style: const TextStyle(
                        color: Color(0xFF53627A),
                        fontSize: 14,
                        height: 1.4,
                      ),
                    ),
                    if (downloading || openingInstaller) ...[
                      const SizedBox(height: 18),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(99),
                        child: LinearProgressIndicator(
                          value: openingInstaller ? 1 : progress,
                          minHeight: 10,
                          backgroundColor: const Color(0xFFE2E8F0),
                          color: const Color(0xFF2454D3),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        openingInstaller
                            ? isWindows
                                  ? 'Instalador de Windows verificado'
                                  : 'APK verificada correctamente'
                            : 'No cierres SafeBrok durante la descarga',
                        style: const TextStyle(
                          color: Color(0xFF64748B),
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                    if (downloadError != null) ...[
                      const SizedBox(height: 16),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFF1F2),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: const Color(0xFFFECACA)),
                        ),
                        child: Text(
                          downloadError!,
                          style: const TextStyle(
                            color: Color(0xFFB91C1C),
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            height: 1.35,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
                actions: [
                  if (downloadError != null)
                    TextButton.icon(
                      onPressed: () async {
                        try {
                          await UpdateService.openUpdateExternally(url.trim());
                        } catch (e) {
                          if (!dialogContext.mounted) return;
                          setDialogState(() {
                            downloadError = e.toString().replaceFirst(
                              'Exception: ',
                              '',
                            );
                          });
                        }
                      },
                      icon: const Icon(Icons.open_in_browser_rounded),
                      label: const Text('Abrir en navegador'),
                    ),
                  FilledButton.icon(
                    onPressed: downloading || openingInstaller
                        ? null
                        : () async {
                            setDialogState(() {
                              downloading = true;
                              openingInstaller = false;
                              progress = null;
                              downloadError = null;
                            });

                            try {
                              await UpdateService.downloadAndInstall(
                                url.trim(),
                                onProgress: (received, total) {
                                  if (!dialogContext.mounted || total <= 0) {
                                    return;
                                  }

                                  setDialogState(() {
                                    progress = (received / total).clamp(
                                      0.0,
                                      1.0,
                                    );
                                  });
                                },
                              );

                              if (!dialogContext.mounted) return;

                              setDialogState(() {
                                downloading = false;
                                openingInstaller = true;
                                progress = 1;
                              });
                            } catch (e) {
                              debugPrint('ERROR INSTALANDO ACTUALIZACIÓN: $e');

                              if (!dialogContext.mounted) return;

                              setDialogState(() {
                                downloading = false;
                                openingInstaller = false;
                                downloadError = e.toString().replaceFirst(
                                  'Exception: ',
                                  '',
                                );
                              });
                            }
                          },
                    icon: downloading
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.download_rounded),
                    label: Text(
                      downloadError == null ? 'Actualizar ahora' : 'Reintentar',
                    ),
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFF2454D3),
                      foregroundColor: Colors.white,
                      disabledBackgroundColor: const Color(0xFF94A3B8),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 18,
                        vertical: 13,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                  ),
                ],
              );
            },
          );
        },
      );
    } catch (e) {
      debugPrint('ERROR UPDATE CHECK: $e');
    } finally {
      _checkingUpdate = false;
    }
  }

  double get produccionPorcentaje {
    if (objetivoMes == 0) return 0;

    final value = primasMes / objetivoMes;

    if (value.isNaN || value.isInfinite) return 0;

    return value.clamp(0.0, 1.0);
  }

  int get produccionTexto {
    return (produccionPorcentaje * 100).round();
  }

  DateTime? _fechaEfecto(Map<String, dynamic> row) {
    final value = row['fecha_efecto'];

    if (value == null) return null;

    if (value is DateTime) {
      return value.toLocal();
    }

    final parsed = DateTime.tryParse(value.toString());

    return parsed?.toLocal();
  }

  bool _esVentaProductiva(Map<String, dynamic> venta) {
    final textos = <String>[
      venta['estado']?.toString() ?? '',
      venta['estado_poliza']?.toString() ?? '',
      venta['tipo']?.toString() ?? '',
      venta['tipo_movimiento']?.toString() ?? '',
      venta['situacion']?.toString() ?? '',
    ].join(' ').toLowerCase().trim();

    const estadosNoProductivos = <String>[
      'baja',
      'extorno',
      'anulada',
      'anulado',
      'anulacion',
      'anulación',
      'cancelada',
      'cancelado',
    ];

    for (final estado in estadosNoProductivos) {
      if (textos.contains(estado)) {
        return false;
      }
    }

    return true;
  }

  bool _tareaPendiente(Map<String, dynamic> tarea) {
    final estado =
        (tarea['estado'] ??
                tarea['status'] ??
                tarea['ESTADO'] ??
                tarea['STATUS'] ??
                '')
            .toString()
            .toLowerCase()
            .trim();

    final completada =
        tarea['completada'] ??
        tarea['finalizada'] ??
        tarea['is_done'] ??
        tarea['done'];

    if (completada == true) return false;

    if (estado.contains('completada') ||
        estado.contains('finalizada') ||
        estado.contains('hecha') ||
        estado.contains('cerrada')) {
      return false;
    }

    return true;
  }

  String get _rolActivo {
    final rol = rolUsuarioLogueado.isNotEmpty
        ? rolUsuarioLogueado
        : widget.role;

    return AppRole.normalize(rol);
  }

  @override
  Widget build(BuildContext context) {
    final rolActivo = _rolActivo;
    final items = _getDashboardItems(rolActivo, context);
    final isWide = MediaQuery.of(context).size.width > 700;

    return Scaffold(
      backgroundColor: const Color(0xFFF2FCFD),
      extendBody: true,
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton:
          rolActivo == 'director_nacional' || rolActivo == 'administracion'
          ? null
          : Padding(
              padding: const EdgeInsets.only(bottom: 76),
              child: _bigSaleButton(),
            ),
      body: Stack(
        children: [
          _background(),
          SafeArea(
            child: RefreshIndicator(
              onRefresh: loadKpis,
              color: const Color(0xFF22D3EE),
              backgroundColor: const Color(0xFF071A3A),
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: EdgeInsets.fromLTRB(
                  isWide ? 42 : 20,
                  20,
                  isWide ? 42 : 20,
                  130,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _topBar(),
                    const SizedBox(height: 22),
                    _hero(),
                    const SizedBox(height: 24),
                    _sectionTitle(
                      "Tu rendimiento en el cargo actual",
                      Icons.trending_up_rounded,
                    ),
                    const SizedBox(height: 14),
                    _kpiGrid(isWide),
                    const SizedBox(height: 18),
                    if (!AppRole.hasNationalAccess(rolActivo)) ...[
                      _goalAndStreak(),
                      const SizedBox(height: 20),
                      _rankingCard(),
                      const SizedBox(height: 26),
                    ] else ...[
                      _dailyGoalCard(),
                      const SizedBox(height: 26),
                    ],
                    _sectionTitle("Accesos rápidos", Icons.flash_on_rounded),
                    const SizedBox(height: 14),
                    _moduleGrid(items, isWide),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _background() {
    return Stack(
      children: [
        Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFF4FDFE), Color(0xFFDDF8FA), Color(0xFFF7FBFF)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        Positioned(
          top: -90,
          right: -80,
          child: _glow(const Color(0xFF14B8B3), 300),
        ),
        Positioned(
          top: 260,
          right: -120,
          child: _glow(const Color(0xFF36D6E5), 320),
        ),
        Positioned(
          bottom: -90,
          left: -80,
          child: _glow(const Color(0xFF22D3EE), 240),
        ),
        BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 36, sigmaY: 36),
          child: Container(color: Colors.white.withOpacity(0.05)),
        ),
      ],
    );
  }

  Widget _glow(Color color, double size) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [
            color.withOpacity(0.34),
            color.withOpacity(0.10),
            Colors.transparent,
          ],
        ),
      ),
    );
  }

  Widget _topBar() {
    final totalNotifications = chatUnreadCount + systemUnreadCount;

    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 560;
        return Container(
          width: double.infinity,
          height: compact ? 82 : 96,
          padding: EdgeInsets.symmetric(
            horizontal: compact ? 12 : 22,
            vertical: 8,
          ),
          decoration: BoxDecoration(
            color: const Color(0xFF2A3143),
            borderRadius: BorderRadius.circular(26),
            border: Border.all(
              color: const Color(0xFF20C7C2).withOpacity(0.62),
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF071A3A).withOpacity(0.16),
                blurRadius: 28,
                offset: const Offset(0, 11),
              ),
              BoxShadow(
                color: const Color(0xFF0AAEAE).withOpacity(0.13),
                blurRadius: 20,
              ),
            ],
          ),
          child: Row(
            children: [
              SizedBox(
                width: compact ? 145 : 195,
                child: Image.asset(
                  'assets/images/logo.png',
                  fit: BoxFit.contain,
                ),
              ),
              if (!compact) ...[
                Container(
                  width: 1,
                  height: 42,
                  margin: const EdgeInsets.symmetric(horizontal: 20),
                  color: const Color(0xFF20C7C2).withOpacity(0.45),
                ),
                const Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'PLATAFORMA COMERCIAL',
                        style: TextStyle(
                          color: Color(0xFF45D8D1),
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Todo el negocio, en un solo lugar',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: Color(0xFFE7F8F8),
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ] else
                const Spacer(),
              const SizedBox(width: 14),
              Stack(
                clipBehavior: Clip.none,
                children: [
                  IconButton(
                    onPressed: _openNotificationsPanel,
                    icon: const Icon(
                      Icons.notifications_none_rounded,
                      color: Color(0xFF071A3A),
                      size: 29,
                    ),
                    style: IconButton.styleFrom(
                      backgroundColor: const Color(0xFFF1FFFF),
                      fixedSize: const Size(56, 56),
                      side: const BorderSide(
                        color: Color(0xFF45D8D1),
                        width: 1.5,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18),
                      ),
                    ),
                  ),
                  if (totalNotifications > 0)
                    Positioned(
                      right: -4,
                      top: -6,
                      child: Container(
                        constraints: const BoxConstraints(
                          minWidth: 24,
                          minHeight: 24,
                        ),
                        padding: const EdgeInsets.symmetric(horizontal: 6),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE74646),
                          borderRadius: BorderRadius.circular(99),
                          border: Border.all(
                            color: const Color(0xFF2A3143),
                            width: 2,
                          ),
                        ),
                        child: Center(
                          child: Text(
                            totalNotifications > 99
                                ? '+99'
                                : totalNotifications.toString(),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _hero() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(2),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        color: const Color(0xFF52D2CF).withOpacity(0.24),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0AAEAE).withOpacity(0.10),
            blurRadius: 30,
            offset: const Offset(0, 14),
          ),
        ],
      ),
      child: Container(
        constraints: const BoxConstraints(minHeight: 250),
        padding: const EdgeInsets.all(28),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: const LinearGradient(
            colors: [Color(0xFFFFFFFF), Color(0xFFEAFBFC), Color(0xFFD9F6F8)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              right: 8,
              top: 4,
              child: Icon(
                Icons.rocket_launch_rounded,
                color: const Color(0xFF0AAEAE).withOpacity(0.14),
                size: 160,
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  fraseDelDia[0],
                  style: const TextStyle(
                    color: Color(0xFF071A3A),
                    fontSize: 31,
                    fontWeight: FontWeight.w900,
                    height: 1.05,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  "${fraseDelDia[1]} 🚀",
                  style: const TextStyle(
                    color: Color(0xFF0AAEAE),
                    fontSize: 29,
                    fontWeight: FontWeight.w900,
                    height: 1.05,
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    const Icon(
                      Icons.person_pin_rounded,
                      color: Color(0xFF0AAEAE),
                      size: 22,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        _roleTitle(_rolActivo),
                        style: const TextStyle(
                          color: Color(0xFF075D68),
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                const ProductionCountdown(),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String title, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: const Color(0xFF22D3EE), size: 22),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(
            color: Color(0xFF071A3A),
            fontSize: 20,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }

  Widget _kpiGrid(bool isWide) {
    if (_kpiLoadFailed) {
      return Column(
        children: [
          const Text(
            'No se ha podido cargar la producción del cargo. No es un importe de 0 €.',
          ),
          TextButton.icon(
            onPressed: loadingKpis ? null : loadKpis,
            icon: const Icon(Icons.refresh),
            label: const Text('Reintentar'),
          ),
        ],
      );
    }
    final cards = [
      _metricCard(
        title: "Primas del mes",
        value: _formatearEuros(primasMes),
        subtitle: _cargoDescription,
        icon: Icons.euro_rounded,
        color: const Color(0xFF0A7F91),
      ),
      _metricCard(
        title: "Mix del mes",
        value: _formatearEuros(primasMixMes),
        subtitle:
            "Decesos + Vida · ${primasMes > 0 ? ((primasMixMes / primasMes) * 100).toStringAsFixed(1) : '0.0'}% del total",
        icon: Icons.pie_chart_rounded,
        color: const Color(0xFF10AAA6),
      ),
      _metricCard(
        title: "Pendientes",
        value: "$totalTareas",
        subtitle: "tareas",
        icon: Icons.assignment_rounded,
        color: const Color(0xFF0A7F91),
      ),
      _productionMetricCard(),
    ];

    return GridView.count(
      crossAxisCount: isWide ? 4 : 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 14,
      crossAxisSpacing: 14,
      childAspectRatio: isWide ? 1.02 : 0.66,
      children: cards,
    );
  }

  Widget _metricCard({
    required String title,
    required String value,
    required String subtitle,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _premiumCard(color),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _iconBubble(icon, color),
          const Spacer(),
          Text(
            title,
            style: const TextStyle(
              color: Color(0xFF071A3A),
              fontSize: 16,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            loadingKpis ? "..." : value,
            style: const TextStyle(
              color: Color(0xFF071A3A),
              fontSize: 38,
              fontWeight: FontWeight.w900,
              height: 1,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            style: TextStyle(
              color: color == const Color(0xFF0A7F91)
                  ? const Color(0xFF53627A)
                  : const Color(0xFF0AAEAE),
              fontSize: 14,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 10),
          _miniSparkline(color),
        ],
      ),
    );
  }

  Widget _productionMetricCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _premiumCard(const Color(0xFF10AAA6)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _iconBubble(Icons.track_changes_rounded, const Color(0xFF10AAA6)),
          const Spacer(),
          const Text(
            "Producción",
            style: TextStyle(
              color: Color(0xFF071A3A),
              fontSize: 16,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            "$produccionTexto%",
            style: const TextStyle(
              color: Color(0xFF071A3A),
              fontSize: 38,
              fontWeight: FontWeight.w900,
              height: 1,
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            "del objetivo mensual",
            style: TextStyle(
              color: Color(0xFF64748B),
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _goalAndStreak() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isNarrow = constraints.maxWidth < 430;

        if (isNarrow) {
          return Column(
            children: [
              _dailyGoalCard(),
              const SizedBox(height: 14),
              _streakCard(),
            ],
          );
        }

        return Row(
          children: [
            Expanded(child: _dailyGoalCard()),
            const SizedBox(width: 14),
            Expanded(child: _streakCard()),
          ],
        );
      },
    );
  }

  Widget _dailyGoalCard() {
    final conseguido = primasMes > objetivoMes ? objetivoMes : primasMes;

    final quedan = (objetivoMes - conseguido)
        .clamp(0.0, objetivoMes)
        .toDouble();

    final progreso = objetivoMes == 0 ? 0.0 : conseguido / objetivoMes;

    return Container(
      height: 230,
      padding: const EdgeInsets.all(18),
      decoration: _premiumCard(const Color(0xFF0AAEAE)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.track_changes_rounded, color: Color(0xFF0AAEAE)),
              SizedBox(width: 8),
              Text(
                "OBJETIVO DEL MES",
                style: TextStyle(
                  color: Color(0xFF087F86),
                  fontWeight: FontWeight.w900,
                  fontSize: 14,
                ),
              ),
            ],
          ),
          const Spacer(),
          Text(
            _formatearEuros(objetivoMes),
            style: const TextStyle(
              color: Color(0xFF071A3A),
              fontSize: 28,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(99),
            child: LinearProgressIndicator(
              value: progreso,
              minHeight: 9,
              backgroundColor: const Color(0xFFE2E8F0),
              color: const Color(0xFF0AAEAE),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _goalMini(
                "Has conseguido",
                _formatearEuros(primasMes),
                const Color(0xFF0AAEAE),
              ),
              Container(width: 1, height: 30, color: const Color(0xFFE2E8F0)),
              _goalMini(
                "Te quedan",
                _formatearEuros(quedan),
                const Color(0xFF071A3A),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _goalMini(String label, String value, Color color) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Color(0xFF64748B),
              fontSize: 13,
              fontWeight: FontWeight.w700,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 30,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  Widget _streakCard() {
    final textoMes = rachaMeses == 1 ? "mes" : "meses";

    return Container(
      height: 230,
      padding: const EdgeInsets.all(18),
      decoration: _premiumCard(const Color(0xFF0A7F91)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(
                Icons.local_fire_department_rounded,
                color: Color(0xFF0AAEAE),
              ),
              SizedBox(width: 8),
              Text(
                "RACHA ACTUAL",
                style: TextStyle(
                  color: Color(0xFF087F86),
                  fontWeight: FontWeight.w900,
                  fontSize: 14,
                ),
              ),
            ],
          ),
          const Spacer(),
          Text(
            "$rachaMeses $textoMes",
            style: const TextStyle(
              color: Color(0xFF071A3A),
              fontSize: 36,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            "cumpliendo objetivos",
            style: TextStyle(
              color: Color(0xFF64748B),
              fontSize: 16,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            rachaMeses == 0
                ? "🔥"
                : List.filled(rachaMeses.clamp(1, 6), "🔥").join(" "),
            style: const TextStyle(fontSize: 20),
          ),
        ],
      ),
    );
  }

  Widget _rankingCard() {
    final sinUsuarios = rankingTotal == 0 || rankingPosicion == 0;

    final diferenciaPrimero = rankingPrimero - misPolizasTotales;

    final progreso = rankingPrimero == 0
        ? 0.0
        : (misPolizasTotales / rankingPrimero).clamp(0.0, 1.0);

    String mensaje;

    if (sinUsuarios) {
      mensaje = "Ranking pendiente de cargar";
    } else if (rankingPosicion == 1) {
      mensaje = "Vas liderando el ranking";
    } else if (diferenciaPrimero <= 0) {
      mensaje = "Empatado con el primero";
    } else if (rankingPosicion <= 3) {
      mensaje = "Estás en el podio, a $diferenciaPrimero pólizas del primero";
    } else {
      mensaje = "Estás a $diferenciaPrimero pólizas del primero";
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: _premiumCard(const Color(0xFF0A7F91)),
      child: Row(
        children: [
          Container(
            width: 82,
            height: 82,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFFFB020), Color(0xFF0AAEAE)],
              ),
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF10AAA6).withOpacity(0.28),
                  blurRadius: 20,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: const Icon(
              Icons.emoji_events_rounded,
              color: Color(0xFF071A3A),
              size: 44,
            ),
          ),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "TU POSICIÓN",
                style: TextStyle(
                  color: Color(0xFF53627A),
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                ),
              ),
              Text(
                sinUsuarios ? "—" : "#$rankingPosicion",
                style: const TextStyle(
                  color: Color(0xFF071A3A),
                  fontSize: 48,
                  fontWeight: FontWeight.w900,
                  height: 1,
                ),
              ),
              Text(
                sinUsuarios ? "cargando" : "de $rankingTotal",
                style: const TextStyle(
                  color: Color(0xFF53627A),
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Ranking de toda la compañía",
                  style: TextStyle(
                    color: Color(0xFF071A3A),
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  "$misPolizasTotales pólizas emitidas",
                  style: const TextStyle(
                    color: Color(0xFF53627A),
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 12),
                ClipRRect(
                  borderRadius: BorderRadius.circular(99),
                  child: LinearProgressIndicator(
                    value: progreso,
                    minHeight: 9,
                    backgroundColor: const Color(0xFFE2E8F0),
                    color: const Color(0xFF0AAEAE),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  mensaje,
                  style: const TextStyle(
                    color: Color(0xFF64748B),
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _moduleGrid(List<DashboardItem> items, bool isWide) {
    final allItems = [
      DashboardItem(
        title: 'Avant2',
        icon: Icons.open_in_browser_rounded,
        subtitle: 'Acceso al portal Avant2',
        color: const Color(0xFF087F86),
        onTap: () => openAvant2(context),
      ),
      DashboardItem(
        title: 'Cotizaciones',
        icon: Icons.calculate_outlined,
        subtitle: 'Compañías, portales y ejecutivos',
        color: const Color(0xFF087F86),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute<void>(builder: (_) => const CotizacionesScreen()),
        ),
      ),
      DashboardItem(
        title: "Nueva venta",
        icon: Icons.add_rounded,
        subtitle: "Crear oportunidad",
        color: const Color(0xFF0A7F91),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const CreateSaleWizard()),
          );
        },
      ),

      DashboardItem(
        title: "Safebrok IA",
        icon: Icons.auto_awesome_rounded,
        subtitle: "Asistente inteligente",
        color: const Color(0xFF0AAEAE),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const SafebrokAiScreen()),
          );
        },
      ),

      DashboardItem(
        title: "Previsiones",
        icon: Icons.insights_rounded,
        subtitle: "Plan mensual y avance",
        color: const Color(0xFF0A7F91),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => PrevisionesScreen(
                role: rolUsuarioLogueado.isNotEmpty
                    ? rolUsuarioLogueado
                    : widget.role,
              ),
            ),
          );
        },
      ),

      DashboardItem(
        title: "Mis gestiones",
        icon: Icons.assignment_turned_in_rounded,
        subtitle: "Gestiones asignadas",
        color: const Color(0xFF0A7F91),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const MisGestionesScreen()),
          );
        },
      ),

      ...items,
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: allItems.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: isWide ? 3 : 2,
        crossAxisSpacing: 14,
        mainAxisSpacing: 14,
        childAspectRatio: isWide ? 1.25 : 0.82,
      ),
      itemBuilder: (context, index) {
        final item = allItems[index];
        return _moduleCard(item);
      },
    );
  }

  Widget _moduleCard(DashboardItem item) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: item.onTap,
        borderRadius: BorderRadius.circular(24),
        splashColor: item.color.withOpacity(0.18),
        highlightColor: item.color.withOpacity(0.08),
        child: Ink(
          padding: const EdgeInsets.all(16),
          decoration: _premiumCard(item.color),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  _iconBubble(item.icon, item.color, size: 54),
                  const Spacer(),
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: item.color.withOpacity(0.14),
                      shape: BoxShape.circle,
                      border: Border.all(color: item.color.withOpacity(0.25)),
                    ),
                    child: const Icon(
                      Icons.chevron_right_rounded,
                      color: Color(0xFF071A3A),
                      size: 23,
                    ),
                  ),
                ],
              ),

              const Spacer(),

              Text(
                item.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Color(0xFF071A3A),
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  height: 1.10,
                ),
              ),

              const SizedBox(height: 6),

              Text(
                item.subtitle,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Color(0xFF64748B),
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _bigSaleButton() {
    return Container(
      width: 88,
      height: 88,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          colors: [Color(0xFF0AAEAE), Color(0xFF2563EB), Color(0xFF7C3AED)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0AAEAE).withOpacity(0.50),
            blurRadius: 30,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: FloatingActionButton(
        elevation: 0,
        backgroundColor: Colors.transparent,
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const CreateSaleWizard()),
          );
        },
        child: const Icon(Icons.add_rounded, color: Colors.white, size: 46),
      ),
    );
  }

  Widget _iconBubble(IconData icon, Color color, {double size = 44}) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF18C3BD), Color(0xFF087F8D)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(size * 0.30),
        border: Border.all(color: const Color(0xFF9FE3E2)),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0AAEAE).withOpacity(0.16),
            blurRadius: 14,
            offset: const Offset(0, 7),
          ),
        ],
      ),
      child: Icon(icon, color: Colors.white, size: size * 0.52),
    );
  }

  Widget _miniSparkline(Color color) {
    return SizedBox(
      height: 22,
      child: CustomPaint(
        painter: _SparklinePainter(color),
        child: const SizedBox.expand(),
      ),
    );
  }

  BoxDecoration _premiumCard(Color color) {
    return BoxDecoration(
      color: Colors.white.withOpacity(0.96),
      borderRadius: BorderRadius.circular(24),
      border: Border.all(color: const Color(0xFFC7ECEC)),
      boxShadow: [
        BoxShadow(
          color: const Color(0xFF071A3A).withOpacity(0.065),
          blurRadius: 22,
          offset: const Offset(0, 9),
        ),
      ],
    );
  }

  DashboardItem _annualCommercialPlanItem(BuildContext context) {
    return DashboardItem(
      title: 'Plan Comercial Anual',
      subtitle: 'Objetivos & Performance',
      icon: Icons.track_changes_rounded,
      color: const Color(0xFF0EA5A4),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const PlanComercialAnualScreen()),
        );
      },
    );
  }

  List<DashboardItem> _getDashboardItems(String role, BuildContext context) {
    switch (AppRole.normalize(role)) {
      case 'administracion':
      case 'director_nacional':
        return [
          _annualCommercialPlanItem(context),
          DashboardItem(
            title: "KPIs Globales",
            subtitle: "Toda la compañía",
            icon: Icons.bar_chart_rounded,
            color: const Color(0xFF22D3EE),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const DirectorNacionalKpisScreen(),
                ),
              );
            },
          ),
          DashboardItem(
            title: "Rendimiento comercial",
            subtitle: "Primas y mix por estructura",
            icon: Icons.groups_rounded,
            color: const Color(0xFF14B8A6),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const MisEquiposJefeVentasScreen(),
                ),
              );
            },
          ),
          DashboardItem(
            title: "Cuadro de mandos",
            subtitle: "Gobierno comercial",
            icon: Icons.admin_panel_settings_rounded,
            color: const Color(0xFF0284C7),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const CuadroMandosScreen()),
              );
            },
          ),
          DashboardItem(
            title: "Ventas Totales",
            subtitle: "Producción global",
            icon: Icons.euro_rounded,
            color: const Color(0xFF22C55E),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const MySalesScreen()),
              );
            },
          ),
          DashboardItem(
            title: "Clientes Globales",
            subtitle: "Cartera completa",
            icon: Icons.person_search_rounded,
            color: const Color(0xFF8B5CF6),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const MyClientsScreen()),
              );
            },
          ),
          DashboardItem(
            title: "Recibos",
            subtitle: "Gestión de cobros",
            icon: Icons.receipt_long_rounded,
            color: const Color(0xFF06B6D4),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const RecibosAgenteScreen()),
              );
            },
          ),

          DashboardItem(
            title: "Desarrollo Comercial",
            subtitle: "Desarrollo y crecimiento",
            icon: Icons.trending_up_rounded,
            color: const Color(0xFF10B981),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const DesarrolloCrecimientoEquipoScreen(),
                ),
              );
            },
          ),

          DashboardItem(
            title: "Control Equipos",
            subtitle: "Ver estado",
            icon: Icons.monitor_heart_rounded,
            color: const Color(0xFF22D3EE),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const ControlEquiposJefeVentasScreen(),
                ),
              );
            },
          ),

          DashboardItem(
            title: "Agenda",
            subtitle: "Organizar citas",
            icon: Icons.calendar_month_rounded,
            color: const Color(0xFFA855F7),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const AgendaJefeVentasScreen(),
                ),
              );
            },
          ),
        ];

      case 'director_zona':
        return [
          _annualCommercialPlanItem(context),
          DashboardItem(
            title: "KPIs Globales",
            subtitle: "Ver métricas",
            icon: Icons.bar_chart_rounded,
            color: const Color(0xFF22D3EE),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const DirectorNacionalKpisScreen(),
                ),
              );
            },
          ),
          DashboardItem(
            title: "Rendimiento comercial",
            subtitle: "Primas y mix por estructura",
            icon: Icons.groups_rounded,
            color: const Color(0xFF14B8A6),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const MisEquiposJefeVentasScreen(),
                ),
              );
            },
          ),
          DashboardItem(
            title: "Cuadro de mandos",
            subtitle: "Gobierno de zona",
            icon: Icons.admin_panel_settings_rounded,
            color: const Color(0xFF0284C7),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const CuadroMandosScreen()),
              );
            },
          ),
          DashboardItem(
            title: "Ventas Totales",
            subtitle: "Ver producción",
            icon: Icons.euro_rounded,
            color: const Color(0xFF22C55E),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const MySalesScreen()),
              );
            },
          ),

          DashboardItem(
            title: "Ranking",
            subtitle: "Clasificación",
            icon: Icons.emoji_events_rounded,
            color: const Color(0xFFFFB020),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const RankingComercialScreen(),
                ),
              );
            },
          ),
          DashboardItem(
            title: "Recibos",
            subtitle: "Gestión de cobros",
            icon: Icons.receipt_long_rounded,
            color: const Color(0xFF06B6D4),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const RecibosAgenteScreen()),
              );
            },
          ),

          DashboardItem(
            title: "Desarrollo Comercial",
            subtitle: "Desarrollo y crecimiento",
            icon: Icons.trending_up_rounded,
            color: const Color(0xFF10B981),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const DesarrolloCrecimientoEquipoScreen(),
                ),
              );
            },
          ),

          DashboardItem(
            title: "Control Equipos",
            subtitle: "Ver estado",
            icon: Icons.monitor_heart_rounded,
            color: const Color(0xFF22D3EE),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const ControlEquiposJefeVentasScreen(),
                ),
              );
            },
          ),

          DashboardItem(
            title: "Agenda",
            subtitle: "Organizar citas",
            icon: Icons.calendar_month_rounded,
            color: const Color(0xFFA855F7),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const AgendaJefeVentasScreen(),
                ),
              );
            },
          ),
        ];

      case 'jefe_ventas':
        return [
          _annualCommercialPlanItem(context),
          DashboardItem(
            title: "Rendimiento comercial",
            subtitle: "Primas y mix por estructura",
            icon: Icons.groups_rounded,
            color: const Color(0xFF14B8A6),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const MisEquiposJefeVentasScreen(),
                ),
              );
            },
          ),
          DashboardItem(
            title: "Control Equipos",
            subtitle: "Ver estado",
            icon: Icons.monitor_heart_rounded,
            color: const Color(0xFF22D3EE),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const ControlEquiposJefeVentasScreen(),
                ),
              );
            },
          ),
          DashboardItem(
            title: "Cuadro de mandos",
            subtitle: "Gobierno equipos",
            icon: Icons.admin_panel_settings_rounded,
            color: const Color(0xFF0284C7),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const CuadroMandosScreen()),
              );
            },
          ),
          DashboardItem(
            title: "Rendimiento",
            subtitle: "Seguimiento",
            icon: Icons.show_chart_rounded,
            color: const Color(0xFF8B5CF6),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const SeguimientoJefeVentasScreen(),
                ),
              );
            },
          ),
          DashboardItem(
            title: "Agenda",
            subtitle: "Organizar citas",
            icon: Icons.calendar_month_rounded,
            color: const Color(0xFFA855F7),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const AgendaJefeVentasScreen(),
                ),
              );
            },
          ),
          DashboardItem(
            title: "Recibos",
            subtitle: "Gestión de cobros",
            icon: Icons.receipt_long_rounded,
            color: const Color(0xFF06B6D4),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const RecibosAgenteScreen()),
              );
            },
          ),
          DashboardItem(
            title: "Desarrollo Comercial",
            subtitle: "Desarrollo y crecimiento",
            icon: Icons.trending_up_rounded,
            color: const Color(0xFF10B981),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const DesarrolloCrecimientoEquipoScreen(),
                ),
              );
            },
          ),
        ];

      case 'jefe_equipo':
        return [
          _annualCommercialPlanItem(context),
          DashboardItem(
            title: "Control de equipo",
            subtitle: "Tareas y actividad de tu equipo",
            icon: Icons.monitor_heart_rounded,
            color: const Color(0xFF2454D3),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const ControlEquiposJefeVentasScreen(),
                ),
              );
            },
          ),
          DashboardItem(
            title: "Rendimiento comercial",
            subtitle: "Primas y mix por estructura",
            icon: Icons.insights_rounded,
            color: const Color(0xFF14B8A6),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const MisEquiposJefeVentasScreen(),
                ),
              );
            },
          ),
          DashboardItem(
            title: "Clientes Equipo",
            subtitle: "Cartera equipo",
            icon: Icons.person_rounded,
            color: const Color(0xFF14B8A6),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const TeamDashboardScreen()),
              );
            },
          ),
          DashboardItem(
            title: "Ventas Equipo",
            subtitle: "Ventas de tu estructura",
            icon: Icons.shopping_cart_rounded,
            color: const Color(0xFF2454D3),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const MySalesScreen()),
              );
            },
          ),
          DashboardItem(
            title: "Seguimiento",
            subtitle: "Ver rendimiento",
            icon: Icons.track_changes_rounded,
            color: const Color(0xFFEC4899),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const TeamTrackingScreen()),
              );
            },
          ),
          DashboardItem(
            title: "Tareas",
            subtitle: "Pendientes",
            icon: Icons.assignment_rounded,
            color: const Color(0xFFFF7A00),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const JefeEquipoTareasScreen(),
                ),
              );
            },
          ),
          DashboardItem(
            title: "Agenda",
            subtitle: "Organizar agenda",
            icon: Icons.calendar_month_rounded,
            color: const Color(0xFF8B5CF6),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const AgendaJefeEquipoScreen(),
                ),
              );
            },
          ),
          DashboardItem(
            title: "Recibos",
            subtitle: "Gestión de cobros",
            icon: Icons.receipt_long_rounded,
            color: const Color(0xFF06B6D4),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const RecibosAgenteScreen()),
              );
            },
          ),
        ];

      case 'agente':
        return [
          DashboardItem(
            title: "Mis Clientes",
            subtitle: "Ver cartera",
            icon: Icons.person_rounded,
            color: const Color(0xFF14B8A6),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const MyClientsScreen()),
              );
            },
          ),
          DashboardItem(
            title: "Mis Ventas",
            subtitle: "Ver ventas",
            icon: Icons.shopping_cart_rounded,
            color: const Color(0xFF22C55E),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const MySalesScreen()),
              );
            },
          ),
          DashboardItem(
            title: "Mis Tareas",
            subtitle: "Pendientes",
            icon: Icons.task_alt_rounded,
            color: const Color(0xFFFF7A00),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const MisTareasScreen()),
              );
            },
          ),
          DashboardItem(
            title: "Agenda",
            subtitle: "Ver citas",
            icon: Icons.calendar_month_rounded,
            color: const Color(0xFF8B5CF6),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AgendaScreen()),
              );
            },
          ),
          DashboardItem(
            title: "Recibos",
            subtitle: "Gestión de pagos",
            icon: Icons.receipt_long_rounded,
            color: const Color(0xFF06B6D4),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const RecibosAgenteScreen()),
              );
            },
          ),
        ];

      default:
        return [];
    }
  }

  String _roleTitle(String role) {
    switch (role) {
      case 'director_nacional':
        return "Director nacional";
      case 'administracion':
        return "Administración";
      case 'director_zona':
        return "Director de zona";
      case 'jefe_ventas':
        return "Jefe de ventas";
      case 'jefe_equipo':
        return "Jefe de equipo";
      case 'agente':
        return "Agente comercial";
      default:
        return "Usuario";
    }
  }
}

class _SparklinePainter extends CustomPainter {
  final Color color;

  _SparklinePainter(this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2.3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final path = Path();

    path.moveTo(0, size.height * 0.72);
    path.cubicTo(
      size.width * 0.15,
      size.height * 0.82,
      size.width * 0.22,
      size.height * 0.28,
      size.width * 0.35,
      size.height * 0.50,
    );
    path.cubicTo(
      size.width * 0.48,
      size.height * 0.78,
      size.width * 0.54,
      size.height * 0.18,
      size.width * 0.67,
      size.height * 0.42,
    );
    path.cubicTo(
      size.width * 0.80,
      size.height * 0.65,
      size.width * 0.86,
      size.height * 0.18,
      size.width,
      size.height * 0.22,
    );

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _SparklinePainter oldDelegate) {
    return oldDelegate.color != color;
  }
}
