# SafeBrok iOS 1.2.4 — preparación para Codemagic (30/10/2026)

- Proyecto Codemagic existente: `6a45557d2547c3f18e7d61c8`.
- Workflow: `ios-release` / `iOS Release SafeBrok`.
- Rama de publicación: `release/ios-1.2.4`.
- Identificador conservado: `com.safebrok`. iOS mínimo: 15.0.
- Versión: `1.2.4`; compilación mínima: `16`. Codemagic consulta el último número de Apple e incrementa para evitar duplicados.
- Firma e integración conservadas: `Codemagic Safebrok`, `safebrok_distribution`, `safebrok_appstore_push`; Apple ID `6787038104`.
- Se conserva la fuente completa de iconos y la validación del manifiesto de privacidad en el IPA.
- 136 pruebas generales superadas y 2 omitidas por requerir Windows; 3 pruebas de privacidad superadas.
- Archivo local sin firma generado y verificado: `build/ios/archive/Runner.xcarchive`, versión 1.2.4 (16), manifiesto package_info_plus válido. Este archivo local no es un IPA distribuible.
- La rama de publicación contiene los clientes, recursos, proyecto iOS y pruebas actuales, con manifiestos y dependencias; no se incluyen claves privadas ni compilaciones antiguas.
- El workflow conserva la subida a App Store Connect. No envía automáticamente la aplicación a revisión de App Store ni a beta externa.

La compilación firmada de Codemagic y la subida a Apple deben verificarse antes de afirmar que hay un IPA disponible o una publicación completada.
